export const COLUMNS = [
  {
    label: 'Detail view',
    type: 'button-icon',
    fixedWidth: 90,
    typeAttributes:
    {
      iconName: 'utility:preview',
      name: 'preview'
    }
  },
  {
    label: 'Hospital Benefit ID', fieldName: 'productClaimHospitalBenefitID', type: 'text',
    typeAttributes: { linkify: true }
  },
  { label: 'Benefit Ref', fieldName: 'benefitRef' },
  { label: 'Start Date', fieldName: 'hospitalisationStartDate' },
  { label: 'End Date', fieldName: 'hospitalisationEndDate' },
  { label: 'Qualifying nights', fieldName: 'qualifyingNights' },
  { label: 'Benefit payable', fieldName: 'benefitAmount' },	
  { label: 'Approval date', fieldName: 'approvalDate' },

  {
    label: 'Delete',
    type: 'button-icon',
    fixedWidth: 90,
    typeAttributes:
    {
      iconName: 'utility:delete',
      name: 'delete'
    }
  }
];