import { LightningElement, api, track } from 'lwc';
import { addNewHospitalBenefitOnProductClaim,getInitialPayLoad, deleteHospitalBenefitOnProductClaim} from 'c/productClaimDataHandler';

//constants
import { COLUMNS } from './hospitslBenifitLayout.js';


export default class ProductClaimTabHospitalBenifit extends LightningElement {
    @track hospitalBenefitData = {};
    @track tabReadOnlyData = {};
    @track columns = COLUMNS;

    @api claimExternalId;
    @api recordId;

    // if:true values
    @track showNewHospitalBenefitForm = false;
    @track disableButton = false;
    @track disableDescription = true;

    connectedCallback(){
        this.invokeApexMethods();
    }

    async invokeApexMethods(){
        let result;
        try{
            result = await getInitialPayLoad(this.claimExternalId);
        } catch(e){
            console.log(e.message);
        }
        finally{
            //this.tabData = JSON.parse(result.productDataUpdate);
            this.tabReadOnlyData = JSON.parse(result.productDataReadOnly);
        }
    }

    handlehospitalBenefitDataChange(e){

        if(e.target.name == 'benefitRef' )
        {
           this.hospitalBenefitData.benefitRef = e.target.value;
        }
        else if(e.target.name== 'hospitalisationStartDate' )
        {
            this.hospitalBenefitData.hospitalisationStartDate = e.target.value;
        }
        else if(e.target.name== 'hospitalisationEndDate' )
        {
            this.hospitalBenefitData.hospitalisationEndDate = e.target.value;
        }
        else if(e.target.name== 'qualifyingNights' )
        {
            this.hospitalBenefitData.qualifyingNights = parseInt(e.target.value);
        }
        else if(e.target.name== 'benefitAmount' )
        {
            this.hospitalBenefitData.benefitAmount = parseInt(e.target.value);
        }
        else if(e.target.name== 'approvalDate' )
        {
            this.hospitalBenefitData.approvalDate = parseInt(e.target.value);
        }
        

        console.log(JSON.stringify(this.hospitalBenefitData));
    }


    // for listening the "refresh" event, which is dispatched when a save/cancel action happens.
   /* subscribeToMessageChannel() {
        if (!this.subscription) {
            this.subscription = subscribe(
                this.messageContext,
                ProductClaimRefreshData__c,
                (message) => this.handleRefreshMessage(message),
                { scope: APPLICATION_SCOPE }
            );
        }
    }*/

    addNewHospitalBenefit(event){
        this.showNewHospitalBenefitForm = true;
        this.disableButton = true;
    }

    

    onSave(event){
        console.log('hospital Benefit data '+this.hospitalBenefitData);
        addNewHospitalBenefitOnProductClaim(this.claimExternalId,JSON.stringify(this.hospitalBenefitData)).then(result => {
            console.log('pozvao sam eksterni servis');
        });
        this.showNewHospitalBenefitForm = false;
        this.disableButton = false;
        invokeApexMethods();
        
    }

    handleRowAction(event){
        if(event.detail.action.name === 'preview'){
            this.template.querySelector("[data-id='productClaimhospitalBenefitForm']").showModal(event.detail.row);

            console.log('event.detail.row '+JSON.stringify(event.detail.row));
        }
        else if(event.detail.action.name === 'delete')
        {
            if (confirm("Do you want to delete this hospital Benefit?") == true) {
                console.log('HospitalBenefitID '+ event.detail.row.productClaimHospitalBenefitID);
                deleteHospitalBenefitOnProductClaim(event.detail.row.productClaimHospitalBenefitID).then(result => {
                    console.log('delete service called');
                });
              }
        }
    }
}