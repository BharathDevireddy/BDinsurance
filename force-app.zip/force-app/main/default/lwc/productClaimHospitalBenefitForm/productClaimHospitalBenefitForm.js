import { LightningElement, track, api } from 'lwc';
//import { addNewExpenseOnProductClaim } from 'c/productClaimDataHandler';
//constants


export default class ProductClaimExpenseForm extends LightningElement {

    @api claimExternalId;
    @api tabReadOnlyData;
    hospitalBenefit = {};

    modalVisible = false;

    // if:true values
    @track showNewHospitalBenefitForm = false;
    @track disableButton = false;

    //for disabled button on description
    //@track disableDescription = true;

    connectedCallback(){
        console.log('Hospital Benefit FORM DATA  '+JSON.stringify(this.tabReadOnlyData));
    }

    addNewHospitalBenefit(event){
        this.showNewHospitalBenefitForm = true;
        this.disableButton = true;
    }


    onUpdate(event){

    }
    @api
    showModal(data) {
        console.log('show modal '+JSON.stringify(data));
        this.hospitalBenefit = data;
        this.modalVisible = true;
    }

    @api
    closeModal() {
        this.modalVisible = false;
    }
}