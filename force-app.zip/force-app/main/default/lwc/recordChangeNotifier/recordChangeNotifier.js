import { api, LightningElement, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';

/**
 * @description This component is used to determine whether a record has
 * changed. In the event that the record does change, it will fire a 'change'
 * event, and the detail of the event will be the id of the record which
 * triggered the change.
 *
 * @param {string} recordId This is the id of the record which you want to be
 * tracked.
 */
export default class RecordChangeNotifier extends LightningElement {
    @api recordId;
    @api objectApiName;

    firstGet = true;

    // Track the last modified date so that any changes to the record are
    // captured by this component
    get fieldNames() { return [ `${this.objectApiName}.LastModifiedDate` ]; }

    @wire(getRecord, { recordId: "$recordId", fields: "$fieldNames" })
    getRecordData({ data, error }) {
        if(data) {
            // We presume that people won't care about the record changing for
            // the first time, as they will probably be fetching the data when
            // their component first loads anyway, so we skip this event firing
            // on the component getting its first load of data.
            if(!this.firstGet) this.dispatchEvent(new CustomEvent('change', { detail: this.recordId }));
            this.firstGet = false;
        } else if(error) {
            // Suggests that the record has been deleted, so we should send a
            // change notification
            if(error.status === 404) {
                if(!this.firstGet) this.dispatchEvent(new CustomEvent('change', { detail: this.recordId }));
                this.firstGet = false;
            } else {
                console.error(error);
            }
        }
    }
}