import UnderwritingOutcome__c from '@salesforce/schema/UnderwritingOutcome__c';

import Cover__c               from '@salesforce/schema/UnderwritingOutcome__c.Cover__c';
import URE_Recommendation__c  from '@salesforce/schema/UnderwritingOutcome__c.URE_Recommendation__c';
import URE_MortalityRating__c from '@salesforce/schema/UnderwritingOutcome__c.URE_MortalityRating__c';
import UREExclusions__c       from '@salesforce/schema/UnderwritingOutcome__c.UREExclusions__c';
import URERemovals__c         from '@salesforce/schema/UnderwritingOutcome__c.URERemovals__c';
import UW_Decision__c         from '@salesforce/schema/UnderwritingOutcome__c.UW_Decision__c';
import UW_MortalityRating__c  from '@salesforce/schema/UnderwritingOutcome__c.UW_MortalityRating__c';
import UWExclusions__c        from '@salesforce/schema/UnderwritingOutcome__c.UWExclusions__c';
import UWRemovals__c          from '@salesforce/schema/UnderwritingOutcome__c.UWRemovals__c';

/**
 * @description A wrapper around the `UnderwritingOutcome__c` Object
 *
 * (Potentially) Contains all fields from the `UnderwritingOutcome__c` object as
 * well as a few others
 *
 * @property {string} coverTypeLabel The Label for the value of the `Cover__c`
 * picklist value on `UnderwritingOutcome__c`
 * @property {string} recordLink The URL to the `UnderwritingOutcome__c` record
 *
 * @property {{ [fieldApiName: string]: { [picklistValue]: picklistLabel } }} UnderwritingOutcome.picklistLabels
 * The picklist labels required. Set a particular field using the
 * `UnderwritingOutcome.setPicklistLabels` static function.
 * @property {string} UnderwritingOutcome.objectApiName The API name for the
 * `UnderwritingOutcome__c` object.
 */
export class UnderwritingOutcome {
    static picklistLabels = { };
    static objectApiName  = UnderwritingOutcome__c.objectApiName;

    constructor(outcomeData) {
        Object.assign(this, outcomeData);
    }

    get coverTypeLabel() {
        const fieldApiName = Cover__c.fieldApiName;
        const labels       = UnderwritingOutcome.picklistLabels[fieldApiName];

        const coverType = this[fieldApiName];
        return labels && labels[coverType];
    }
	get URERemovalsLabel() {
		const fieldApiName = URERemovals__c.fieldApiName;
		const labels       = UnderwritingOutcome.picklistLabels[fieldApiName];
		
		let labelledvalues = UnderwritingOutcome.multiSelectLabelReplace(this[fieldApiName], labels);
		return labels && labelledvalues;
	}
	get UREExclusionsLabel() {
		const fieldApiName = UREExclusions__c.fieldApiName;
		const labels       = UnderwritingOutcome.picklistLabels[fieldApiName];
		
		let labelledvalues = UnderwritingOutcome.multiSelectLabelReplace(this[fieldApiName], labels);
		return labels && labelledvalues;
	}
	get UWRemovalsLabel() {
		const fieldApiName = UWRemovals__c.fieldApiName;
		const labels       = UnderwritingOutcome.picklistLabels[fieldApiName];
		
		let labelledvalues = UnderwritingOutcome.multiSelectLabelReplace(this[fieldApiName], labels);
		return labels && labelledvalues;;
	}
	get UWExclusionsLabel() {
		const fieldApiName = UWExclusions__c.fieldApiName;
		const labels       = UnderwritingOutcome.picklistLabels[fieldApiName];
		
		let labelledvalues = UnderwritingOutcome.multiSelectLabelReplace(this[fieldApiName], labels);
		return labels && labelledvalues;;
	}


    get recordLink() { return `/lightning/r/${UnderwritingOutcome.objectApiName}/${this.Id}/view`; }

	 static multiSelectLabelReplace(fieldValue, labels){
		let retVal = '';
		if(fieldValue){
			const options = fieldValue.split(';');
			options.forEach(
				(item) => {retVal += labels[item] + '; '}
			);
		}
		return retVal;
	 }

    /**
     * @description Set the picklist values for `fieldApiName` to the values
     * stored in the `picklistValues`
     * @param {string} fieldApiName The API name of the field which the values
     * in `picklistValues` apply to
     * @param {{ value: string, label: string }[]} picklistValues
     */
    static setPicklistLabels(fieldApiName, picklistValues) {
        const picklistLabels = { };
        for(const entry of picklistValues) {
            picklistLabels[entry.value] = entry.label;
        }
        UnderwritingOutcome.picklistLabels[fieldApiName] = picklistLabels;
    }
    /**
     * @description Build the columns for the table
     * @param {ObjectInfo} objectInfo The `ObjectInfo` (e.g. from
     * `getObjectInfo`) for the `UnderwritingOutcome__c` object.
     * @return {ColumnInfo[]} The Column infos for the Underwriting Outcome part
     * of the decision summary table
     */
    static buildColumns(objectInfo) {
        return [
            {
                label: objectInfo.fields[Cover__c.fieldApiName].label,
                fieldName: 'recordLink',
                type: 'url',
                typeAttributes: {
                    label: {
                        fieldName: 'coverTypeLabel',
                    },
                    tooltip: {
                        fieldName: 'coverTypeLabel'
                    }
                },
            },
            {
                label: objectInfo.fields[URE_Recommendation__c.fieldApiName].label,
                fieldName: URE_Recommendation__c.fieldApiName,
                type: 'text',
            },
            {
                label: objectInfo.fields[URE_MortalityRating__c.fieldApiName].label,
                fieldName: URE_MortalityRating__c.fieldApiName,
                type: 'text',
            },
            {
                label: objectInfo.fields[UREExclusions__c.fieldApiName].label,
                fieldName: 'UREExclusionsLabel',
                type: 'text',
            },
            {
                label: objectInfo.fields[URERemovals__c.fieldApiName].label,
                fieldName: 'URERemovalsLabel',
                type: 'text',
            },
            {
                label: objectInfo.fields[UW_Decision__c.fieldApiName].label,
                fieldName: UW_Decision__c.fieldApiName,
                type: 'text',
            },
            {
                label: objectInfo.fields[UW_MortalityRating__c.fieldApiName].label,
                fieldName: UW_MortalityRating__c.fieldApiName,
                type: 'text',
            },
            {
                label: objectInfo.fields[UWExclusions__c.fieldApiName].label,
                fieldName: 'UWExclusionsLabel',
                type: 'text',
            },
            {
                label: objectInfo.fields[UWRemovals__c.fieldApiName].label,
					 fieldName: 'UWRemovalsLabel',
                type: 'text',
            },			
        ]
    }
}