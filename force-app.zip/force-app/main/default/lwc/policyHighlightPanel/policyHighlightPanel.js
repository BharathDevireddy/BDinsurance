//LWC Imports
import { LightningElement, api, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import { createRecord, getFieldValue } from 'lightning/uiRecordApi';

//Salesforce Imports
import CASE_OBJECT from '@salesforce/schema/Case';
import CASE_FIELD__RECORDTYPEID from '@salesforce/schema/Case.RecordTypeId';
import CASE_FIELD__ACCOUNTID from '@salesforce/schema/Case.AccountId';

//Label Imports
import LABEL_TITLE from '@salesforce/label/c.NewPolicyClaimButton_Title';
import LABEL_BODY from '@salesforce/label/c.NewPolicyClaimButton_Body';
import NEW_CLAIM_LABEL from '@salesforce/label/c.NewPolicyClaimButton_Label';
import NEW_CLAIM_ERROR_TITLE from '@salesforce/label/c.NewPolicyClaimButton_Error_Title';

//Permission Imports
import HAS_NEW_CLAIM_ENQUIRY_PERMISSION from '@salesforce/customPermission/CoverDetailNewClaimsEnquiryAccess';

//Component Imports
import { callApex, getErrorMessage } from 'c/utility';

//Apex Imports
import fetchRecordType from '@salesforce/apex/LExToolkit.fetchRecordType';
import fetchAccountForPolicyNumber from '@salesforce/apex/PolicyHeader_LEx.fetchAccountForPolicyNumber';
import fetchLatestOpenCase from '@salesforce/apex/PolicyHeader_LEx.fetchLatestOpenCase';

//Consts
const CASE_RT_DEV_NAME_POLICY_CLAIM = 'Policy_Claim';

export default class PolicyHighlightPanel extends NavigationMixin(LightningElement) {

    /*=========================================================
            API Vars
    =========================================================*/

    @api policyref;

    /*=========================================================
            Vars
    =========================================================*/

    confirmationTitle = LABEL_TITLE;
    confirmationBody = LABEL_BODY;

    displayNewClaimButton = HAS_NEW_CLAIM_ENQUIRY_PERMISSION;
    newClaimLabel = NEW_CLAIM_LABEL;
    newClaimLoading = true; //Set to true whilst we load the check for latest open case

    @track account;
    @track accountUrl;
    @track openCaseId;

    /*=========================================================
            Wires
    =========================================================*/

    @wire(fetchAccountForPolicyNumber, {pPolicyNumber:'$policyref'}) onAccountLoad(pAccount) {
        this.account = pAccount;
        if(this.account.data) {
            this[NavigationMixin.GenerateUrl]({
                type: 'standard__recordPage',
                attributes: {
                    "recordId": this.account.data.Id,
                    "objectApiName": "Account",
                    "actionName": "view"
                },
            }).then(pUrl => this.accountUrl = pUrl);
        }
    }

    /*=========================================================
            Events
    =========================================================*/

    onNewClaim() { this.handleNewClaim(); }

    /*=========================================================
            Setup
    =========================================================*/

    async connectedCallback() {
        callApex(
            fetchLatestOpenCase
            , { 
                pPolicyNumber: this.policyref
            }
        ).then(pCaseId => {
            this.openCaseId = pCaseId;
        }).catch(ex => {
            this.caseUrl = undefined;
            console.error(ex);
        }).finally(() => this.newClaimLoading = false)
    }

    /*=========================================================
            Handlers
    =========================================================*/
    
    async handleNewClaim() {
        if(!this.newClaimLoading) {
            this.newClaimLoading = true; //Prevent duplicate button clicks
            try {
                let isConfirmed = true;
                let [rtInfo] = await Promise.all([
                    callApex(
                        fetchRecordType
                        , { 
                            pObjectName: CASE_OBJECT.objectApiName, 
                            pRecordTypeDeveloperName: CASE_RT_DEV_NAME_POLICY_CLAIM 
                        }
                    )
                    , this.openCaseId 
                        ? this.template.querySelector('c-confirmation-modal').getConfirmation().catch(ex => isConfirmed = false) 
                        : Promise.resolve()
                ]);
                if(isConfirmed) {
                    let record = await createRecord({
                        apiName: CASE_OBJECT.objectApiName,
                        fields: {
                            [CASE_FIELD__RECORDTYPEID.fieldApiName]: rtInfo.Id,
                            [CASE_FIELD__ACCOUNTID.fieldApiName]: this.account.data.Id
                        }
                    });
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Success',
                        message: 'Successfully created new Policy Claim Case',
                        variant: 'success'
                    }));
                    this[NavigationMixin.Navigate]({
                        type: 'standard__recordPage',
                        attributes: {
                            "recordId": record.id,
                            "objectApiName": CASE_OBJECT.objectApiName,
                            "actionName": "view"
                        },
                    })
                }

            } catch(ex) {
                //Log error
                console.error(ex);
                //Build error message
                let errorParts = [];
                errorParts.push(getErrorMessage(ex, 'Unable to understand error'));
                if(ex.body.output.errors) {
                    errorParts.push(...ex.body.output.errors.map(error => error.message));
                }
                if(ex.body.output.fieldErrors) {
                    for(let fieldName in ex.body.output.fieldErrors) {
                        errorParts.push(...ex.body.output.fieldErrors[fieldName].map(error => error.fieldLabel + ': ' + error.message));
                    }
                }
                //Throw toast
                this.dispatchEvent(new ShowToastEvent({
                    title: NEW_CLAIM_ERROR_TITLE,
                    message: errorParts.join('; '),
                    variant: 'error'
                }));
            } finally {
                this.newClaimLoading = false;
            }
        }
    }

}