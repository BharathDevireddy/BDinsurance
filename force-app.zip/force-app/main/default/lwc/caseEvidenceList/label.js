import Cancel                                  from '@salesforce/label/c.Cancel';
import CaseEvidenceList_Action_Delete          from '@salesforce/label/c.CaseEvidenceList_Action_Delete';
import CaseEvidenceList_Action_Edit            from '@salesforce/label/c.CaseEvidenceList_Action_Edit';
import CaseEvidenceList_DeleteEvidence_Confirm from '@salesforce/label/c.CaseEvidenceList_DeleteEvidence_Confirm';
import CaseEvidenceList_DeleteEvidence_Title   from '@salesforce/label/c.CaseEvidenceList_DeleteEvidence_Title';
import CaseEvidenceList_NewEvidence_Button     from '@salesforce/label/c.CaseEvidenceList_NewEvidence_Button';
import CaseEvidenceList_SetStatus_Button       from '@salesforce/label/c.CaseEvidenceList_SetStatus_Button';
import CaseEvidenceList_SetStatus_Title        from '@salesforce/label/c.CaseEvidenceList_SetStatus_Title';

export {
    Cancel,
    CaseEvidenceList_Action_Delete,
    CaseEvidenceList_Action_Edit,
    CaseEvidenceList_DeleteEvidence_Confirm,
    CaseEvidenceList_DeleteEvidence_Title,
    CaseEvidenceList_NewEvidence_Button,
    CaseEvidenceList_SetStatus_Button,
    CaseEvidenceList_SetStatus_Title,
}