import obj_Case                        from '@salesforce/schema/Case';
import fld_Case__Application_Member__c from '@salesforce/schema/Case.Application_Member__c';

import obj_Evidence__c                     from '@salesforce/schema/Evidence__c';
import fld_Evidence__Application_Member__c from '@salesforce/schema/Evidence__c.Application_Member__c';
import fld_Evidence__Case__c               from '@salesforce/schema/Evidence__c.Case__c';
import fld_Evidence__CreatedDate           from '@salesforce/schema/Evidence__c.CreatedDate';
import fld_Evidence__Instructions__c       from '@salesforce/schema/Evidence__c.Instructions__c';
import fld_Evidence__LastModifiedDate      from '@salesforce/schema/Evidence__c.LastModifiedDate';
import fld_Evidence__Name                  from '@salesforce/schema/Evidence__c.Name';
import fld_Evidence__Status__c             from '@salesforce/schema/Evidence__c.Status__c';
import fld_Evidence__SubtypeSubjects__c    from '@salesforce/schema/Evidence__c.SubtypeSubjects__c';
import fld_Evidence__Type__c               from '@salesforce/schema/Evidence__c.Type__c';

const schema = { };

function addSObjectData(obj, ...fields) {
    const output = { };
    output.sObjectType = obj;
    for(const field of fields) {
        output[field.fieldApiName] = field;
    }

    schema[obj.objectApiName] = Object.freeze(output);
}

addSObjectData(obj_Case, fld_Case__Application_Member__c);
addSObjectData(
    obj_Evidence__c,
    fld_Evidence__Application_Member__c,
    fld_Evidence__Case__c,
    fld_Evidence__CreatedDate,
    fld_Evidence__Instructions__c,
    fld_Evidence__LastModifiedDate,
    fld_Evidence__Name,
    fld_Evidence__Status__c,
    fld_Evidence__SubtypeSubjects__c,
    fld_Evidence__Type__c,
);
Object.freeze(schema);

export default schema;