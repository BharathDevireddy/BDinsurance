import apex_fetchEvidence from '@salesforce/apex/CaseEvidenceList_Ctrl.fetchEvidence';
import apex_massSetStatus from '@salesforce/apex/CaseEvidenceList_Ctrl.massSetStatus';

export function fetchEvidence(caseId) {
    return apex_fetchEvidence({ caseId });
}
export function massSetStatus(evidenceIds, status) {
    return apex_massSetStatus({ evidenceIds, status });
}