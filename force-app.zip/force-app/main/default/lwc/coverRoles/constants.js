export const COLUMNS = [
    {
        label: 'Name',
        fieldName: 'Name',
        type: 'conditionalLink',
        typeAttributes: {
            displayUrl: {
                fieldName: 'Link'
            },
            link: {
                fieldName: 'Link'
            }
        }
    },
    {
        label: 'Date Of Birth',
        fieldName: 'DateOfBirth',
        type: 'date',
        typeAttributes: { 
            day: '2-digit', 
            month: '2-digit', 
            year: 'numeric' 
        }
    },
    {
        label: 'Role',
        fieldName: 'RoleType',
        type: 'text'
    },
    {
        label: '%',
        fieldName: 'PercentageRate',
        type: 'percent',
        typeAttributes: {minimumFractionDigits: 3}
    },
    {
        label: 'Start Date',
        fieldName: 'StartDate',
        type: 'date',
        typeAttributes: { 
            day: '2-digit', 
            month: '2-digit', 
            year: 'numeric' 
        }
    },
    {
        label: 'End Date',
        fieldName: 'EndDate',
        type: 'date',
        typeAttributes: { 
            day: '2-digit', 
            month: '2-digit', 
            year: 'numeric' 
        }
    }
];

import { SORT_ASCENDING } from "c/utility";
export const DATA_ORDERING = [
    {
        property: 'RoleType',
        direction: SORT_ASCENDING
    },
    {
        property: 'FirstName',
        direction: SORT_ASCENDING
    },
    {
        property: 'LastName',
        direction: SORT_ASCENDING
    },
    {
        property: 'DateOfBirth',
        direction: SORT_ASCENDING
    }
];