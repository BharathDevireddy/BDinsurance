import { LightningElement, api } from 'lwc';

export default class CoverSummary extends LightningElement {

    /*=========================================================
            External Vars
    =========================================================*/

    @api displayExpandedFields = false;
    @api displayActiveOnly = false;
    @api displayMatchingProductGroupOnly = false;
    @api recordId;


    /*=========================================================
            Getters
    =========================================================*/

    get activeTableTags() {
        let ret = [ 'Active' ];
        if(this.displayExpandedFields) ret.push('Expanded');
        return ret;
    }

    get inactiveTableTags() {
        return ['Inactive'];
    }

    /*=========================================================
            Events
    =========================================================*/

    onAccountChange() {
        this.template.querySelectorAll('c-cover-table').forEach(element => element.onAccountChange());
    }

}