import { LightningElement, api } from 'lwc';

export default class ProductClaimTabAssessment extends LightningElement {

    @api recordId;

    onNewAssessment() {
        this.template.querySelector("[data-id='assessmentCreateModal']").showModal();
    }

    onCloseNewAssessmentModal() {
        this.template.querySelector("[data-id='assessmentCreateModal']").closeModal();
    }

    onSearch(event) {
        this.template.querySelector("[data-id='assessmentList']").getAssessmentData(event.detail);
    }

    onAssessmentSaved(event) {
        this.template.querySelector("[data-id='assessmentList']").getAssessmentData();
    }
}