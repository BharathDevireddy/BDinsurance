import { LightningElement, api, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const columns = [
        {
            label: 'Detail view',
            type: 'button-icon',
            fixedWidth: 90,
            typeAttributes:
                {
                    iconName: 'utility:preview',
                    name: 'preview'
                }
        },
        {
            label: 'Benefit Ref',
            fieldName: 'benefitRef',
            type: 'text'
        },
        {
            label: 'Start Date',
            fieldName: 'startDate',
            type: 'date'
        },
        {
            label: 'End Date',
            fieldName: 'endDate',
            type: 'date'
        },
        {
            label: 'Qualifying nights',
            fieldName: 'qualifyingNights',
            type: 'text'
        },
        {
            label: 'Benefit payable',
            fieldName: 'benefitPayable',
            type: 'text'
        },
        {
            label: 'Approval date',
            fieldName: 'approvalDate',
            type: 'date'
        }
];

export default class ProductClaimTabHospitalBenifitForm extends LightningElement {
    @api recordId;

    @track dataExists = true;
    @track hospitalBenifitsColumns = columns;
    @track showSpinner;

   handleRowAction(event){
    const dataRow = event.detail.row;
      this.contactRow = dataRow;
      // commented out because constantly showing on the page
      //this.showSpinner = true; 
    if(event.detail.action.name === 'preview'){
        this.template.querySelector("[data-id='hospitalBenifitDetailsModal']").showModal();
    }    
   }

   showNotification(title, message, variant) {
       const evt = new ShowToastEvent({
           title: title,
           message: message,
           variant: variant,
       });
       this.dispatchEvent(evt);
   }
}