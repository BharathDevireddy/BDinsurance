import { LightningElement, api } from 'lwc';

export default class RelatedListHeader extends LightningElement {
    @api title;

    get hasStringTitle() {
        return !!this.title;
    }
}