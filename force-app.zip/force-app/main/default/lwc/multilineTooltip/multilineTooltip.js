import { LightningElement, api, track } from 'lwc';

export default class MultilineTooltip extends LightningElement {

    @api value;

    get nubbinElement() { return this.template.querySelector('[data-identifier="nubbin"]'); }
    get tooltipElement() { return this.template.querySelector('[data-identifier="tooltip"]'); }

    onMouseOver() { this.showNubbin(); }
    onMouseOut() { this.hideNubbin(); }

    showNubbin() {
        this.nubbinElement.classList.remove('slds-hide');
        this.updateNubbinPosition();
        window.addEventListener('scroll', this.updateNubbinPosition.bind(this));
    }

    hideNubbin() {
        this.nubbinElement.classList.add('slds-hide');
        window.removeEventListener('scroll', this.updateNubbinPosition);
    }

    updateNubbinPosition() {
        let nubbin = this.nubbinElement;
        let tooltip = this.tooltipElement;
        let tooltipBounds = tooltip.getBoundingClientRect();
        
        nubbin.style.top = (tooltipBounds.top - nubbin.offsetHeight - 15) + 'px';
        nubbin.style.left = (tooltipBounds.left - 16) + 'px';
    }
}