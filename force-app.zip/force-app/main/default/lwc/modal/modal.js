import { api, LightningElement, track } from 'lwc';

/**
 * @description A modal which tries to be as close to a standard Salesforce
 * modal as possible.
 *
 * When the close button is pressed (the "X" icon) it will fire a `close` event,
 * but it will not actually close on its own. The caller will need to catch this
 * event and change the `show` parameter in order to close the modal.
 *
 * @param {boolean} headless If this is true, it will not show a header for the
 * component. If this is false, anything in the `header` slot will be shown in
 * the header.
 * @param {boolean} footless If this is true, it will not show a footer for the
 * component. If this is false, anything in the `footer` slot will be shown in
 * the footer.
 * @param {string} size Either 'small', 'medium', 'large'. Determines the size
 * of the modal. Can be null.
 * @param {boolean} show Whether or not the modal is visible. This component
 * should not be hidden behind an `if:true`/`if:false` directive otherwise the
 * component will instantly disappear when it is closed. Using this `show`
 * instead will make it so that the component will fade in and out when loading
 * and being closed.
 */
export default class Modal extends LightningElement {
    @api headless = false;
    @api footless = false;
    @api size;

    @api
    get show() {
        return this.internalShow;
    }
    set show(value) {
        if(value) {
            this.internalShow = true;
            this.closed       = false;
        } else {
            if(this.internalShow && !this.closed) {
                this.closed = true;
                // Wait for the animation to end before classifying ourselves as
                // closed. The reason we need to do this is because the only way
                // that we can make it so that the page is interactive again is
                // to make it so that the modal is marked as "visibility: none".
                // However, if we do that immediately the modal will simply
                // disappear, so we wait for the animation to finish and then
                // make it so that the modal is completely invisible.
                const section = this.template.querySelector('[data-id="section"]');
                const func = () => {
                    this.internalShow = false;
                    section.removeEventListener("animationend", func);
                };
                section.addEventListener("animationend", func);
            }
        }
    }

    @track internalShow = false;
    @track closed       = true;


    get sectionClass()  { return this.show   ? `slds-modal ${this.stateClass}${this.sizeClass}` : `slds-modal${this.sizeClass}`; }
    get backdropClass() { return this.closed ? 'slds-backdrop' : 'slds-backdrop slds-backdrop_open'; }
    get stateClass()    { return this.closed ? 'closing' : 'open'; }

    get sizeClass() {
        switch(this.size) {
        case 'small':
        case 'medium':
        case 'large':
            return ` slds-modal_${this.size}`;
        default:
            return '';
        }
    }

    onClose() {
        this.dispatchEvent(new CustomEvent('close'));
    }
}