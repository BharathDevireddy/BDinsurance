//LWC Imports
import { api, track, wire } from 'lwc';
import { getRecord, updateRecord } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import ClaimsComponent from 'c/claimsComponent';
import { getInitialPayLoad, getProductData, getProductReadOnlyData, setProductData } from 'c/productClaimDataHandler';

//Message channel info
import ProductClaimDirty__c from '@salesforce/messageChannel/ProductClaimDirty__c';
import ProductClaimRefreshData__c from '@salesforce/messageChannel/ProductClaimRefreshData__c';
import { publish, MessageContext, subscribe, APPLICATION_SCOPE, unsubscribe} from 'lightning/messageService';

//Constants
import { LAYOUT_DATA } from './constantLayout.js';
import { JOB_LAYOUT_DATA } from './jobLayout.js';
import { INCAPACITY_LAYOUT_DATA } from './incapacityLayout.js';
import BODY from './productClaimTabSummary.html';
const FIELDS = ['Case.New_Claim_Next_Action_Date__c'];

export default class ProductClaimTabSummary extends ClaimsComponent {

    /*=========================================================
            Claims Component Vars
    =========================================================*/

    componentLabel = 'Summary';
    componentBody = BODY;

    /*=========================================================
           Vars
    =========================================================*/
    @api claimExternalId;
    @api recordId;

    @wire(getRecord, { recordId: '$recordId', fields: FIELDS })
    wiredRecord({ error, data }) {
        if (error) {
            let message = 'Unknown error';
            if (Array.isArray(error.body)) message = error.body.map(e => e.message).join(', ');
            else if (typeof error.body.message === 'string') message = error.body.message;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error Loading Product Claim!',
                    message,
                    variant: 'error',
                }),
            );
        } else if(data) {
            this.productClaimCase = data;
            this.oldNextActionDate = this.nextActionDate = data.fields.New_Claim_Next_Action_Date__c.value; 
        }
    }

    @wire(MessageContext)
    messageContext;
    subscription = null;

    @track formData = {};
    @track tabData = {};
    @track tabReadOnlyData = {};
    @track layoutData = {};
    productClaimCase;
    nextActionDate; oldNextActionDate;
    numberOfNewIncapacities = 0;
	numberOfNewReviews = 0;
    numberOfNewJobs = 0;
    incapacity = {
        productClaimIncapacityID : 0,
        icD10Code : null,
        causeOfIncapacity : null,
        dateOfIncapacity : null,
		incapacityEndDate : null, 
		incapacityEndReason: null 
    };
    occupation = {
        productClaimOccupationID : 0,
        jobTitle : null,
        employerName : null,
        employmentType : null,
        hoursWorked : null,
        natureOfDuties : null
    };
	review = {
        productClaimReviewsID : 0,
        assessmentReviewPredictedEndDate : null,
        assessmentReviewDate : null,
        assessmentReviewActions : null,
        assessmentReviewNotes : null
    };
	today = new Date();
	wasSummaryDataValid = false;
    
    /*=========================================================
           Setup
    =========================================================*/
    
    connectedCallback() {
        getInitialPayLoad(this.claimExternalId).then(result => {
            this.tabData = JSON.parse(result.productDataUpdate);    
            this.tabReadOnlyData = JSON.parse(result.productDataReadOnly);
            this.State.show();
            this.subscribeToMessageChannel(); // subscribing to the "save/ancel" event message channel
            this.loadTheContent(false); // this is for loading the summary data in the fields, initial load
        });
    }
    
    // when a field is updated we're updating the pointer & opening the global "save - cancel" popup
    handleSummaryDataChange(e) {
		var isNextActionDateValid = true;
		var isIncapacityDateValid = true;
		//var isEndDateIncapacityDateValid = true;
		var isOriginalIncapacityDateValid = true;
        if (e.detail[1].includes('icD10Code') === false
            && e.detail[1].includes('causeOfIncapacity') === false
            && e.detail[1].includes('dateOfIncapacity') === false
			&& e.detail[1].includes('incapacityEndDate') === false
			&& e.detail[1].includes('incapacityEndReason') === false
            && e.detail[1].includes('jobTitle') === false
            && e.detail[1].includes('employerName') === false
            && e.detail[1].includes('employmentType') === false
            && e.detail[1].includes('hoursWorked') === false
            && e.detail[1].includes('natureOfDuties') === false
            && e.detail[1].includes('bpsScoreName') === false
/*            && e.detail[1].includes('assessmentReviewPredictedEndDate') === false
            && e.detail[1].includes('assessmentReviewDate') === false
            && e.detail[1].includes('assessmentReviewActions') === false
  */          && e.detail[1].includes('incapacityEndReason') === false
            && e.detail[1].includes('New_Claim_Next_Action_Date__c') === false
            && e.detail[1].includes('incapacityCategories') === false) {
            this.tabData.summary[e.detail[1]] = e.detail[0];
		} else if (e.detail[1].includes('New_Claim_Next_Action_Date__c') === true) {
            this.nextActionDate = e.detail[0];
            this.tabData['nextActionDate'] = this.nextActionDate;
        } else if (e.detail[1].includes('incapacityCategories') === true) {
            this.falsifyIncapacityCategories();
            let arr = e.detail[0].split(',');
            for(let i=0; i<arr.length; i++) {
                this.tabData.summary.incapacityCategory[arr[i]] = true;
			}
        } else if (e.detail[1].includes('bpsScoreName')) {
            if (e.detail[0] === 'Low') {
                this.tabData.summary.bpsScore = 1;
                this.tabData.summary.bpsScoreName = 'Low';
            } else if (e.detail[0] === 'Medium') {
                this.tabData.summary.bpsScore = 2;
                this.tabData.summary.bpsScoreName = 'Medium';
            } else {
                this.tabData.summary.bpsScore = 3;
                this.tabData.summary.bpsScoreName = 'High';
            }
        } else if (e.detail[1].includes('icD10Code') === true
				|| e.detail[1].includes('causeOfIncapacity') === true
				|| e.detail[1].includes('dateOfIncapacity') === true 
				|| e.detail[1].includes('incapacityEndDate') === true
                || e.detail[1].includes('incapacityEndReason') === true) { 
            if (this.tabData.summary.incapacities.length <= 0) {
                this.tabData.summary.incapacities.push(this.incapacity);
                this.tabData.summary.incapacities[0].toDelete = false;
                this.tabData.summary.incapacities[0][e.detail[1]] = e.detail[0];
            } else {
				let dateOfIncapacityChanged = false;
				//let endDateOfIncapacityChanged = false;
				if (e.detail[1].includes('dateOfIncapacity')) {
					dateOfIncapacityChanged = true;
					// CLAIM-933 - Business decided to use the first section incapacity date to set the original incapacity date
					if (this.tabData.summary.incapacities[0].dateOfIncapacity !== null && this.tabData.summary.incapacities[0].dateOfIncapacity !== undefined) {
						let originalIncapacityDateFormatted = new Date(this.tabData.summary.incapacities[0].dateOfIncapacity).toISOString();
						this.tabData.summary.originalIncapacityDate = originalIncapacityDateFormatted;
						this.tabData.summary.incapacityDate = originalIncapacityDateFormatted;
					} else {
						this.tabData.summary.originalIncapacityDate = null;
						this.tabData.summary.incapacityDate = null;
						isOriginalIncapacityDateValid = false;
					}
				}

                let incapacityId = '';
				let incapacityName = '';
                if (e.detail[1].includes('icD10Code') === true) { 
                    incapacityId = e.detail[1].replace('icD10Code','');
                    incapacityName = 'icD10Code';
                } else {
                    incapacityId = e.detail[1].replace(/\D/g,''); // we're striping all non-digits in order to capture the Id. 
                    incapacityName = e.detail[1].replace(/[0-9]/g, ''); // we're striping all digits in order to capture the fieldName of the service product data. 
                }

                if (incapacityId != '0' && incapacityId.toString().includes('0000') === false) { // if this is already an existing incapacity coming from the webservice
                    for (let i=0; i<this.tabData.summary.incapacities.length; i++) {
                        if (this.tabData.summary.incapacities[i].productClaimIncapacityID == incapacityId) {
							if (dateOfIncapacityChanged) {
								let incapacityDate = new Date(this.tabData.summary.incapacities[i].dateOfIncapacity);
								if (incapacityDate.getTime() > this.today.getTime()) {
									isIncapacityDateValid = false;
								}
							}
							

                            this.tabData.summary.incapacities[i][incapacityName] = e.detail[0];
						}
					}
                } else {
                    let incapacitySectionExists = false;
                    for (let i=0; i<this.tabData.summary.incapacities.length; i++) {
                        if (this.tabData.summary.incapacities[i].productClaimIncapacityID == incapacityId) {
							if (dateOfIncapacityChanged) {
								let incapacityDate = new Date(this.tabData.summary.incapacities[i].dateOfIncapacity);
								if (incapacityDate.getTime() > this.today.getTime()) {
									isIncapacityDateValid = false;
								}
							}
							

                            this.tabData.summary.incapacities[i][incapacityName] = e.detail[0];
                            incapacitySectionExists = true;
                        }
					}
                    if (!incapacitySectionExists) {
                        this.tabData.summary.incapacities.push(this.incapacity);
                        this.tabData.summary.incapacities[this.tabData.summary.incapacities.length-1].productClaimIncapacityID = incapacityId; // we assign the temporary id which is beginning with '0000' in order to capture the updates for the already opened new incapacity section
                        this.tabData.summary.incapacities[this.tabData.summary.incapacities.length-1].toDelete = false;
                        this.tabData.summary.incapacities[this.tabData.summary.incapacities.length-1][incapacityName] = e.detail[0];
						if (dateOfIncapacityChanged) {
							let incapacityDate = new Date(e.detail[0]);
							if (incapacityDate.getTime() > this.today.getTime()) {
								isIncapacityDateValid = false;
							}
						}
						
                    }
                }
            }
        } else if (e.detail[1].includes('jobTitle') === true
                || e.detail[1].includes('employerName') === true
                || e.detail[1].includes('employmentType') === true
                || e.detail[1].includes('hoursWorked') === true
                || e.detail[1].includes('natureOfDuties') === true) {
            if (this.tabData.summary.occupations.length <= 0) {
                this.tabData.summary.occupations.push(this.occupation);
                this.tabData.summary.occupations[0].toDelete = false;
                this.tabData.summary.occupations[0][e.detail[1]] = e.detail[0];
            } else {
                let occupationId = e.detail[1].replace(/\D/g,''); // we're striping all non-digits in order to capture the Id. 
                let occupationName = e.detail[1].replace(/[0-9]/g, ''); // we're striping all digits in order to capture the fieldName of the service product data. 
                if (occupationId != '0' && occupationId.toString().includes('0000') === false) { // if this is already an existing job coming from the webservice
                    for(let i=0; i<this.tabData.summary.occupations.length; i++)
                        if(this.tabData.summary.occupations[i].productClaimOccupationID == occupationId)
                            this.tabData.summary.occupations[i][occupationName] = e.detail[0];
                } else {
                    let jobSectionExists = false;
                    for (let i=0; i<this.tabData.summary.occupations.length; i++) {
                        if (this.tabData.summary.occupations[i].productClaimOccupationID == occupationId) {
                            this.tabData.summary.occupations[i][occupationName] = e.detail[0];
                            jobSectionExists = true;
                        }
					}
                    if (!jobSectionExists) {
                        this.tabData.summary.occupations.push(this.occupation);
                        this.tabData.summary.occupations[this.tabData.summary.occupations.length-1].productClaimOccupationID = occupationId; // we assign the temporary id which is beginning with '0000' in order to capture the updates for the already opened new job section
                        this.tabData.summary.occupations[this.tabData.summary.occupations.length-1].toDelete = false;
                        this.tabData.summary.occupations[this.tabData.summary.occupations.length-1][occupationName] = e.detail[0];
                    }
                }
            }
        }

		if (this.nextActionDate == null && this.nextActionDate == undefined) {
			isNextActionDateValid = false;
		}

        // before sending the data to the service, let's restore the "id"s for the new job sections
        let data2Send = JSON.parse(JSON.stringify(this.tabData));
        for(let i=0; i<data2Send.summary.occupations.length; i++) {
            if(data2Send.summary.occupations[i].productClaimOccupationID.toString().includes('0000'))
                data2Send.summary.occupations[i].productClaimOccupationID = '0';
            if(data2Send.summary.occupations[i].toDelete === null)
                data2Send.summary.occupations[i].toDelete = false;
        }
        for(let i=0; i<data2Send.summary.incapacities.length; i++) {
            if(data2Send.summary.incapacities[i].productClaimIncapacityID.toString().includes('0000'))
                data2Send.summary.incapacities[i].productClaimIncapacityID = '0';
            if(data2Send.summary.incapacities[i].toDelete === null)
                data2Send.summary.incapacities[i].toDelete = false;
        }

       
       

		if (isNextActionDateValid && isIncapacityDateValid) {
			setProductData(data2Send);
			publish(this.messageContext, ProductClaimDirty__c, {
				componentName: 'Summary Tab'
			});

			this.wasSummaryDataValid = true; // Until the data is not correct for the first time, we dont need the method for hiding the 'save' button
		} else {
			let errorMsg = 'Date validations';
			if (!isNextActionDateValid) {
				errorMsg = 'Next action date cannot be blank!';
			} else if (!isIncapacityDateValid) {
				errorMsg = 'Incapacity date cannot be in the future!';
			} else if (!isOriginalIncapacityDateValid) {
				errorMsg = 'First incapacity date cannot be blank!';
			}
			this.dispatchEvent(
				new ShowToastEvent({
					title: 'Error',
					message: errorMsg,
					variant: 'error',
				}),
			);

			if (this.wasSummaryDataValid) {
				publish(this.messageContext, ProductClaimRefreshData__c, { componentName: 'Summary Tab' });
			}
		}
    }

    //method for getting this.s date for validation rule on CLAIMS-933 (Prevent entering Next action date in the past)
    todaysDate() {
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();
        today = mm + '/' + dd + '/' + yyyy;
        return today
    };

    //when a button is clicked on the summary tab --> this can be the 'delete' icon or any standalone button
    handleSummaryButtonClick(e) {
        var showSaveButton = true;
        if(e.detail[0] == 'New Earnings') {
            this.createJobSections([], true); // we're creating an empty job section on the existing layout
        }
        else if(e.detail[0] == 'New Incapacity') {
            showSaveButton = false;
            this.createIncapacitySections([], true); // we're creating an empty incapacity section on the existing layout
        }
        else if(e.detail[0] == 'Delete') {
            if(e.detail[2] == 'Incapacity') {
                showSaveButton = false;
                this.deleteIncapacity(e.detail[1]);
            }
            if(e.detail[2] == 'Job') {
                this.deleteJob(e.detail[1]);
            }
             
            
        }
        

        if(showSaveButton){
        setProductData(this.tabData);
        publish(this.messageContext, ProductClaimDirty__c, {
            componentName: 'Summary Tab'
        });
        }
    }

    //when we get the "save/cancel" message, we're refreshing the data
    handleRefreshMessage(message) {
        if (message.msg == 'Saved!') {
            // we update 'Next Action Date' separately as this is saved into Salesforce but not sent to the Claim Service
            const fields = {}; fields['Id'] = this.recordId; fields['New_Claim_Next_Action_Date__c'] = this.nextActionDate; const recordInput = {fields};
            if(this.nextActionDate) {
                updateRecord(recordInput)
                .then(() => {   
                    refreshApex(this.productClaimCase);
                    this.oldNextActionDate = this.nextActionDate;
                })
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Invalid Value',
                            message: 'For '+error.body.output.fieldErrors.New_Claim_Next_Action_Date__c[0].fieldLabel+', '+error.body.output.fieldErrors.Next_Action_Date__c[0].message,
                            variant: 'error'
                        })
                    );
                    this.nextActionDate = this.oldNextActionDate;
                    this.loadTheContent(true); // we do the refresh
                });  
            } else {
                this.nextActionDate = null;
            }
        } else if(message.msg == 'Cancelled!') {
            this.nextActionDate = this.oldNextActionDate;
		}

		if (message.msg == 'Failed!') {
            this.template.querySelector('c-form').validateData();
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: message.msgDetail,
                    variant: 'error',
					mode: 'pester'
                }),
            );
        } else {
            getProductData(this.claimExternalId).then(result => {
                this.tabData = result; 
                this.State.show();
                this.loadTheContent(true); // we do the refresh
            });
        }
    }
    
    /*****************
     * HELPER METHODS
     *****************/

    // for listening the "refresh" event, which is dispatched when a save/cancel action happens.
     subscribeToMessageChannel() {
        if (!this.subscription) {
            console.log("Mesto 2");
            this.subscription = subscribe(
                this.messageContext,
                ProductClaimRefreshData__c,
                (message) => this.handleRefreshMessage(message),
                { scope: APPLICATION_SCOPE }
            );
        }
    }

    // when the user deletes an existing incapacity
    deleteIncapacity(incapacityId) {
        for(let i=0; i<this.tabData.summary.incapacities.length; i++)
            if(this.tabData.summary.incapacities[i].productClaimIncapacityID == incapacityId)
                this.tabData.summary.incapacities[i].toDelete = true;
        this.loadTheContent(true);
    }
    
   

    // when the user deletes an existing job
    deleteJob(occupationId) {
        for(let i=0; i<this.tabData.summary.occupations.length; i++)
            if(this.tabData.summary.occupations[i].productClaimOccupationID == occupationId)
                this.tabData.summary.occupations[i].toDelete = true;
        this.loadTheContent(true);
    }

   /**
     * for creating empty (or with values) occupation section(s)
     * @param {Boolean} occupations List of the occupations, coming from the service
     * @param {Boolean} isNew If we're going to use this method in order to create an empty occupation section
     */
    createJobSections(occupations, isNew) {
        let layout = JSON.parse(JSON.stringify(JOB_LAYOUT_DATA));
        let tempName = '';
        if(!isNew) {
            if(occupations.length > 0) {
                for(let i=0; i<occupations.length; i++) 
                    if(occupations[i].toDelete == false || occupations[i].toDelete == null) {
                        layout.id = occupations[i].productClaimOccupationID;
                        layout.isDeletable = true;
                        layout.rows[0].fields[0].fieldName = 'jobTitle'+occupations[i].productClaimOccupationID;
                        layout.rows[0].fields[1].fieldName = 'employerName'+occupations[i].productClaimOccupationID;
                        layout.rows[1].fields[0].fieldName = 'employmentType'+occupations[i].productClaimOccupationID;
                        layout.rows[1].fields[1].fieldName = 'hoursWorked'+occupations[i].productClaimOccupationID;
                        layout.rows[2].fields[0].fieldName = 'natureOfDuties'+occupations[i].productClaimOccupationID;
                        this.layoutData[2].subSections.splice(0+i, 0, layout);
                        layout = JSON.parse(JSON.stringify(JOB_LAYOUT_DATA));
        
                        tempName = 'jobTitle'+occupations[i].productClaimOccupationID; this.formData[tempName] = occupations[i].jobTitle;
                        tempName = 'employerName'+occupations[i].productClaimOccupationID; this.formData[tempName] = occupations[i].employerName;
                        tempName = 'employmentType'+occupations[i].productClaimOccupationID; this.formData[tempName] = occupations[i].employmentType;
                        tempName = 'hoursWorked'+occupations[i].productClaimOccupationID; this.formData[tempName] = occupations[i].hoursWorked;
                        tempName = 'natureOfDuties'+occupations[i].productClaimOccupationID; this.formData[tempName] = occupations[i].natureOfDuties;
                        this.tabData.summary.occupations[i].toDelete = false; // as this job is on the screen, we default its toDelete value

                        this.numberOfNewJobs++;
                }
            }
            else {
                this.layoutData[2].subSections.splice(0, 0, layout); // we're just adding empty layout
                this.numberOfNewJobs++;
            }
        }
        else {
            this.formData['jobTitle0000'+this.numberOfNewJobs.toString()] = '';
            this.formData['employerName0000'+this.numberOfNewJobs.toString()] = '';
            this.formData['employmentType0000'+this.numberOfNewJobs.toString()] = '';
            this.formData['hoursWorked0000'+this.numberOfNewJobs.toString()] = '';
            this.formData['natureOfDuties0000'+this.numberOfNewJobs.toString()] = '';

            layout.id = '00'+this.numberOfNewJobs.toString();
            layout.isDeletable = false;
            layout.rows[0].fields[0].fieldName = 'jobTitle0000'+this.numberOfNewJobs.toString();
            layout.rows[0].fields[1].fieldName = 'employerName0000'+this.numberOfNewJobs.toString();
            layout.rows[1].fields[0].fieldName = 'employmentType0000'+this.numberOfNewJobs.toString();
            layout.rows[1].fields[1].fieldName = 'hoursWorked0000'+this.numberOfNewJobs.toString();
            layout.rows[2].fields[0].fieldName = 'natureOfDuties0000'+this.numberOfNewJobs.toString();

            this.layoutData[2].subSections.splice(0 + this.numberOfNewJobs, 0, layout);
            this.template.querySelector('c-form').rebuildLayout();
            this.numberOfNewJobs++;
        }
    }

    /**
     * for creating empty (or with values) incapacity section(s)
     * @param {Boolean} incapacities List of the incapacities, coming from the service
     * @param {Boolean} isNew If we're going to use this method in order to create an empty incapacity section
     */
    createIncapacitySections(incapacities, isNew) {
        let layout = JSON.parse(JSON.stringify(INCAPACITY_LAYOUT_DATA));
        console.log(">>> layout... "+layout.rows[0]);
        let tempName = '';
        if(!isNew) {
            if(incapacities.length > 0) {
                for(let i=0; i<incapacities.length; i++) 
                    if(incapacities[i].toDelete == false || incapacities[i].toDelete == null) {
                        layout.id = incapacities[i].productClaimIncapacityID;
                        layout.isDeletable = true;
                        layout.rows[0].fields[0].fieldName = 'icD10Code'+incapacities[i].productClaimIncapacityID;
                        layout.rows[0].fields[1].fieldName = 'causeOfIncapacity'+incapacities[i].productClaimIncapacityID;
                        layout.rows[1].fields[0].fieldName = 'dateOfIncapacity'+incapacities[i].productClaimIncapacityID;
						layout.rows[1].fields[1].fieldName = 'incapacityEndDate'+incapacities[i].productClaimIncapacityID;//newchange
						layout.rows[2].fields[0].fieldName = 'incapacityEndReason'+incapacities[i].productClaimIncapacityID;//newchange
                        this.layoutData[1].subSections.splice(1+i, 0, layout);
                        layout = JSON.parse(JSON.stringify(INCAPACITY_LAYOUT_DATA));
        
                        tempName = 'icD10Code'+incapacities[i].productClaimIncapacityID; this.formData[tempName] = incapacities[i].icD10Code;
                        tempName = 'causeOfIncapacity'+incapacities[i].productClaimIncapacityID; this.formData[tempName] = incapacities[i].causeOfIncapacity;
                        tempName = 'dateOfIncapacity'+incapacities[i].productClaimIncapacityID; this.formData[tempName] = incapacities[i].dateOfIncapacity;
						tempName = 'incapacityEndDate'+incapacities[i].productClaimIncapacityID; this.formData[tempName] = incapacities[i].incapacityEndDate;//newchange
						tempName = 'incapacityEndReason'+incapacities[i].productClaimIncapacityID; this.formData[tempName] = incapacities[i].incapacityEndReason; //newchange
                        this.tabData.summary.incapacities[i].toDelete = false; // as this incapacity is on the screen, we default its toDelete value

                        this.numberOfNewIncapacities++;
                    }
            }
            else {
                this.layoutData[1].subSections.splice(1, 0, layout); // we're just adding empty layout
                this.numberOfNewIncapacities++;
            }
        }
        else {
            this.formData['icD10Code0000'+this.numberOfNewIncapacities.toString()] = '';
            this.formData['causeOfIncapacity0000'+this.numberOfNewIncapacities.toString()] = '';
            this.formData['dateOfIncapacity0000'+this.numberOfNewIncapacities.toString()] = '';
            this.formData['incapacityEndDate0000'+this.numberOfNewIncapacities.toString()] = '';
            this.formData['incapacityEndReason0000'+this.numberOfNewIncapacities.toString()] = '';

            layout.id = '00'+this.numberOfNewIncapacities.toString();
            layout.isDeletable = false;
            layout.rows[0].fields[0].fieldName = 'icD10Code0000'+this.numberOfNewIncapacities.toString();
            layout.rows[0].fields[1].fieldName = 'causeOfIncapacity0000'+this.numberOfNewIncapacities.toString();
            layout.rows[1].fields[0].fieldName = 'dateOfIncapacity0000'+this.numberOfNewIncapacities.toString();
            layout.rows[1].fields[1].fieldName = 'incapacityEndDate0000'+this.numberOfNewIncapacities.toString();
            layout.rows[2].fields[0].fieldName = 'incapacityEndReason0000'+this.numberOfNewIncapacities.toString();

            this.layoutData[1].subSections.splice(1 + this.numberOfNewIncapacities, 0, layout);
            this.template.querySelector('c-form').rebuildLayout();
            console.log('TESTING 933');
            this.numberOfNewIncapacities++;
        }
    }
	
	/** BD
     * for creating empty (or with values) reviews section(s)
     * @param {Boolean} reviews List of the reviews, coming from the service
     * @param {Boolean} isNew If we're going to use this method in order to create an empty incapacity section
     */
    createReviewsSections(reviews, isNew) {
        let layout = JSON.parse(JSON.stringify(LAYOUT_DATA));
        let tempName = '';
        if(!isNew) {
            if(reviews.length > 0) {
                for(let i=0; i<reviews.length; i++) 
                    if(reviews[i].toDelete == false || reviews[i].toDelete == null) {
                        layout.id = reviews[i].productClaimReviewsID;
                        layout.isDeletable = true;
                        layout.rows[0].fields[0].fieldName = 'assessmentReviewPredictedEndDate'+reviews[i].productClaimReviewsID;
                        layout.rows[0].fields[1].fieldName = 'assessmentReviewDate'+reviews[i].productClaimReviewsID;
                        layout.rows[1].fields[0].fieldName = 'assessmentReviewActions'+reviews[i].productClaimReviewsID;
						layout.rows[2].fields[0].fieldName = 'assessmentReviewNotes'+reviews[i].productClaimReviewsID;//newchange
                        this.layoutData[1].subSections.splice(1+i, 0, layout);
                        layout = JSON.parse(JSON.stringify(LAYOUT_DATA));
        
                        tempName = 'assessmentReviewPredictedEndDate'+reviews[i].productClaimReviewsID; this.formData[tempName] = reviews[i].assessmentReviewPredictedEndDate;
                        tempName = 'assessmentReviewDate'+reviews[i].productClaimReviewsID; this.formData[tempName] = reviews[i].assessmentReviewDate;
                        tempName = 'assessmentReviewActions'+reviews[i].productClaimReviewsID; this.formData[tempName] = reviews[i].assessmentReviewActions;
						tempName = 'assessmentReviewNotes'+reviews[i].productClaimReviewsID; this.formData[tempName] = reviews[i].assessmentReviewNotes;//newchange
                        this.tabData.summary.reviews[i].toDelete = false; // as this incapacity is on the screen, we default its toDelete value

                        this.numberOfNewReviews++;
                    }
            }
            else {
                this.layoutData[1].subSections.splice(1, 0, layout); // we're just adding empty layout
                this.numberOfNewReviews++;
            }
        }
        else {
            this.formData['assessmentReviewPredictedEndDate0000'+this.numberOfNewReviews.toString()] = '';
            this.formData['assessmentReviewDate0000'+this.numberOfNewReviews.toString()] = '';
            this.formData['assessmentReviewActions0000'+this.numberOfNewReviews.toString()] = '';
            this.formData['assessmentReviewNotes0000'+this.numberOfNewReviews.toString()] = '';

            layout.id = '00'+this.numberOfNewReviews.toString();
            layout.isDeletable = false;
            layout.rows[0].fields[0].fieldName = 'assessmentReviewPredictedEndDate0000'+this.numberOfNewReviews.toString();
            layout.rows[0].fields[1].fieldName = 'assessmentReviewDate0000'+this.numberOfNewReviews.toString();
            layout.rows[1].fields[0].fieldName = 'assessmentReviewActions0000'+this.numberOfNewReviews.toString();
            layout.rows[1].fields[0].fieldName = 'assessmentReviewNotes0000'+this.numberOfNewReviews.toString();

            this.layoutData[1].subSections.splice(1 + this.numberOfNewReviews, 0, layout);
            this.template.querySelector('c-form').rebuildLayout();
            console.log('TESTING 933');
            this.numberOfNewReviews++;
        }
    } //BD*

    /**
     * @description Reads the selected categories in the web service data and puts them into an array for displaying it in the dual list component
     */
    getIncapacityCategories() {
        let arr = [];
        for(const property in this.tabData.summary.incapacityCategory) {
            if(this.tabData.summary.incapacityCategory[property] == true)
                arr.push(`${property}`);
        }
        return arr;
    }

    /**
     * @description We make all incapacity categories 'false'
     */
    falsifyIncapacityCategories() {
        for(const property in this.tabData.summary.incapacityCategory)
            this.tabData.summary.incapacityCategory[property] = false;
    }

    /**
     * @param {Boolean} isRefreshed True when refreshed, false on initial loading
     * @description this is for refreshing the data & the layout of the component's content
     */
    loadTheContent(isRefreshed) {
        this.layoutData = JSON.parse(JSON.stringify(LAYOUT_DATA));
        console.log('form data');
        console.log(JSON.stringify(this.formData));
        this.formData = {};
  
        this.createIncapacitySections(this.tabData.summary.incapacities, false);
        this.createJobSections(this.tabData.summary.occupations, false);
		//this.createReviewsSections(this.tabData.summary.reviews, false);

        this.formData.New_Claim_Next_Action_Date__c = this.nextActionDate;
        
        this.formData.importantNotes = this.tabData.summary.importantNotes;
        this.formData.reserve = this.tabData.summary.reserve;
        this.formData.riskScore = this.tabData.summary.riskScore;
        this.formData.originalIncapacityDate = this.tabData.summary.incapacities[0]?.dateOfIncapacity;
        this.formData.incapacityCategories = this.getIncapacityCategories();
        this.formData.websites = this.tabData.summary.websites;
        this.formData.bpsScoreName = this.tabData.summary.bpsScoreName;
        this.formData.bps = this.tabData.summary.bps;
        this.formData.bpsScore = this.tabData.summary.bpsScore;
        /*if (e.detail[0] === 'Low') {
            this.tabData.summary.bpsScore = 1;
        } else if (e.detail[0] === 'Medium') {
            this.tabData.summary.bpsScore = 2;
        } else {
            this.tabData.summary.bpsScore = 3;
        }*/
        this.formData.reinsurerName = this.tabReadOnlyData.summary.reinsurerName;
        this.formData.reinsurerPercentageRate = this.tabReadOnlyData.summary.reinsurerPercentageRate;
        this.formData.summaryNotes = this.tabData.summary.summaryNotes;
        this.formData.assessmentReviewActions = this.tabData.summary.assessmentReviewActions;
        this.formData.assessmentReviewPredictedEndDate = this.tabData.summary.assessmentReviewPredictedEndDate;
        this.formData.assessmentReviewDate = this.tabData.summary.assessmentReviewDate;
        this.formData.assessmentReviewNotes = this.tabData.summary.assessmentReviewNotes;
        

        if(isRefreshed) {
            setTimeout(() => {
                this.template.querySelector('c-form').rebuildLayout();
                this.template.querySelector('c-form').syncFields();
            }, 500);
        }
    }
}