export const INCAPACITY_LAYOUT_DATA = {
    id: 'incapacity-repeating',
    columns: 2,
    style: 'border: 2px #E3E3E3 solid; margin: 10px 0px 10px 15px; width:95%; padding-bottom:5px; padding-top:3px;',
    isDeletable: false,
    rows: [
        {
            fields: [
                {
                    label: 'ICD-10 code',
                    fieldName: 'icD10Code',
                    fieldType: 'Text',
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none;',
                    isEditable: true
                },
                {
                    label: 'Cause of Incapacity',
                    fieldName: 'causeOfIncapacity',
                    fieldType: 'Text',
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none;',
                    isEditable: true
                }
            ]
        },
        {
            fields: [
                {
                    label: 'Date of Incapacity',
                    fieldName: 'dateOfIncapacity',
                    fieldType: 'Date',
                    style: 'margin-top: -20px; width:50%;',
                    isEditable: true,
                    formElementStyle: 'border-bottom:none;',
                    fieldTypeAttributes: {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                    }
                },
                {
                    label: 'End Date of Incapacity',
                    fieldName: 'incapacityEndDate',
                    fieldType: 'Date',
                    style: 'margin-top: -20px; width:50%;',
                    isEditable: true,
                    formElementStyle: 'border-bottom:none;',
                    fieldTypeAttributes: {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                    }
                }
            ]
        },
        {
            fields: [
                {
                    label: 'Incapacity End Reason',
                    fieldName: 'incapacityEndReason',
                    fieldType: 'Picklist',
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none;',
                    isEditable: true,
					options: [
                        {label: 'Death', value: 'death'},
                        {label: 'End of cover period', value: 'endofcoverperiod'},
                        {label: 'End of cover term', value: 'endofcoverterm'},
                        {label: 'Failed to engage', value: 'faiedtoengage'},
                        {label: 'No longer meets incapacity definition ', value: 'nolongermeets'},
						{label: 'Returned to work (Rehab)', value: 'returnedtoworkrehab'},
                        {label: 'Retuned to work (no rehab)', value: 'returnedtoworknorehab'}
                    ]
                }
            ]
        }
        
    ]
}