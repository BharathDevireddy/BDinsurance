import {LightningElement, api} from 'lwc';

const EXPANDABLE_CLASS = 'expandable';
const NON_EXPANDABLE_CLASS = 'non-expandable';

export default class ExpandableSection extends LightningElement {

    @api
    title = '';
    @api
    expandable = false;
    @api
    expanded = false;

    get buttonClass() {
        return 'slds-button slds-section__title-action header-layout slds-p-bottom_xxx-small '.concat(this.expandable ? EXPANDABLE_CLASS : NON_EXPANDABLE_CLASS);
    }

    get sectionClass() {
        return this.expanded ? 'slds-section slds-m-around_none slds-is-open' : 'slds-section slds-m-around_none';
    }

    @api
    expand() {
        this.expanded = true;
    }

    @api
    collapse() {
        this.expanded = false;
    }

    onSectionClick() {
        if (this.expandable) {
            this.expanded = !this.expanded;
        }
    }

}