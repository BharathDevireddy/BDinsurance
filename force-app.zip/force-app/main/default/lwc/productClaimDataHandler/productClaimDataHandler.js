import updateProductClaim from "@salesforce/apex/ClaimsDataHandler_LEx.updateProductClaim";
import fetchProductClaimView from "@salesforce/apex/ClaimsDataHandler_LEx.fetchProductClaimView";
import calculateProductClaimDraft from '@salesforce/apex/ClaimsDataHandler_LEx.calculateProductClaimDraft';
import fetchContinuingIncomeTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchContinuingIncomeTypes";
import fetchMisRepTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchMisRepTypes";
import fetchMisRepCatTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchMisRepCatTypes";
import fetchMisRepRetro from "@salesforce/apex/ClaimsDataHandler_LEx.fetchMisRepRetro";
import fetchCalculationTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchCalculationTypes";
import fetchDecisionTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchDecisionTypes";
import fetchDecisionSubTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchDecisionSubTypes";

import { callApex } from 'c/utility';

var productData = null;
var productDataReadOnly = null;
var originalProductData = null;

var recordClaimExternalId;

export async function getInitialPayLoad(productClaimId) {
    var res;
    await fetchProductClaimView({ pProductClaimId: productClaimId }).then(result => {
        var modifiedData = productData;
        productData = originalProductData = Object.assign(JSON.parse(result.productDataUpdate),productData);
        productData = Object.assign(productData, modifiedData);
        productDataReadOnly = JSON.parse(result.productDataReadOnly);
        result['productDataUpdate'] = JSON.stringify(productData);
        console.log('init');
        console.log(JSON.stringify(result));
        res = result;
    });
    return res;
}

export async function getProductData(productClaimId) {
    if (productData == null) {
        await fetchProductClaimView({ pProductClaimId: productClaimId }).then(result => {
            productData = originalProductData = JSON.parse(result.productDataUpdate);
        });
    }
    return productData;
}

export async function getContinuingIncomeTypes(){
    var continuingIncomeTypes;
        await fetchContinuingIncomeTypes().then(result => {
            continuingIncomeTypes = result;
        });
    return continuingIncomeTypes;
}

export async function getMisRepTypes(){
    var misRepTypes;
        await fetchMisRepTypes().then(result => {
            misRepTypes = result;
        });
    return misRepTypes;
}

export async function getMisRepCatTypes(){
    var misRepCatTypes;
        await fetchMisRepCatTypes().then(result => {
            misRepCatTypes = result;
        });
    return misRepCatTypes;
}

export async function getMisRepRetro(){
    var misRepRetro;
        await fetchMisRepRetro().then(result => {
            misRepRetro = result;
        });
    return misRepRetro;
}

export async function getCalculationTypes(){
    var calculationTypes;
        await fetchCalculationTypes().then(result => {
            calculationTypes = result;
        });
    return calculationTypes;
}

export async function getDecisionTypes(){
    var decisionTypes;
        await fetchDecisionTypes().then(result => {
            decisionTypes = result;
        });
    return decisionTypes;
}

export async function getDecisionSubTypes(decisionTypeId){
    var decisionSubTypes;
        await fetchDecisionSubTypes({decisionTypeId : decisionTypeId}).then(result => {
            decisionSubTypes = result;
        });
    return decisionSubTypes;
}

export async function getProductReadOnlyData(productClaimId) {
    if (productDataReadOnly == null) {
        await fetchProductClaimView({ pProductClaimId: productClaimId }).then(result => {
            productDataReadOnly = JSON.parse(result.productDataReadOnly);
        });
    }
    return productDataReadOnly;
}

export function setProductData(summaryTabData) {
    console.log('summaryTabData');
    console.log(JSON.stringify(summaryTabData));
    productData = Object.assign(productData, summaryTabData);
}

export function getUnsavedProductData(){
    if(productData != null)
        return productData;
}

export function cancelSave() {
    productData = JSON.parse(JSON.stringify(originalProductData));
}

export function saveProductData(productClaimId) {
    console.log('saving');
    console.log(JSON.stringify(productData));
    originalProductData = JSON.parse(JSON.stringify(productData));
    return callApex(
        updateProductClaim,
            {
                pProductClaimRef: productClaimId,
                pProductData: JSON.stringify(productData)
            },
            'SaveProductData' + productClaimId,
    );
}

export function calculateProductClaimDraftData(productClaimId) {
    return callApex(
        calculateProductClaimDraft,
        {
            pRecordId: productClaimId
        },
        'CalculateProductClaimDraft' + productClaimId,
    );
}

export async function addNewExpenseOnProductClaim(productClaimId, expenseData){
    console.log('productClaimId '+productClaimId);
    var response;
        await createNewProductClaimExpense({ pProductClaimRef: productClaimId,pProductData: expenseData }).then(result => {
            response = result;
        });
    return response;
}

export async function deleteExpenseOnProductClaim(expenseID){
    console.log('expenseID '+expenseID);
    var response;
        await deleteProductClaimExpense({ expenseID: expenseID}).then(result => {
            response = result;
        });
    return response;
}

export async function addNewHospitalBenefitOnProductClaim(productClaimId, hospitalBenefitData){
    console.log('productClaimId '+productClaimId);
    var response;
        await createNewProductClaimhospitalBenefit({ pProductClaimRef: productClaimId,pProductData: hospitalBenefitData }).then(result => {
            response = result;
        });
    return response;
}

export async function deleteHospitalBenefitOnProductClaim(expenseID){
    console.log('expenseID '+expenseID);
    var response;
        await deleteProductClaimHospitalBenefit({ expenseID: expenseID}).then(result => {
            response = result;
        });
    return response;
}