import { LightningElement, track, api } from 'lwc';
//import { addNewExpenseOnProductClaim } from 'c/productClaimDataHandler';
//constants
import { EXPENSE_TYPE, EXPENSE_TYPE_INVESTIGATIVE,EXPENSE_TYPE_MEDICAL,EXPENSE_TYPE_REHABILITATION,EXPENSE_TYPE_OTHER } from './constants';


export default class ProductClaimExpenseForm extends LightningElement {

    @api claimExternalId;
    @api tabReadOnlyData;
    expense = {};

    @track expense_type_options = EXPENSE_TYPE;
    @track description_options;
    modalVisible = false;

    // if:true values
    @track showNewExpenseForm = false;
    @track disableButton = false;

    //for disabled button on description
    //@track disableDescription = true;

    connectedCallback(){
        console.log('EXPENSE FORM DATA  '+JSON.stringify(this.tabReadOnlyData));
    }

    addNewExpense(event){
        this.showNewExpenseForm = true;
        this.disableButton = true;
    }

    onExpenseTypeChange(event){
        /*console.log('value '+event.detail.value);
        if(event.detail.value === 'Investigative'){
            this.description_options = EXPENSE_TYPE_INVESTIGATIVE;
        }else if(event.detail.value === 'Medical'){
            this.description_options = EXPENSE_TYPE_MEDICAL;
        }else if(event.detail.value === 'Rehabilitation'){
            this.description_options = EXPENSE_TYPE_REHABILITATION;
        }else if(event.detail.value === 'Other'){
            this.description_options = EXPENSE_TYPE_OTHER;
        }*/
        //this.disableDescription = false;
    }

    onUpdate(event){
       /* addNewExpenseOnProductClaim(this.claimExternalId).then(result => {
            console.log('pozvao sam eksterni servis');
        });*/
    }
    @api
    showModal(data) {
        console.log('show modal '+JSON.stringify(data));
        this.expense = data;
        this.modalVisible = true;
    }

    @api
    closeModal() {
        this.modalVisible = false;
    }
}