import { LightningElement, api } from 'lwc';

import ClaimsComponents_Error_Prefix from '@salesforce/label/c.ClaimsComponents_Error_Prefix';

export default class LoadWrapper extends LightningElement {

    errorPrefix = ClaimsComponents_Error_Prefix;

    @api isLoading = false;
    @api errorMessage;

}