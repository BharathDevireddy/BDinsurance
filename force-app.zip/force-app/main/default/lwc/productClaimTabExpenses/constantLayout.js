export const LAYOUT_DATA = [
    {
        id: 1,
        collapsible: true,
        heading: 'Expenses',
        headingStyle: 'margin-left:20px; width:95%;',
        useHading: true,
        subSections:[
            {
                id: 0,
                columns: 1,
                isDeletable: false,
                style: 'margin-bottom:30px; margin-left: 15px;',
                rows:[
                    {
                        fields: [
                            {
                                label: 'Expense Date',
                                fieldName: 'expenseDate',
                                fieldType: 'Date',
                                style: 'margin-top: -20px; width: 50%;',
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; padding-top:10px; margin-left:15px;',
                                fieldTypeAttributes: {
                                    day: '2-digit',
                                    month: '2-digit',
                                    year: 'numeric'
                                }
                            },
                            {
                                label: 'Expense Type',
                                fieldName: 'productClaimExpenseType',
                                fieldType: 'Picklist',
                                style: 'margin-top: -20px; width: 98%;',
                                isEditable: true,
                                options: [
                                    {label: 'Please Select', value: 'unselected'},
                                    {label: 'Investigative', value: 'Investigative'},
                                    {label: 'Medical', value: 'Medical'},
                                    {label: 'Rehabilitation', value: 'Rehabilitation'},
                                    {label: 'Other', value: 'Other'}
                                ],
                                formElementStyle: 'border-bottom:none;'
                            },
                            {
                                label: 'Description',
                                fieldName: 'description',
                                fieldType: 'Picklist',
                                style: 'margin-top: -20px; width: 98%;',
                                isEditable: true,
                                options: [
                                    {label: '1', value: '1'},
                                    {label: '2', value: '2'}
                                ],
                                formElementStyle: 'border-bottom:none;'
                            }
                        ]
                    },
                ]
            }
        ]
    }
]