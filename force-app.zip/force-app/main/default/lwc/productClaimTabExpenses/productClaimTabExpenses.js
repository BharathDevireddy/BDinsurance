import { LightningElement, api, track } from 'lwc';
import { addNewExpenseOnProductClaim,getInitialPayLoad, deleteExpenseOnProductClaim} from 'c/productClaimDataHandler';

//constants
import { LAYOUT_DATA } from './constantLayout.js';
import { EXPENSE_OBJECT,COLUMNS, EXPENSE_TYPE, EXPENSE_TYPE_INVESTIGATIVE,EXPENSE_TYPE_MEDICAL,EXPENSE_TYPE_REHABILITATION,EXPENSE_TYPE_OTHER } from './constants';

export default class ProductClaimTabExpenses extends LightningElement {
    @track expenseData = {};
    //@track layoutData = {};
   // @track tabData = {};
    @track tabReadOnlyData = {};
    @track columns = COLUMNS;
    @track expense_type_options = EXPENSE_TYPE;
    @track description_options;

    @api claimExternalId;
    @api recordId;

    // if:true values
    @track showNewExpenseForm = false;
    @track disableButton = false;
    @track disableDescription = true;

    connectedCallback(){
        //this.expenseData = EXPENSE_OBJECT;
        this.invokeApexMethods();
    }

    async invokeApexMethods(){
        let result;
        try{
            result = await getInitialPayLoad(this.claimExternalId);
        } catch(e){
            console.log(e.message);
        }
        finally{
            //this.tabData = JSON.parse(result.productDataUpdate);
            this.tabReadOnlyData = JSON.parse(result.productDataReadOnly);
        }
    }

    handleExpenseDataChange(e){

        if(e.target.name == 'expenseDate' )
        {
           this.expenseData.expenseDate = e.target.value;
        }
        else if(e.target.name== 'productClaimExpenseType' )
        {
            this.expenseData.productClaimExpenseType = e.target.value;
        }
        else if(e.target.name== 'description' )
        {
            this.expenseData.description = e.target.value;
        }
        else if(e.target.name== 'maximumAmountPermitted' )
        {
            this.expenseData.maximumAmountPermitted = parseInt(e.target.value);
        }
        else if(e.target.name== 'amount' )
        {
            this.expenseData.amount = parseInt(e.target.value);
        }
        else if(e.target.name== 'amountReclaimable' )
        {
            this.expenseData.amountReclaimable = parseInt(e.target.value);
        }
        else if(e.target.name== 'payee' )
        {
            this.expenseData.payee = e.target.value;
        }
        else if(e.target.name== 'invoiceNumber' )
        {
            this.expenseData.invoiceNumber = e.target.value;
        }
        else if(e.target.name== 'financeNotificationDate' )
        {
            this.expenseData.financeNotificationDate = Date.parse(e.target.value);
        }
        else if(e.target.name== 'additionalInformation' )
        {
            this.expenseData.additionalInformation = e.target.value;
        }

        console.log(JSON.stringify(this.expenseData));
    }


    // for listening the "refresh" event, which is dispatched when a save/cancel action happens.
   /* subscribeToMessageChannel() {
        if (!this.subscription) {
            this.subscription = subscribe(
                this.messageContext,
                ProductClaimRefreshData__c,
                (message) => this.handleRefreshMessage(message),
                { scope: APPLICATION_SCOPE }
            );
        }
    }*/

    addNewExpense(event){
        this.showNewExpenseForm = true;
        this.disableButton = true;
    }

    onExpenseTypeChange(event){
        console.log('value '+event.detail.value);
        if(event.detail.value === 'Investigative'){
            this.description_options = EXPENSE_TYPE_INVESTIGATIVE;
        }else if(event.detail.value === 'Medical'){
            this.description_options = EXPENSE_TYPE_MEDICAL;
        }else if(event.detail.value === 'Rehabilitation'){
            this.description_options = EXPENSE_TYPE_REHABILITATION;
        }else if(event.detail.value === 'Other'){
            this.description_options = EXPENSE_TYPE_OTHER;
        }
        this.disableDescription = false;
    }

    onSave(event){
        console.log('expense data '+this.expenseData);
        addNewExpenseOnProductClaim(this.claimExternalId,JSON.stringify(this.expenseData)).then(result => {
            console.log('pozvao sam eksterni servis');
        });
        this.showNewExpenseForm = false;
        this.disableButton = false;
        invokeApexMethods();
        //this.expenseData = [];
        
    }

    handleRowAction(event){
        if(event.detail.action.name === 'preview'){
            this.template.querySelector("[data-id='productClaimExpenseForm']").showModal(event.detail.row);
           // this.showNewExpenseForm = true;
            console.log('event.detail.row '+JSON.stringify(event.detail.row));
        }
        else if(event.detail.action.name === 'delete')
        {
            if (confirm("Do you want to delete this expense?") == true) {
                console.log('ExpenseID '+ event.detail.row.productClaimExpenseID);
                deleteExpenseOnProductClaim(event.detail.row.productClaimExpenseID).then(result => {
                    console.log('delete service called');
                });
              }
        }
    }
}