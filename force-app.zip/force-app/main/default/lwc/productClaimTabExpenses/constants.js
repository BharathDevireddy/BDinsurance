export const COLUMNS = [
  {
    label: 'Detail view',
    type: 'button-icon',
    fixedWidth: 90,
    typeAttributes:
    {
      iconName: 'utility:preview',
      name: 'preview'
    }
  },
  {
    label: 'Expense ID', fieldName: 'productClaimExpenseID', type: 'text',
    typeAttributes: { linkify: true }
  },
  { label: 'Expense Type', fieldName: 'productClaimExpenseType' },
  { label: 'Description', fieldName: 'description' },
  { label: 'Amount', fieldName: 'amount' },
  { label: 'Payee', fieldName: 'payee' },
  { label: 'Approval  Date', fieldName: 'expenseDate' },
  {
    label: 'Delete',
    type: 'button-icon',
    fixedWidth: 90,
    typeAttributes:
    {
      iconName: 'utility:delete',
      name: 'delete'
    }
  }
];

export const EXPENSE_TYPE = [
  { label: 'Investigative', value: 'Investigative' },
  { label: 'Medical', value: 'Medical' },
  { label: 'Rehabilitation', value: 'Rehabilitation' },
  { label: 'Other', value: 'Other' }
]

export const EXPENSE_TYPE_INVESTIGATIVE = [
  { label: 'Desk Top Enquiries', value: 'Desk Top Enquiries' },
  { label: 'Forensic Accounting', value: 'Forensic Accounting' },
  { label: 'Interview', value: 'Interview' },
  { label: 'PI', value: 'PI' },
  { label: 'Surveillance', value: 'Surveillance' },
  { label: 'Other', value: 'Other' }
]

export const EXPENSE_TYPE_MEDICAL = [
  { label: 'Consultant Reports', value: 'Consultant Reports' },
  { label: 'GP Reports / Records', value: 'GP Reports / Records' },
  { label: 'Functional Capacity Evaluation', value: 'Functional Capacity Evaluation' },
  { label: 'Independent Medical Examination', value: 'Independent Medical Examination' },
  { label: 'Other Medical Specialist', value: 'Other Medical Specialist' },
  { label: 'Desktop Review of Medical Evidence', value: 'Desktop Review of Medical Evidence' }
]

export const EXPENSE_TYPE_REHABILITATION = [
  { label: 'Initial Assessment', value: 'Initial Assessment' },
  { label: 'In Claim Assessment Review', value: 'In Claim Assessment Review' },
  { label: 'Rehab - Combined Treatment & Vocational', value: 'Rehab - Combined Treatment & Vocational' },
  { label: 'Rehab - Treatment ', value: 'Rehab - Treatment ' },
  { label: 'Rehab - Vocationa', value: 'Rehab - Vocationa' },
  { label: 'Treatment funding', value: 'Treatment funding' }
]

export const EXPENSE_TYPE_OTHER = [
  { label: 'Accountant', value: 'Accountant' },
  { label: 'Legal', value: 'Legal' },
  { label: 'Policyholder - expense', value: 'Policyholder - expense' },
  { label: 'Policyholder - HALO', value: 'Policyholder - HALO' },
  { label: 'Other', value: 'Other' }
]

export const EXPENSE_OBJECT = [
  { label: 'productClaimExpenseDescription', value: '' },
  { label: 'maximumAmountPermitted', value: 0 },
  { label: 'amount', value: 0 },
  { label: 'amountReclaimable', value: 0 },
  { label: 'additionalInformation', value: '' },
  { label: 'payee', value: '' },
  { label: 'invoiceNumber', value: '' },
  { label: 'descriptione', value: '' },
  { label: 'salesForceCaseNumber', value: '' },
  { label: 'financeNotificationDate', value: '' },
  { label: 'expenseDate', value: '' }
]