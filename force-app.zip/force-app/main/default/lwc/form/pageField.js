const VIEW_ELEMENT_CLASSES = 'slds-form-element slds-form-element_edit slds-form-element_readonly slds-form-element_stacked slds-hint-parent';
const EDIT_ELEMENT_CLASSES = 'slds-form-element slds-form-element_stacked slds-is-editing';

const TYPE_TEXT = 'Text';
const TYPE_DATE = 'Date';
const TYPE_DATETIME = 'DateTime';
const TYPE_NUMBER = 'Number';
const TYPE_CURRENCY = 'Currency';
const TYPE_PERCENTAGE = 'Percentage';
const TYPE_CHECKBOX = 'CheckBox';
const TYPE_TEXTAREA = 'TextArea';
const TYPE_RICHTEXTAREA = 'RichTextArea';
const TYPE_PICKLIST = 'Picklist';
const TYPE_DUALLIST = 'DualList';
const TYPE_DATATABLE = 'DataTable';
const TYPE_BUTTON = 'Button';

/**
 * Wrapper for fields to allow for dynamic getters and method calls
 * when looping over fields in HTML
 */
export default class PageField {

    get ElementClass() { return `${this.IsEditStage ? EDIT_ELEMENT_CLASSES : VIEW_ELEMENT_CLASSES} ${this.Size == 1 ? 'slds-form-element_1-col' : ''}`; }
    get Value() { return this.Parent.Parent.formData[this.FieldName]; }

    get IsText() { return this.FieldType == null || this.FieldType == TYPE_TEXT; }
    get IsNumber() { return this.FieldType == TYPE_NUMBER; }
    get IsCurrency() { return this.FieldType == TYPE_CURRENCY; }
    get IsPercentage() { return this.FieldType == TYPE_PERCENTAGE; }
    get IsDate() { return this.FieldType == TYPE_DATE; }
    get IsDateTime() { return this.FieldType == TYPE_DATETIME; }
    get IsCheckBox() { return this.FieldType == TYPE_CHECKBOX; }
    get IsTextArea() { return this.FieldType == TYPE_TEXTAREA; }
    get IsRichTextArea() {return this.FieldType == TYPE_RICHTEXTAREA; }
    get IsPickList() {return this.FieldType == TYPE_PICKLIST; }
    get IsDualList() {return this.FieldType == TYPE_DUALLIST; }
    get IsDataTable() {return this.FieldType == TYPE_DATATABLE; }
    get IsButton() {return this.FieldType == TYPE_BUTTON; }
    get IsVisible() { return this.Parent.Parent.hiddenFields.indexOf(this.FieldName) == -1; }

    /**
     *
     * @param {PageSection} pParent Parent Section
     * @param {Integer} pSize Size of field (1 or 2), which dictates width
     * @param {Object} pData Field Data
     * @param {String} pData.label Field Label
     * @param {String} pData.internalLabel Field Internal Label --> used only for dual list; for resolving its label's css-design problem
     * @param {String} pData.fieldName Field Name found on `this.Parent.Parent.formData`
     * @param {String} pData.fieldType Type of field (e.g Text, Number)
     * @param {String} pData.style Custom inline style for the field
     * @param {String} pData.formElementStyle Custom inline style for the field's grandgrandparent "slds-form-element" div 
     * @param {String} pData.formElementControlStyle Custom inline style for the field's grandparent "slds-form-element__control" div 
     * @param {String} pData.formElementStaticStyle Custom inline style for the field's parent "slds-form-element__static" div 
     * @param {Object[]} pData.options Option list for combobox/duallist options
     * @param {Object[]} pData.columns Columns for datatable
     * @param {Object[]} pData.tableData Data for datatable
     * @param {Object} pData.fieldTypeAttributes Type of field (e.g Text, Number)
     * @param {Boolean} pData.isBlank Is this a blank field?
     * @param {Boolean} pData.isEditable Is this a editable field?
     */
    constructor(pParent, pSize, pData) {
        this.Parent = pParent;
        this.Id = this.Parent.Index++;
        this.Label = pData.label;
        this.InternalLabel = pData.internalLabel;
        this.FieldName = pData.fieldName;
        this.FieldType = pData.fieldType || TYPE_TEXT;
        this.Style = pData.style;
        this.FormElementStyle = pData.formElementStyle;
        this.FormElementControlStyle = pData.formElementControlStyle;
        this.FormElementStaticStyle = pData.formElementStaticStyle;
        this.HeadingStyle = pData.headingStyle;
        this.FieldTypeAttributes = pData.fieldTypeAttributes || {};
        this.Options = pData.options || {};
        this.Columns = pData.columns || {};
        this.TableData = pData.tableData || {};
        this.Size = pSize;
        this.IsBlank = pData.isBlank || false;
        this.IsEditable = pData.isEditable || false;
    }
}