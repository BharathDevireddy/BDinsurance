//LWC Imports
import { LightningElement, api, track } from 'lwc';

//Apex Imports
import fetchFormConditionalMetadata from '@salesforce/apex/Form_LEx.fetchFormConditionalMetadata';

//Component imports
import { getErrorMessage } from 'c/utility';

//Internal Imports
import PageSection from './pageSection';

//Salesforce Imports
import Field_Name_to_Hide__c from '@salesforce/schema/Form_Conditional_Field__c.Field_Name_to_Hide__c';
import Controlling_Field_Name__c from '@salesforce/schema/Form_Conditional_Field__c.Controlling_Field_Name__c';
import Criteria__c from '@salesforce/schema/Form_Conditional_Field__c.Criteria__c';
import Conditional_Logic__c from '@salesforce/schema/Form_Conditional_Field__c.Conditional_Logic__c';

//Constants
const ERROR_METADATA_WHITESPACE_FIELD_TO_HIDE = `${Field_Name_to_Hide__c.fieldApiName} should not contain whitespace`;
const ERROR_METADATA_WHITESPACE_DEPENDANT_FIELD = `${Controlling_Field_Name__c.fieldApiName} should not contain whitespace`;

const OPERATOR_LIST_AND = 'AND';
const OPERATOR_LIST_OR = 'OR';
const OPERATOR_SINGLE_EQUALS = 'EQUALS';
const OPERATOR_SINGLE_NOT_EQUALS = 'NOT EQUALS';
const OPERATOR_SINGLE_LESS_THAN = 'LESS THAN';
const OPERATOR_SINGLE_LESS_THAN_EQUAL = 'LESS THAN EQUAL';
const OPERATOR_SINGLE_MORE_THAN = 'MORE THAN';
const OPERATOR_SINGLE_MORE_THAN_EQUAL = 'MORE THAN EQUAL';

const OPERATOR_SIGN_MAP = {
    '==': OPERATOR_SINGLE_EQUALS,
    '!=': OPERATOR_SINGLE_NOT_EQUALS,
    '<': OPERATOR_SINGLE_LESS_THAN,
    '<=': OPERATOR_SINGLE_LESS_THAN_EQUAL,
    '>': OPERATOR_SINGLE_MORE_THAN,
    '>=': OPERATOR_SINGLE_MORE_THAN_EQUAL
};

/**
 * A Form that takes in a set of fields and renders it based on the Salesforce
 * form view.
 */
export default class Form extends LightningElement {

    /*=========================================================
           Vars
    =========================================================*/

    @api identifier; //TODO: Add Conditional logic using identifier
    @api layoutData; // Array of sections, containing an array of rows, containing 1/2 fields
    @api formData; // Object of data, being accessed by data[fieldName];

    @track isLoading = true;
    @track errorMessage;
    @track hiddenFields = []; //List of FieldNames
    @track sections = [];

    /*=========================================================
           Setup
    =========================================================*/

    /**
     * Once connected, create sections and initialise hidden fields
     */
    async connectedCallback() {
        try {
            await Promise.all([
                this.buildLayout(),
                this.buildHiddenFields()
            ]);
        } catch(ex) {
            console.error(ex);
            this.errorMessage = getErrorMessage(ex);
        } finally {
            this.isLoading = false;
        }
    }

    /**
     * Builds the sections for the form based on the given API inputs
     */
    async buildLayout() {
        if(this.layoutData) {
            let index = 0;
            for(let layoutSection of this.layoutData) {
                let section = new PageSection(this, index++, layoutSection, false);
                this.sections.push(section);
            }
        }
    }

    /**
     * For rebuilding the layout with a refreshed layout component
     */
    @api rebuildLayout() {
        let sectionInitialSize = this.sections.length;
        let initialId = this.makeId(sectionInitialSize); // we need random Ids for the sections in order to preserve the functionality on layout updates
        if(this.layoutData) {
            let index = 0;
            for(let layoutSection of this.layoutData) {

                //in order to preserve previous collapse status
                let isCollapsed = false;
                for(let i=0; i<sectionInitialSize; i++)
                    if(this.sections[i].id == layoutSection.id && this.sections[i].Heading == layoutSection.heading)
                        isCollapsed = this.sections[i].IsCollapsed;

                let section = new PageSection(this, initialId+(index++).toString(), layoutSection, isCollapsed);
                this.sections.push(section);
            }
            this.sections.splice(0,sectionInitialSize); // we're removing the initial old elements to prevent duplicate sections
            this.rerender();
        }
    }

    /**
     * If an identifier is specified for this form, then grab any metadata for it
     * and create filters, and check against any dependent fields using it to know
     * if we should hide any fields
     */
    async buildHiddenFields() {
        //Check for indentifier, we need one for conditional data to work
        if(this.identifier) {
            //Grab conditional metadata from apex
            let conditionalMetadata = await fetchFormConditionalMetadata({pIdentifier: this.identifier});
            if(conditionalMetadata && conditionalMetadata.length > 0) {
                //Loop over the metadata, validate that it's valid, then build a filter from it, then hide fields
                for(let metadata of conditionalMetadata) {
                    if(this.validateMetadata(metadata)) {
                        let filter = this.buildFilterFromMetadata(metadata);
                        //Check for Validity
                        if(this.checkValueAgainstFilter(this.formData[metadata[Controlling_Field_Name__c.fieldApiName]], filter)) {
                            this.hiddenFields = [...this.hiddenFields, ...metadata[Field_Name_to_Hide__c.fieldApiName].split(',')];
                        }
                    }
                }
            }
        }
    }

    /*=========================================================
           Helpers
    =========================================================*/

    /**
     *
     * @param {Integer} length : The length of the Id we want
     * @returns randomId : The randomId produced
     */
    makeId(length) {
        var result           = '';
        var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for ( var i = 0; i < length; i++ ) { result += characters.charAt(Math.floor(Math.random() * charactersLength)); }
        return result;
    }

    /**
     *
     * @param {Array} _array1 : 1st array
     * @param {Array} _array2 : 2nd array
     * @returns Boolean : "true" if the arrays are equal, "false" if they are not
     */
    areArraysEquals(_array1, _array2)
    {
        if (_array1 == null || _array2 == null) return false;
        if (_array1.length !== _array2.length) return false;
        _array1.sort(); _array2.sort();
        for (var i = 0; i < _array1.length; ++i)
            if (_array1[i] !== _array2[i])
                return false;
        return true;
    }

    /**
     * Runs some validation checks to make sure we can understand the given metadata. Any errors are
     * thrown and should be caught in a catch block and handled there.
     * @param {Object} pMetadata Form_Conditional_Field__mdt SObject
     * @returns {Boolean} True if valid metadata, false otherwise
     */
    validateMetadata(pMetadata) {
        if(/\s/g.test(pMetadata[Field_Name_to_Hide__c.fieldApiName])) throw new Error(ERROR_METADATA_WHITESPACE_FIELD_TO_HIDE);
        else if(/\s/g.test(pMetadata[Controlling_Field_Name__c.fieldApiName])) throw new Error(ERROR_METADATA_WHITESPACE_DEPENDANT_FIELD);
        else return true;
    }

    /**
     * Builds a filter object from the given metadata. The idea here is to build a filter engine that
     * compares values using different operators with different levels of grouping (e.g 1 AND 2 OR 3 AND 4)
     * which this filter structure lets us do.
     * The output should be used in tandem with `checkValueAgainstFilter`
     * @param {Object} pMetadata Form_Conditional_Field__mdt SObject
     * @returns {Object} Parsed fiter object containing an Operator
     *                   and either an array of additional filters or a value to compare against
     */
    buildFilterFromMetadata(pMetadata) {
        //Grab list of valid values
        let values = [];
        for(let value of pMetadata[Criteria__c.fieldApiName].split('\r\n')) {
            let valueParts = value.split(' ');
            if(Object.keys(OPERATOR_SIGN_MAP).indexOf(valueParts[0]) != -1) {
                values.push({
                    Operator: OPERATOR_SIGN_MAP[valueParts.shift()],
                    Value: valueParts.join(' ') == 'null' ? null : valueParts.join(' ')
                });
            } else {
                values.push({
                    Operator: OPERATOR_SINGLE_EQUALS,
                    Value: value == 'null' ? null : value
                });
            }
        }
        //Conditional Logic
        if(pMetadata[Conditional_Logic__c.fieldApiName] == null) {
            //If it's null, default to or on all of it
            return {
                Operator: OPERATOR_LIST_OR,
                Value: values
            };
        } else {
            //TODO: Parse conditional logic, e.g: 1 AND 2 OR 3 AND (4 OR 2)
        }
    }

    /**
     * Validates the given input based on a recursive filter object structure
     * @param {String|Boolean|Integer} pValue Response to Question
     * @param {Object} pAskCondition Filter
     * @param {String} pAskCondition.Operator Either Joining Operator (And/Or) or Equality Operator (MoreThan, LessThan, Equal, NotEqual)
     * @param {Object[]|String|Boolean|Integer} pAskCondition.Value Array of additional filters, or value for comparison
     * @returns {Boolean} True if filter is correct, false otherwise
     */
    checkValueAgainstFilter(pValue, pAskCondition) {
        if(Array.isArray(pAskCondition.Value)) {
            //Multi Value Filter
            for(let val of pAskCondition.Value) {
                let ret = this.checkValueAgainstFilter(pValue, val);
                console.log('##Item : ret : ' + ret);
                if(pAskCondition.Operator == OPERATOR_LIST_AND && ret == false) {
                    return false;
                } else if(pAskCondition.Operator == OPERATOR_LIST_OR && ret == true) {
                    return true;
                }
            }
            return pAskCondition.Operator == OPERATOR_LIST_AND;
        } else {
            switch (pAskCondition.Operator) {
                case OPERATOR_SINGLE_MORE_THAN:
                    return pValue > pAskCondition.Value;
                case OPERATOR_SINGLE_MORE_THAN_EQUAL:
                    return pValue >= pAskCondition.Value;
                case OPERATOR_SINGLE_LESS_THAN:
                    return pValue < pAskCondition.Value;
                case OPERATOR_SINGLE_LESS_THAN_EQUAL:
                    return pValue <= pAskCondition.Value;
                case OPERATOR_SINGLE_NOT_EQUALS:
                    return pValue != pAskCondition.Value;
                case OPERATOR_SINGLE_EQUALS:
                default:
                    return pValue == pAskCondition.Value;
            }
        }
    }

    /**
     * Rerenders the component by updating a tracked property.
     * Used because the child classes have no way of having tracked properties for a rerender
     */
    rerender() {
        this.sections = [...this.sections];
    }

    /**
     * When there is a change in an input field, we dispatch an event including the details for the parent component
     * @param {Object} event
     */
    handleChange(event) {
        event.stopPropagation();

        if(event.target.name != 'incapacityCategories' && event.target.name != 'isADW' && event.target.name != 'minimumCoverGuarantee') {
            if(this.formData[event.target.name] != event.target.value) 

                this.dispatchEvent(new CustomEvent('datachange', {detail : [event.target.value, event.target.name]}));
        }
        else
            this.dispatchEvent(new CustomEvent('datachange', {detail : [event.target.value.toString(), event.target.name]}));
    }

    /**
     * When there is a click on a button in the screen
     * @param {Object} event
     */
    handleClick(event) {
        //event.stopPropagation();
        this.dispatchEvent(new CustomEvent('buttonclick', {detail : [event.target.title, event.target.getAttribute('data-id'), event.target.getAttribute('data-heading')]}));
    }

    /**
     * We need to sync the input values seen on the screen with the actual values of this.formData
     * If we don't do this, the input values are not restoring back to their initial values in case of "Cancel".
     */
    @api syncFields() {
        let inputRichFields = this.template.querySelectorAll('lightning-input-rich-text');
        let inputFields = this.template.querySelectorAll('lightning-input');
        let comboFields = this.template.querySelectorAll('lightning-combobox');
        let textAreaFields = this.template.querySelectorAll('lightning-textarea');
        let dualListFields = this.template.querySelectorAll('lightning-dual-listbox');
        let nameField = '';
        for(let i=0; i<inputRichFields.length; i++) {
            nameField = '';
            if(inputRichFields[i].name)
                nameField = inputRichFields[i].name;
            if(this.formData[nameField])
                inputRichFields[i].value = this.formData[nameField];
        }
        for(let i=0; i<inputFields.length; i++) {
            nameField = '';
            if(inputFields[i].name)
                nameField = inputFields[i].name;
            if(this.formData[nameField])
                inputFields[i].value = this.formData[nameField];
        }
        for(let i=0; i<comboFields.length; i++) {
            nameField = '';
            if(comboFields[i].name)
                nameField = comboFields[i].name;
            if(this.formData[nameField])
                comboFields[i].value = this.formData[nameField];
        }
        for(let i=0; i<textAreaFields.length; i++) {
            nameField = '';
            if(textAreaFields[i].name)
                textAreaFields = textAreaFields[i].name;
            if(this.formData[nameField])
                textAreaFields[i].value = this.formData[nameField];
        }
        for(let i=0; i<dualListFields.length; i++) {
            nameField = '';
            if(dualListFields[i].name)
                nameField = dualListFields[i].name;
            if(this.formData[nameField])
                dualListFields[i].value = this.formData[nameField];
        }
    }
}