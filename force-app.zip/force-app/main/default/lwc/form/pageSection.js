import PageField from './pageField';

/**
 * Section wrapper to allow for dynamic getters and method calls when
 * looping over them in HTML
 */
export default class PageSection {

    onSectionClick = e => { this.IsCollapsed = !this.IsCollapsed; this.Parent.rerender(); }

    get SectionContainerClass() { return (this.IsCollapsed) ? 'slds-section' : 'slds-section slds-is-open';}
    get ChevronIcon() {
        if(this.IsCollapsible)
            return (!this.IsCollapsed) ? 'utility:chevrondown' : 'utility:chevronright';
        else
            return '';
    }
    get DisplaySection() { return this.SubSections.find(subsection => subsection.rows.find(row => row.fields.find(field => field.IsVisible))); }

    /**
     *
     * @param {Form} pParent Parent LWC
     * @param {Integer} pId Identifier
     * @param {String} HeadingStyle Section inline style
     * @param {Object} pData Section Data
     * @param {String} pData.id Section Data Id
     * @param {Boolean} pData.collapsible Should this Section be collapsable, defaults to true
     * @param {String?} pData.heading Heading of this section, required if pData.useHeading is set to true
     * @param {Boolean} pData.useHeading Should we display the header, defaults to the value of `pData.heading != null`
     * @param {String} pData.headingStyle Heading of this section, required if pData.useHeading is set to true
     * @param {Object[]} pData.subSections SubSections of this section
     * @param {String} pData.subSections.id SubSection identifier
     * @param {Integer} pData.subSections.columns Number of columns for this SubSection (1 or 2), defaults to 2
     * @param {Boolean} pData.subSections.isDeletable Whether the SubSection is deletable or not
     * @param {String} pData.subSections.style Inline style for the subsection
     * @param {Object[]} pData.subSections.rows Rows of fields
     * @param {Object[]} pData.subSections.rows.fields Fields for that row
     * @param {String} pData.subSections.rows.fields.label Field Label
     * @param {String} pData.subSections.rows.fields.fieldName Field Name found on `this.Parent.formData`
     * @param {String} pData.subSections.rows.fields.fieldType Type of field (e.g Text, Number)
     * @param {Object} pData.subSections.rows.fields.fieldTypeAttributes Type of field (e.g Text, Number)
     * @param {Boolean} pData.subSections.rows.fields.isBlank Is this a blank field?
     * @param {Boolean} pData.subSections.rows.fields.isEditable Is this a editable field?
     */

    constructor(pParent, pId, pData, isCollapsed) {
        this.Parent = pParent;
        this.Id = pId;
        this.IsCollapsed = isCollapsed;
        this.IsCollapsible = pData.collapsible && true;
        this.Heading = pData.heading;
        this.UseHeading = pData.useHeading || this.Heading != null;
        this.HeadingStyle = pData.headingStyle;

        this.SubSections = [];
        for(let subSection of pData.subSections) {
            let tempRows = [];
            let newSubSection = Object.assign({},subSection);
            newSubSection.columns = newSubSection.columns || 2;
            for(let row of newSubSection.rows) {
                let newRow = Object.assign({}, row);
                newRow.fields = row.fields?.map(field => new PageField(this, newSubSection.columns, field));
                tempRows.push(newRow);
            }
            newSubSection.rows = tempRows;
            this.SubSections.push(newSubSection);
        }
    }
}