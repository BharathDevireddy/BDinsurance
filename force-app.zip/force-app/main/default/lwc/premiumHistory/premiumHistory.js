//LWC Imports
import { api, track } from 'lwc';

//Component imports
import { callApex, getErrorMessage } from 'c/utility';
import ClaimsComponent from 'c/claimsComponent';

//Apex Imports
import fetchPremiumHistoryConfiguration from '@salesforce/apex/PremiumHistory_LEx.fetchPremiumHistoryConfiguration';

//Internal Imports
import BODY from './premiumHistory.html';

//Constants
const IDENTIFIER_PREMIUM_HISTORY_METADATA = 'PremiumHistory_LExfetchPremiumHistoryConfiguration';

export default class PremiumHistory extends ClaimsComponent {

    /*=========================================================
            Parent Component Vars
    =========================================================*/

    componentLabel = 'Premium History';
    componentBody = BODY;

    /*=========================================================
           API Vars
    =========================================================*/
    
    @api coverRef;
    @api policyRef;
    @api title = 'Policy Premium History'; // base title
    @api cardTitle; // formatted with totals
    @api totalNumberOfItems;
    @api outstandingBalance;
    @api premiums;

    /*=========================================================
            Vars
    =========================================================*/

    @track columns = [
        {
            label: 'Payment Date', 
            fieldName: 'PaymentDate', 
            type: 'date',
            typeAttributes: { 
                day: '2-digit', 
                month: '2-digit', 
                year: 'numeric' 
            }
        },
        {
            label: 'Type',
            fieldName: 'Type'
        },
        {
            label: 'Debit', 
            fieldName: 'Debit', 
            type: 'number',
            typeAttributes: {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            } 
        },
        {
            label: 'Credit', 
            fieldName: 'Credit', 
            type: 'number',
            typeAttributes: {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            } 
        }
    ];
    @track data = [];
    @track errorMessage;
    @track isLoading = true;
    @track summary;
    @track numberOfSummaryRows;
    @track expandedLink;

    /*=========================================================
            Setup
    =========================================================*/

    async connectedCallback() {
        try {
            await Promise.all([
                callApex(
                    fetchPremiumHistoryConfiguration,
                    undefined,
                    IDENTIFIER_PREMIUM_HISTORY_METADATA
                ).then(
                    config => this.numberOfSummaryRows = config.Initial_Display_Rows__c
                ),
                this.ClaimsDataService.fetchCoverDetails(
                    this.policyRef, 
                    this.coverRef
                ).then(
                    result => { 
                        this.summary = result.PremiumHistorySummary;
                        this.totalNumberOfItems = this.summary.TotalNumberOfItems;
                        this.outstandingBalance = this.summary.Outstanding;
                        this.cardTitle = this.title + ` (Outstanding £${this.outstandingBalance}) (${this.totalNumberOfItems})`;
                        this.premiums = this.summary.PremiumHistory.slice(0, this.numberOfSummaryRows);
                    }
                ),
                this.Navigation.generateComponentPageLink(
                    'premiumHistoryExpanded',
                    {
                        policyRef: this.policyRef,
                        coverRef: this.coverRef
                    }
                ).then(link => this.expandedLink = link)
            ])
        } catch(ex) {
            this.ErrorHandling.logErrorFromException(ex);
        } finally {
            this.State.show();
        }
    }

}