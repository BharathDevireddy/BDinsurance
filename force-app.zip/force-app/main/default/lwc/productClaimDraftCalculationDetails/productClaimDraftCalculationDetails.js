import { LightningElement, api } from 'lwc';

export default class ProductClaimDraftCalculationDetails extends LightningElement {
    
    modalVisible=false;
    @api draftCalculationData;
    @api selectedRowInfo;

    @api
    showModal() {
        this.modalVisible = true;
    }

    @api
    closeModal() {
        this.modalVisible = false;
    }
}