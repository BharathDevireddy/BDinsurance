import { LightningElement,api,wire,track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getUnderwritingCases from '@salesforce/apex/ProductClaimUnderwritingCases_LEx.getUnderwritingCases';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import casesFetchError from '@salesforce/label/c.Cases_fetch_error';
import casesFetchErrorMessage from '@salesforce/label/c.Cases_fetch_error_message';

const columns = [
    { label: 'Application Number', fieldName: 'url' , type: 'url' ,
     typeAttributes: {label: { fieldName: 'applicationNumber'}, target: '_blank'}},
    { label: 'Decision', fieldName: 'status'},
    { label: 'Decision Date', fieldName: 'decisionDate', type: 'date'},
    { label: 'Application Covers', fieldName: 'applicationCovers'},
];

export default class ProductClaimUnderwritingCases extends NavigationMixin(LightningElement) {

    @api caseId;
    columns = columns;
    @track isApplicationsExists = false;
    @track applicationsData;
    @track error;

    connectedCallback() {
        this.getAllUnderwritingCases();
    }

    async getAllUnderwritingCases() {
        getUnderwritingCases({productClaimId : this.caseId})
        .then(result => {
            console.log(result);
            console.log('application exists');
            this.populateHyperlinkForCases(result);
            console.log(result.length);
            this.isApplicationsExists = result.length > 0;
            console.log(this.isApplicationsExists);
            this.error = null;
            })
        .catch(error => {
            this.error = error;
            console.log('application does not exist');
            this.isApplicationsExists = false;
            this.applicationsData = [];
            this.showNotification(casesFetchError,casesFetchErrorMessage,'error')
        });
    }

    async populateHyperlinkForCases(cases){
       this.applicationsData = await Promise.all(cases.map(async(row) =>  {
           let url = await this.generateRecordUrl(row).then((val) => {return val});
           return {...row , url};
       }));
    }

    generateRecordUrl(record){
        return this[NavigationMixin.GenerateUrl]({
            type: 'standard__recordPage',
            attributes: {
                recordId: record.id,
                objectApiName: 'Application__c',
                actionName: 'view',
            },
        })
    }

    showNotification(title,message,variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }
}