import apex_mostRecentCases from '@salesforce/apex/CopyEmailMessages_Ctrl.mostRecentCases';
import apex_searchCases     from '@salesforce/apex/CopyEmailMessages_Ctrl.searchCases';
import apex_copyEmails      from '@salesforce/apex/CopyEmailMessages_Ctrl.copyEmails';

export function mostRecentCases(baseRecordId) {
    return apex_mostRecentCases({ baseRecordId });
}
export function searchCases(query, baseRecordId) {
    return apex_searchCases({ query, baseRecordId });
}
export function copyEmails(sourceId, destId) {
    return apex_copyEmails({ sourceId, destId });
}