export const BANK_LAYOUT_DATA_EDIT = {
    id: 'bank-details',
    columns: 2,
    style: 'border: 2px #E3E3E3 solid; margin: 10px 0px 10px 15px; width:95%; padding-bottom:5px; padding-top:3px;',
    isDeletable: false,
    rows: [
        {
            fields: [
                {
                    label: 'Effective Date',
                    fieldName: 'effectiveDate',
                    fieldType: 'Date',
                    style: 'margin-top: -20px; width: 50%;',
                    isEditable: true,
                    formElementStyle: 'border-bottom:none; padding-top:10px; margin-left:23px;',
                    fieldTypeAttributes: {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                    }
                }
            ]
        },
        {
            fields: [
                {
                    label: 'Bank Name',
                    fieldName: 'bankName',
                    fieldType: 'Text',
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none; margin-left:25px;',
                    isEditable: true   
                },
                {
                    label: 'Account Name',
                    fieldName: 'accountName',
                    fieldType: 'Text',
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none; margin-left:15px;',
                    isEditable: true   
                }
            ]
        },
        {
            fields: [
                {
                    label: 'Account Number',
                    fieldName: 'accountNumber',
                    fieldType: 'Text',
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none; margin-left:25px;',
                    isEditable: true   
                },
                {
                    label: 'Sort Code',
                    fieldName: 'sortCode',
                    fieldType: 'Text',
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none; margin-left:15px;',
                    isEditable: true   
                }
            ]
        },
        {
            fields: [
                {
                    label: 'Payee Reference',
                    fieldName: 'payeeReference',
                    fieldType: 'Text',
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none; margin-left:25px;',
                    isEditable: true   
                }
            ]
        },
        {
            fields: [
                {
                    label: 'Bank Details Validated',
                    fieldName: 'bankDetailsValidated',
                    fieldType: 'Picklist',
                    isEditable: true,
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none; margin-left:25px;',
                    options: [
                        {label: 'Yes', value: 'yes'},
                        {label: 'No', value: 'no'}
                    ]
                }
            ]
        }
    ]
}