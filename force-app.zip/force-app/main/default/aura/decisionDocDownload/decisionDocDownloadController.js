({	
	// new start point so we can check if its PP before attempting to D/L doc
	 start: function(component){	
		const action = component.get('c.isThisPPApplication');
		action.setParam('appId', component.get('v.recordId'));
			action.setCallback(this, $A.getCallback(function(response) {
					switch(response.getState()) {
					case 'SUCCESS':
						if(response.getReturnValue() === true){
							//if PP just show a msg
							component.set("v.showPPMessage", true);
						}
						else{
							//else run prior download code for nbj1/2
							new Promise($A.getCallback(function (resolve, reject) {
								const action = component.get('c.fetchDecisionDocument');
								action.setParam('applicationId', component.get('v.recordId'));
								action.setCallback(this, $A.getCallback(function(response) {
										switch(response.getState()) {
										case 'SUCCESS':
											resolve(response.getReturnValue());
											break;
										case 'ERROR':
											reject(response.getError());
											break;
										}
								}));
								$A.enqueueAction(action);
							})).then($A.getCallback(function(resData) {
								// Convert the base64 into binary data
								const data = atob(resData.Content);
								// Honestly not sure what the problem is here
								//
								// Ultimately I believe the problem comes down to the fact that
								// `atob` returns a String while JS strings are utf-16 (i.e. each
								// code-point is 2 bytes). This seems to cause issues when creating
								// a Blob from that data (there was no error, however the resulting
								// Blob was larger than the base64 encoded data, which isn't how
								// base64 works, so I assume that the actual data was corrupted).
								// My guess is that converting to a Blob converts the UTF-16 into
								// UTF-8, which screws with the binary representation. I'm not
								// certain about this though.
								//
								// The following line converts the UTF-16 into pure binary data.
								const bin  = Uint8Array.from(data, c => c.charCodeAt(0));
								const blob = new Blob([ bin ], { type: resData.ContentType });
								// Store the objectURL so that we can clean it up when the component
								// is removed from the page.
								component.objectUrl = URL.createObjectURL(blob);
				
								// Create a fake element to store the download URL and click it
								const elt    = document.createElement('a');
								elt.href     = component.objectUrl;
								elt.download = resData.FileName;
				
								// The element needs to be on the page to be clickable
								document.body.appendChild(elt);
								elt.click();
								document.body.removeChild(elt);
							})).catch($A.getCallback(function(err) {
								const toast = $A.get('e.force:showToast');
								toast.setParams({
										title:   "Error!",
										message: (err[0] && err[0].message) || err.message || "Failed to download",
										type:    "error",
								});
								toast.fire();
							})).then($A.getCallback(function () {
								$A.get("e.force:closeQuickAction").fire();
							}));
						}
						break;
					case 'ERROR':
						const toast = $A.get('e.force:showToast');
						toast.setParams({
							title:   "Error!",
							message: response.getError() || "Failed to download",
							type:    "error",
						});
						toast.fire();
						reject();
						break;
					}
			}));
			$A.enqueueAction(action);
	 },
    cleanup: function(component) {
        if(component.objectUrl) {
            URL.revokeObjectURL(component.objectUrl);
        }
    }
})