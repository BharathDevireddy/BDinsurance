({
    confirmOpenCase: function(component) {
        if(component.get('v.loadingMessage')) return;

        component.set("v.loadingMessage", $A.get("$Label.c.OpenPostSTPCase_Loading_CreatingCase"));
        new Promise($A.getCallback(function(resolve, reject) {
            const action = component.get("c.createPostSTPCase");
            action.setParams({
                appMemberId: component.get("v.recordId"),
            });
            action.setCallback(this, $A.getCallback(function(response) {
                if("SUCCESS" !== response.getState()) {
                    reject(response.getError());
                } else {
                    resolve(response.getReturnValue());
                }
            }));

            $A.enqueueAction(action);
        }))
        .then($A.getCallback(function(res) {
            const toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Open Post STP Case",
                "type": "success",
                "message": $A.get("$Label.c.OpenPostSTPCase_Success")
            });
            toastEvent.fire();

            const urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({ "url": "/lightning/r/Case/" + res + '/view' });
            urlEvent.fire();
        }))
        .catch($A.getCallback(function(err) {
            component.set("v.errorMessage", (err[0] && err[0].message) || err.message || "Failed to open Case");
        }))
        .then($A.getCallback(function() {
            component.set("v.loadingMessage", null);
        }));
    },
    close: function() {
        $A.get('e.force:closeQuickAction').fire();
    }
})