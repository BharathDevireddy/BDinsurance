({
	doInit: function(cmp) {
		//take parameter from pagereference
		var myPageRef = cmp.get("v.pageReference");
		cmp.set("v.ApplicationMemberId",  myPageRef.state.c__ApplicationMemberId);

		//callout to find enquiry Id
		let action = cmp.get("c.getEnquiryId");        
		action.setParams({
			"applicationMemberId": cmp.get("v.ApplicationMemberId")
		});
		action.setCallback(this, function(response){
			var state = response.getState();
			console.log("state >> ", state);
			if (state === "ERROR") {
				let errors = response.getError();
				if (errors) {
					if (errors[0] && errors[0].message) {
						alert("Error: " + errors[0].message);
					} else {
						alert("An unknown error occured.");
					}
				} else {
					alert("An unknown error occured.");
				}

			}
			if (state === "SUCCESS") {
				cmp.set("v.showEnquiry",true);
				let enquiryId = response.getReturnValue();
				cmp.set("v.iframeUrl", 'https://uniteserver-uwt.gghltest.co.uk/api/underwriteme/stg/proxy/enquiryhistory/#?enquiryId=' + enquiryId);
			}
		});
		$A.enqueueAction(action);
	}
})