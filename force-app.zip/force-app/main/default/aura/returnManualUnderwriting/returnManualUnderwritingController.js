({
    init: function(component, event, helper) {
        component.set("v.errorMessage", "");

        /**
         * call `userHasPermission` method in the apex controller and set result
         * to component attribute 'v.userHasPermission'.
         * This check's that the current user has the following custom permission
         * set for the current user: 'CanReturnToManualUnderwriting'
         * Without the permission, user will be shown an error message denoting
         * that user 'does not have permission' or the same effect
         */
        const userHasPermissionPromise = new Promise($A.getCallback(function(resolve, reject) {
            const action = component.get("c.userHasPermission");
            action.setCallback(this, $A.getCallback(function(response) {
                if ("SUCCESS" !== response.getState()) {
                    reject(response.getError() || response.getReturnValue());
                } else {
                    resolve(response.getReturnValue());
                }
            }));
            $A.enqueueAction(action);
        }))
        .then($A.getCallback(function(res) { component.set("v.hasPermission", res) }))
        .catch($A.getCallback(function(err) { component.set("v.hasError", true); component.set("v.errorMessage", (err[0] && err[0].message) || err.message || "Unable to check permissions"); }));

        /**
         * call 'canBeReturnedToUnderwriting' method in the apex controller and
         * set result to component attribute 'v.meetsRequirements'.
         * Method will check that the Application Member meets the business
         * requirements and enables the user to further decide if the current
         * record (Application Member) should be returned to Manual Underwriting
         */
        const meetsRequirementsPromise = new Promise($A.getCallback(function(resolve, reject) {
            const action = component.get("c.canBeReturnedToUnderwriting");
            action.setParams({ applicationMemberId: component.get("v.recordId") });
            action.setCallback(this, $A.getCallback(function(response) {
                if("SUCCESS" !== response.getState()) {
                    reject(response.getError() || response.getReturnValue())
                } else {
                    resolve(response.getReturnValue());
                }
            }))
            $A.enqueueAction(action);
        }))
        .then($A.getCallback(function(res) { component.set("v.meetsRequirements", res) }))
        .catch($A.getCallback(function(err) { component.set("v.hasError", true); component.set("v.errorMessage", (err[0] && err[0].message) || err.message || "Unable to check Application Member requirements"); }));

        Promise.all([userHasPermissionPromise, meetsRequirementsPromise])
        .then($A.getCallback(function() { component.set("v.isLoading", false) }));

    },
    hasError: function(component, event, helper) {
        const errorMessage = component.get("v.errorMessage");
        console.log(errorMessage && errorMessage.length > 0);
        return (errorMessage && errorMessage.length > 0);
    },
    returnMUWConfirmation: function(component, event, helper) {
        // If the component is loading, don't do anything. The person might've
        // already pressed the button and we don't want to submit twice.
        if(component.get('v.isLoading')) {
            return;
        }

        /**
         * component has 3 stages which signify returnMUW progress:
         * ---------------------------------------------------------------------
         * 1) 'CONFIRM' - set by default and used to show confirmation message
         *                and button. This will appear after the initial
         *                application member requirements are met and the user
         *                custom permission check has been completed.
         * ---------------------------------------------------------------------
         * 2) 'SUCCESS' - this is set once user has proceeded through the
         *                confirmation section and an initial positive result
         *                from the http request has been gained. at this point,
         *                the adjacent application member's case has either been
         *                created, re-opened or updated and is in 'underwriting'
         *                status. Currently this stage should not do anything as
         *                user should be redirected to the newly modified case
         *                record.
         * ---------------------------------------------------------------------
         * 3) 'FAILURE' - this denotes that the step 2) above has failed;
         *                initial callout has failed. errorMessage should be set
         *                to include details of the failure. User to be shown a
         *                custom label that generalises a failure has occured,
         *                as well as a failure message from the callout (where
         *                appropriate)
         * ---------------------------------------------------------------------
         * if at anytime the modal state should be reset, 'v.stage' should be
         * set to 'CONFIRM'
         */
        component.set('v.isLoading', true);

        const returnMUWPromise = new Promise($A.getCallback(function(resolve, reject) {
            const action = component.get("c.returnToUnderwriting");
            action.setParams({ applicationMemberId: component.get("v.recordId") });
            action.setCallback(this, $A.getCallback(function(response) {
                if("SUCCESS" !== response.getState()) {
                    reject(response.getError() || response.getReturnValue())
                } else {
                    resolve(response.getReturnValue());
                }
            }))
            $A.enqueueAction(action);
        }))
        .then($A.getCallback(function(res) {
            if (true === res.isSuccess) {
                // if response is successful, redirect user to case record

                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Return to Underwriting",
                    "type": "success",
                    "message": $A.get("$Label.c.ReturnMUW_Success_Message")
                });
                toastEvent.fire();

                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({ "url": "/" + res.caseId });
                urlEvent.fire();
                // component.set("v.stage", "SUCCESS");  // this should never be set on success.
            } else {
                component.set("v.hasError", true);
                component.set("v.stage", "FAILURE");
                component.set("v.errorMessage", res.errorMessage);
            };
        }))
        .catch($A.getCallback(function(err) {
            component.set("v.hasError", true);
            component.set("v.errorMessage", (err[0] && err[0].message) || err.message || "Unable to communicate with the 'returnToUnderwriting' service");
            component.set("v.stage", "FAILURE");
        }));

        Promise.all([returnMUWPromise])
        .then($A.getCallback(function() {component.set("v.isLoading", false) }));
    },
    close: function(component, event, helper) {
        $A.get('e.force:closeQuickAction').fire();
    }
})