({
    doInit : function(component, event, helper) {
        helper.getUploadedFiles(component);  
    },

    delFilesAction : function(component,event,helper){
        component.set("v.Spinner", true);
        var documentId = event.currentTarget.id;        

        helper.delUploadedfiles(component,documentId);
    },

    handleClick : function(component, event, helper) {
        helper.getUploadedFiles(component);

        $A.get('e.force:refreshView').fire();      
    }
})