export default class Themes {
    static CLASS_ENTRY = 'slds-timeline__item_expandable';
    static CLASS_EXPANDED = 'slds-is-open';
    static CATEGORY_THEME_DEFINITIONS = {
        Medical: {
            themeClass: 'theme-medical',
            iconName: 'custom:custom1'
        },
        Financial: {
            themeClass: 'theme-financial',
            iconName: 'custom:custom17'
        },
        Occupational: {
            themeClass: 'theme-occupational',
            iconName: 'custom:custom19'
        },
        Admin: {
            themeClass: 'theme-admin',
            iconName: 'custom:custom83'
        },
        Complaint_Appeal: {
            themeClass: 'theme-appeal',
            iconName: 'custom:custom90'
        },
        General: {
            themeClass: 'theme-general',
            iconName: 'custom:custom96'
        },
        Reinsurer: {
            themeClass: 'theme-reinsurer',
            iconName: 'custom:custom16'
        },
        BPS_Score: {
            themeClass: 'theme-bps',
            iconName: 'custom:custom109'
        }
    };
}