import { api, LightningElement, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { publish, MessageContext } from 'lightning/messageService';

import { callApex, clearCache } from 'c/utility';
import ClaimsComponent from 'c/claimsComponent';
import { cancelSave, saveProductData } from 'c/productClaimDataHandler';

import fetchRecordClaimExternalId from '@salesforce/apex/ClaimsDataHandler_LEx.fetchRecordClaimExternalId';
import ProductClaimRefreshData__c from '@salesforce/messageChannel/ProductClaimRefreshData__c';


const IDENTIFIER_RECORD_PRODUCT_CLAIMID = 'ProductClaim_LExfetchRecordProductClaimId';

import BODY from './productClaimSavePanel.html';

export default class ProductClaimSavePanel extends ClaimsComponent {

    @api recordId;
    recordClaimExternalId;

    @wire(MessageContext)
    messageContext;

    componentBody = BODY;


    async connectedCallback() {
        try {

            await Promise.all([
                this.fetchClaimExternalId()
                    .then(pVal => this.recordClaimExternalId = pVal)
            ]);

        } catch(ex) {
            this.ErrorHandling.logErrorFromException(ex);
            console.log('error getting external id !');
        } finally {
            this.State.show();
        }
    }

    handleCancel() {
        cancelSave();
        publish(this.messageContext, ProductClaimRefreshData__c, {msg: 'Cancelled!'});
    }

    /**
     * Fetches the product claim external Id through an apex method using the recordId.
     * This will cache the result using `utility.callApex`
     */
    async fetchClaimExternalId() {
        return await callApex(
            fetchRecordClaimExternalId,
            {
                pRecordId: this.recordId
            },
            IDENTIFIER_RECORD_PRODUCT_CLAIMID + this.recordId
        );
    }

    async handleSave() {

            try {
                await saveProductData(this.recordClaimExternalId)
                .then((result) => {
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Success',
                        message: 'Save successful',
                        variant: 'success'
                        }));
                    publish(this.messageContext, ProductClaimRefreshData__c, {msg: 'Saved!'});
                })
            } catch(ex) {
               // this.ErrorHandling.logErrorFromException(ex);
                // await saveProductData(this.recordClaimExternalId)
                // .then((result) => {
                //     this.dispatchEvent(new ShowToastEvent({
                //         title: 'Fail-Error',
                //         message: 'Save failed.',
                //         variant: 'fail'
                //         }));
                    publish(this.messageContext, ProductClaimRefreshData__c, {msg: 'Failed!'});
                // })
            } finally {
                this.State.show();
            } 
        }
}