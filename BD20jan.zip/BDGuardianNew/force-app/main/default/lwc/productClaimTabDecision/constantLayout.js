export const LAYOUT_DATA = [   
    {
        id: 1,
        collapsible: true,
        heading: 'Payment Details',
        useHeading: true,
        headingStyle: 'margin-left:20px; width:95%;',
        subSections: [
            {
                id: 0,
                columns: 2,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: 'Premium Account',
                                fieldName: 'payToPremiumAccount',
                                fieldType: 'Picklist',
                                isEditable: true,
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                options: [
                                    {label: 'Yes', value: 'yes'},
                                    {label: 'No', value: 'no'}
                                ]
                            }/*,
                            {
                                label: 'Standard Payment',
                                fieldName: 'standardPayment',
                                fieldType: 'Picklist',
                                isEditable: true,
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                options: [
                                    {label: 'Yes', value: 'yes'},
                                    {label: 'No', value: 'no'}
                                ]
                            }*/
                        ]
                    }
                ]
            }/*,
            {
                id: 'new-payment-details-button',
                columns: 1,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: 'New Payment Details',
                                fieldName: 'newPaymentDetailsButton',
                                fieldType: 'Button',
                                formElementStyle: 'border-bottom:none; border-top: 3px solid #F3F3F3; margin-top: 10px; margin-bottom:20px;',
                                formElementStaticStyle: 'padding-top:10px; padding-bottom:10px; margin-left:15px; width:95%;'
                            }
                        ]
                    }
                ]
            }*/
        ]
    }, 
    {
        id: 2,
        collapsible: true,
        heading: 'Decision',
        useHeading: true,
        headingStyle: 'margin-left:20px; width:95%;',
        subSections: [
            {
                id: 0,
                columns: 2,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: 'Calc Ref',
                                fieldName: 'financialAssessmentID',
                                fieldType: 'Text',
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                isEditable: false   
                            },
                            {
                                label: 'Calc Type',
                                fieldName: 'productClaimDecisionCalculationTypeID',
                                fieldType: 'Picklist',
                                isEditable: true,
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                options: []
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Decision Type',
                                fieldName: 'decisionTypeID',
                                fieldType: 'Picklist',
                                isEditable: true,
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                options: [
                                    {label: 'Please Select', value: 'unselected'}
                                ]
                            },
                            {
                                label: 'Decision',
                                fieldName: 'decisionSubTypeID',
                                fieldType: 'Picklist',
                                isEditable: true,
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                options: [
                                    {label: 'Please Select', value: 'unselected'}
                                ]
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Payee',
                                fieldName: 'payeeName',
                                fieldType: 'Text',
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                isEditable: true
                            },
                            {
                                label: 'Payee Reference',
                                fieldName: 'payeeReference',
                                fieldType: 'Text',
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                isEditable: true
                            },
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'PEP/Sanction Check Date',
                                fieldName: 'pepSanctionCheckDate',
                                fieldType: 'Date',
                                style: 'margin-top: -20px; width: 50%;',
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; padding-top:10px; margin-left:15px;',
                                fieldTypeAttributes: {
                                    day: '2-digit',
                                    month: '2-digit',
                                    year: 'numeric'
                                }
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Reinsurer Decision',
                                fieldName: 'isReinsurerApproved',
                                fieldType: 'Picklist',
                                isEditable: true,
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                options: [
                                    {label: 'Please Select', value: 'unselected'},
                                    {label: 'Approved', value: 'approved'},
                                    {label: 'Decline', value: 'decline'}
                                ]
                            },
                            {
                                label: 'Reinsurer Decision Date',
                                fieldName: 'reinsurerDecisionDate',
                                fieldType: 'Date',
                                style: 'margin-top: -20px;',
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                fieldTypeAttributes: {
                                    day: '2-digit',
                                    month: '2-digit',
                                    year: 'numeric'
                                }
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Reinsurer Comments',
                                fieldName: 'reinsurerComments',
                                fieldType: 'RichTextArea',
                                style: 'width:99%;',
                                fieldTypeAttributes: {
                                    formats: [
                                        'font',
                                        'size',
                                        'bold',
                                        'italic',
                                        'underline',
                                        'list',
                                        'indent',
                                        'align',
                                        'link',
                                        'clean',
                                        'table',
                                        'header'
                                    ]
                                },
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; margin-left:13px;'
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        id: 3,
        collapsible: true,
        heading: 'Mis-Rep',
        useHeading: true,
        headingStyle: 'margin-left:20px; width:95%;',
        subSections: [
            {
                id: 0,
                columns: 2,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {

                                label: 'Misrep Type',
                                fieldName: 'misrepresentationTypeID',
                                fieldType: 'Picklist',
                                isEditable: true,
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                options: []
                            },
                            {
                                label: 'Related to Claim',
                                fieldName: 'misrepresentationRelatedToClaim',
                                fieldType: 'Picklist',
                                isEditable: true,
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                options: [
                                    {label: 'Please Select', value: 'unselected'},
                                    {label: 'Yes', value: 'yes'},
                                    {label: 'No', value: 'no'}
                                ]
                            }
                        ]
                    },
                    {
                        fields: [
                            {

                                label: 'Misrep Category',
                                fieldName: 'misrepresentationCategoryID',
                                fieldType: 'Picklist',
                                isEditable: true,
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                options: [
                                    {label: 'Please Select', value: 'unselected'}
                                ]
                            },
                            {

                                label: 'Retro U/W',
                                fieldName: 'retroUWID',
                                fieldType: 'Picklist',
                                isEditable: true,
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                options: [
                                    {label: 'Please Select', value: 'unselected'}
                                ]
                            }
                        ]
                    },
                ]
            }
        ]
    },
    {
        id: 4,
        collapsible: false,
        useHeading: false,
        subSections: [
            {
                id: 0,
                columns: 1,
                isDeletable: false,
                rows: [
                    {

                        fields: [
                            {
                                label: 'Submit For Approval',
                                fieldName: 'submitForApprovalButton',
                                fieldType: 'Button',
                                formElementStyle: 'border-bottom:none; border-top: 3px solid #F3F3F3; margin-top: 10px; margin-bottom:20px;',
                                formElementStaticStyle: 'padding-top:10px; padding-bottom:10px; margin-left:15px; width:95%;'
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        id: 5,
        collapsible: true,
        heading: 'Decision Summary',
        useHeading: true,
        headingStyle: 'margin-left:20px; width:95%;',
        subSections: [
            {
                id: 0,
                columns: 1,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                fieldName: 'summary-table',
                                fieldType: 'DataTable',
                                style: 'min-height:60px;',
                                columns: [
                                    { label: 'Calc Ref', fieldName: 'financialAssessmentID'},
                                    { label: 'Decision Type', fieldName: 'decisionTypeID', type: 'url' },
                                    { label: 'Decision', fieldName: 'decisionSubTypeID' },
                                    { label: 'Payee', fieldName: 'payeeName' },
                                    { label: 'Reinsurer Decision', fieldName: 'isReinsurerApproved' },
                                    { label: 'GFS Decision Date', fieldName: 'gfsDecisionDate' },
                                ],
                                tableData: [],
                                fieldTypeAttributes: {
                                    keyField: 'name'
                                },
                                isEditable: false
                            }
                        ]
                    }
                ]
            }
        ]
    }
]