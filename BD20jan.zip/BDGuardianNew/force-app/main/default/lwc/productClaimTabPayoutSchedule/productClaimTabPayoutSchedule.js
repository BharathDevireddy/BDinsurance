import {LightningElement, track, api, wire} from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import CASE_FIELD_CALCULATED from '@salesforce/schema/Case.Draft_Calculated__c';

import {calculateProductClaimDraftData, getProductReadOnlyData} from 'c/productClaimDataHandler';

import {
    DRAFT_PAYOUT_SCHEDULE_COLUMNS,
    PUBLISHED_FUTURE_PAYOUT_SCHEDULE_COLUMNS,
    PUBLISHED_PAID_PAYOUT_SCHEDULE_COLUMNS
} from "./tablesConfiguration";

import {ShowToastEvent} from "lightning/platformShowToastEvent";

export default class ProductClaimTabPayoutSchedule extends LightningElement {

    @api recordId;
    @track draftPayoutScheduleColumns = DRAFT_PAYOUT_SCHEDULE_COLUMNS;
    @track publishedFuturePayoutScheduleColumns = PUBLISHED_FUTURE_PAYOUT_SCHEDULE_COLUMNS;
    @track publishedPaidPayoutScheduleColumns = PUBLISHED_PAID_PAYOUT_SCHEDULE_COLUMNS;
    @track draftPayoutScheduleData = [];
    @track publishedFuturePayoutScheduleData = [];
    @track publishedPaidPayoutScheduleData = [];
    showSpinner = false;
    draftPayoutScheduleDataAll = [];
    publishedFuturePayoutScheduleDataAll = [];
    publishedPaidPayoutScheduleDataAll = [];
    showModal = false;
    allData = [];
    pageData = [];
    columns = [];
    header;
    draftViewAll = false;
    futureViewAll = false;
    paidViewAll = false;
    pageSize = 10;
    @track pageNumber = 1;
    nextDisabled = false;
    prevDisabled = false;

    get pageSizeOptions() {
        return [
            { label: '10', value: '10' },
            { label: '25', value: '25' },
            { label: '50', value: '50' },
        ];
    }
    
    //get the Product Claim Case
    @wire(getRecord, { recordId: '$recordId', fields: [CASE_FIELD_CALCULATED] })
    case

    get isDraftCalculated() {
        return getFieldValue(this.case.data, CASE_FIELD_CALCULATED);
    }

    connectedCallback() {
        this.showSpinner = true;
        this.getPayoutScheduleData();
        setTimeout(() => {
            if (this.isDraftCalculated) {
                this.isCalculateButtonInactive = false;
                this.getPayoutScheduleDraftData();
            }
        }, 1000);
    }

    @api
    getPayoutScheduleDraftData() {
        this.showSpinner = true;
        calculateProductClaimDraftData(this.recordId)
            .then(result => {
                // this.draftPayoutScheduleDataAll = this.processPayoutScheduleData(result.payoutSchedule);
                // this.draftPayoutScheduleDataAll = result.payoutSchedule;
                this.draftPayoutScheduleDataAll = this.processPayoutScheduleData(result.payoutSchedule);
                if (this.draftPayoutScheduleDataAll) {
                    this.draftPayoutScheduleData = this.draftPayoutScheduleDataAll.length > 6 ? this.draftPayoutScheduleDataAll.slice(0,6) : this.draftPayoutScheduleDataAll;
                    this.draftViewAll = this.draftPayoutScheduleDataAll.length > 6;
                    // this.draftPayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule);
                }
                // if (result.payoutSchedule) {
                //     alert(result.payoutSchedule.draftPayoutSchedule.length);
                //     alert(result.payoutSchedule.publishedFuturePayoutSchedule.length);
                //     alert(result.payoutSchedule.publishedPaidPayoutSchedule.length);
                //     if (result.payoutSchedule.draftPayoutSchedule) {
                //         this.draftPayoutScheduleDataAll = result.payoutSchedule.draftPayoutSchedule;
                //         this.draftPayoutScheduleData = this.draftPayoutScheduleDataAll.length > 6 ? this.draftPayoutScheduleDataAll.slice(0,6) : this.draftPayoutScheduleDataAll;
                //         this.draftPayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.draftPayoutSchedule);
                //         this.draftViewAll = this.draftPayoutScheduleDataAll.length > 6;
                //     }
                //     if (result.payoutSchedule.publishedFuturePayoutSchedule) {
                //         this.publishedFuturePayoutScheduleDataAll = result.payoutSchedule.publishedFuturePayoutSchedule;
                //         this.publishedFuturePayoutScheduleData = this.publishedFuturePayoutScheduleDataAll.length > 6 ? this.publishedFuturePayoutScheduleDataAll.slice(0,6) : this.publishedFuturePayoutScheduleDataAll;
                //         this.publishedFuturePayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.publishedFuturePayoutSchedule);
                //         this.futureViewAll = this.publishedFuturePayoutScheduleDataAll.length > 6;
                //     }
                //     if (result.payoutSchedule.publishedPaidPayoutSchedule) {
                //         this.publishedPaidPayoutScheduleDataAll = result.payoutSchedule.publishedPaidPayoutSchedule;
                //         this.publishedPaidPayoutScheduleData = this.publishedPaidPayoutScheduleDataAll.length > 6 ? this.publishedPaidPayoutScheduleDataAll.slice(0,6) : this.publishedPaidPayoutScheduleDataAll;
                //         this.publishedPaidPayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.publishedPaidPayoutSchedule);
                //         this.paidViewAll = this.publishedPaidPayoutScheduleDataAll.length > 6;
                //     }
                    // this.publishedFuturePayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.publishedFuturePayoutSchedule);
                    // this.publishedPaidPayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.publishedPaidPayoutSchedule);
                // }
            })
            .catch(error => {
                this.showNotification('Error' , 'Cannot retrieve calculation result' , 'error');
            })
            .finally(() => {
                this.showSpinner = false;
            });
    }

    @api
    getPayoutScheduleData() {
        this.showSpinner = true;
        getProductReadOnlyData(this.recordId)
            .then(result => {
                if (result.payoutSchedule) {
                    this.draftPayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.draftPayoutSchedule);
                    this.publishedFuturePayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.publishedFuturePayoutSchedule);
                    this.publishedPaidPayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.publishedPaidPayoutSchedule);
                }
            })
            .catch(error => {
                this.showNotification('Error' , 'Cannot retrieve calculation result' , 'error');
            })
            .finally(() => {
                this.showSpinner = false;
            });
    }

    processPayoutScheduleData(payoutScheduleData) {
        let mainIndex = 1;
        // const dateReference = new Date().setMonth(new Date().getMonth() + 6);
        // payoutScheduleData = payoutScheduleData.filter(payoutScheduleDataItem => {
        //    return new Date(payoutScheduleDataItem.startDate) <= dateReference;
        // });
        payoutScheduleData.forEach(payoutScheduleDataItem => {
            payoutScheduleDataItem._children = payoutScheduleDataItem.details;
            payoutScheduleDataItem.key = mainIndex;
            mainIndex++;
            let childIndex = 1;
            payoutScheduleDataItem._children.forEach(child => {
                child.key = mainIndex + '-' + childIndex;
                childIndex++;
            });
            if (payoutScheduleDataItem._children && payoutScheduleDataItem._children.length === 1) {
                payoutScheduleDataItem.dayRate = payoutScheduleDataItem._children[0].dayRate;
                payoutScheduleDataItem.annualisedPayout = payoutScheduleDataItem._children[0].annualisedPayout;
                delete payoutScheduleDataItem._children;
            }
        });
        return payoutScheduleData;
    }

    showNotification(title, message, variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }

    showNotification(title,message,variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }

    handleViewMore (event){
        var section = event.currentTarget.dataset.id;
        if (section === 'draft') {
            this.header = 'DRAFT Payout Schedule';
            this.columns = this.draftPayoutScheduleColumns;
            this.allData = this.draftPayoutScheduleDataAll;
        }
        else if (section === 'issued') {
            this.header = 'ISSUED Future Payout Schedule';
            this.columns = this.publishedFuturePayoutScheduleColumns;
            this.allData = this.publishedFuturePayoutScheduleDataAll;
        }
        else {
            this.header = 'Payout History';
            this.columns = this.publishedPaidPayoutScheduleColumns;
            this.allData = this.publishedPaidPayoutScheduleDataAll;
        }
        this.allData.sort((a,b) => (a.startDate > b.startDate) ? 1 : ((b.startDate > a.startDate) ? -1 : 0))
        this.showModal = true;
        this.pageNumber = 1;
        this.prevDisabled = true;
        this.nextDisabled = false;
        this.handlePageNoChange();
    }

    handleClose (){
        this.showModal = false;
    }

    handlePageSizeChange(event) {
        this.pageSize = event.detail.value;
        this.handlePageNoChange();
    }

    handleNext() {
        this.pageNumber++;
        if (Math.ceil(this.allData.length/this.pageSize) == this.pageNumber) {
            this.nextDisabled = true;
        }
        this.handlePageNoChange();
        // this.handleChangeData();
    }

    handlePrev() {
        this.pageNumber--;
        if (this.pageNumber == 1) {
            this.prevDisabled = true;
        }
        this.handlePageNoChange();
    }

    handlePageNoChange(event) {
        var maxPage = Math.ceil(this.allData.length/this.pageSize);
        if (event) {
            this.pageNumber = event.target.value;
        }
        if (maxPage > 1 && this.pageNumber == 1) {
            this.prevDisabled = true;
            this.nextDisabled = false;
        }
        if (maxPage <= this.pageNumber) {
            this.nextDisabled = true;
            this.pageNumber = maxPage;
        }
        if (maxPage > 1 && this.pageNumber != 1) {
            this.prevDisabled = false;
            if (maxPage != this.pageNumber) {
                this.nextDisabled = false;
            }
        }
        this.handleChangeData();
    }

    handleChangeData() {
        if (this.pageNumber == 1) {
            this.pageData = this.allData.slice(0,this.pageSize);            
        }
        else {
            this.pageData = this.allData.slice((this.pageNumber-1)*this.pageSize, this.pageNumber*this.pageSize);
        }
    }
}