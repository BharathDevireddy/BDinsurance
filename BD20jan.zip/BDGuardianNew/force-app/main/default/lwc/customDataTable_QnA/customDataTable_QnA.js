import LightningDatatable  from 'lightning/datatable';

import wHelpTxt from "./withHelpText.html";

export default class customDataTable_QnA extends LightningDatatable {
	static customTypes = {
		wHelpTxt:{
			template: wHelpTxt,
			typeAttributes: ['options', 'isForeignQuestion']
		}
	}
}