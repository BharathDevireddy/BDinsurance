import {LightningElement, api, track} from 'lwc';

import saveAssessment from '@salesforce/apex/AssessmentEdit_LEx.saveAssessment';
import getAssessment from '@salesforce/apex/AssessmentEdit_LEx.getAssessment';

import {CATEGORY_OPTIONS,BPS_SCORE_OPTIONS} from "c/assessmentUtils";
import {ShowToastEvent} from "lightning/platformShowToastEvent";

export default class AssessmentEdit extends LightningElement {

    @api assessmentId;
    @api parentCaseId;
    categoryOptions = CATEGORY_OPTIONS;
    bpsScoreOptions = BPS_SCORE_OPTIONS;
    modalVisible = false;
    isLoading = false;
    @api bpsScoreCategory ;
    @track
    assessment = {
        Outcome: '',
        Observation: ''
    };
    observationValidity = true;
    outcomeValidity = true;

    connectedCallback() {
        this.initializeEditor();
    }

    @api
    showModal() {
        this.modalVisible = true;
    }

    @api
    closeModal() {
        this.modalVisible = false;
    }

    initializeEditor() {
        if (this.assessmentId) {
            this.getAssessment();
        } else {
            this.resetNewAssessment();
            this.assessment.ParentCaseId = this.parentCaseId;
        }
    }

    resetNewAssessment() {
        this.assessment = {
            Outcome: '',
            Observation: ''
        };
        this.bpsScoreCategory = false;
    }

    onCloseNewAssessmentModal() {
     this.closeModal();
    }

    onObservationChange(event) {
        this.assessment.Observation = event.target.value;
    }

    onOutcomeChange(event) {
        this.assessment.Outcome = event.target.value;
    }

    onSaveAssessment() {
        let formElements = this.template.querySelectorAll("[data-role='formInput']");
        this.captureFieldValues(formElements, this.assessment);
        if (!this.validateForm(formElements)) {
            return;
        }
        this.saveAssessment();
    }

    getAssessment() {
        this.isLoading = true;
        getAssessment({pAssessmentId: this.assessmentId})
            .then(result => {
                this.assessment = result;
            })
            .catch(error => {
                console.log(error);
            })
            .finally(() => {
                this.isLoading = false;
            });
    }

    saveAssessment() {
        this.isLoading = true;
        saveAssessment({pAssessment: this.assessment})
            .then(result => {
                this.closeModal();
                this.initializeEditor();
                this.dispatchEvent(new CustomEvent('assessmentsaved'))
            })
            .catch(error => {
                this.showNotification('Error', error.body.message, 'error');
            })
            .finally(() => {
                this.isLoading = false;
            });
    }

    captureFieldValues(formElements, editedObject) {
        const checkedFieldTypes = ['checkbox', 'toggle'];
        formElements.forEach(formElement => {
            let fieldName = formElement.dataset.field;
            if (checkedFieldTypes.includes(formElement.type)) {
                editedObject[fieldName] = formElement.checked;
            } else {
                editedObject[fieldName] = formElement.value;
            }
        });
    }

    validateForm(formElements) {
        return [...formElements]
            .reduce((validSoFar, inputCmp) => {
                if (inputCmp.dataset.rich) {
                    this[inputCmp.dataset.validity] = (!inputCmp.required || inputCmp.value);
                    if (!this[inputCmp.dataset.validity]) {
                        inputCmp.focus();
                    }
                    return validSoFar && this[inputCmp.dataset.validity];
                } else {
                    inputCmp.reportValidity();
                    return validSoFar && inputCmp.checkValidity();
                }
            }, true);
    }

    showNotification(title, message, variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }

    /* CLAIM-668 Dijana Bursac */
    ifBpsScore(event){
        console.log('SCORE ON EDIT '+this.bpsScoreCategory);
        if(event.detail.value==='BPS_Score')
        {
            this.bpsScoreCategory = true;
        }else{
            this.bpsScoreCategory = false;
        }
    }
}