//LWC imports
import { LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

//Salesforce Imports
import ClaimsComponents_Error_Prefix from '@salesforce/label/c.ClaimsComponents_Error_Prefix';

//Component Imports
import { callApex, getErrorMessage, clearCache } from 'c/utility';

//Apex
import fetchCovers from "@salesforce/apex/ClaimsDataHandler_LEx.fetchCovers";
import fetchCoverDetail from "@salesforce/apex/ClaimsDataHandler_LEx.fetchCoverDetail";
import fetchProductClaimView from "@salesforce/apex/ClaimsDataHandler_LEx.fetchProductClaimView";
import fetchRecordClaimExternalId from '@salesforce/apex/ClaimsDataHandler_LEx.fetchRecordClaimExternalId';
import fetchBankDetails from '@salesforce/apex/ClaimsDataHandler_LEx.fetchBankDetails';

//Internal Imports
import LOADING_TEMPLATE from './loading.html';
import ERROR_TEMPLATE from './error.html';
import { sortCoversSummaryObject } from './utility.js';

//Constants
const IDENTIFIER_COVER_INFO = 'CoverInfo';
const IDENTIFIER_COVER_DETAIL = 'CoverDetail';
const IDENTIFIER_PRODUCTCLAIMID = 'ProductClaimId';
const IDENTIFIER_RECORD_PRODUCT_CLAIMID = 'ProductClaimRecordId';
const IDENTIFIER_BANK_DETAIL = 'BankDetail';

/**
 * Component to be extended for any Claims Component
 * This contains a collection of helpful methods that can be used
 * to obtain information
 */
export default class ClaimsComponent extends NavigationMixin(LightningElement) {

    /*=========================================================
            Vars
    =========================================================*/

    errorPrefix = ClaimsComponents_Error_Prefix;

    componentLabel;

    @track isLoading = true;
    @track errorMessage;
    @track componentBody;

    /*=========================================================
            "Libraries"
    =========================================================*/

    /**
     * Collection of methods for communicating with the ClaimsDataService
     */
    ClaimsDataService = {

        /**
         * Calls out to the ClaimsDataService and returns active and inactive covers
         * @param {Integer} pPolicyNumber Policy Number to fetch covers for
         * @returns {Object} Cover Summary Information
         */
        fetchCoverInformation: (pPolicyNumber) => {
            clearCache(IDENTIFIER_COVER_INFO + pPolicyNumber); // for preventing future cache issues
            return callApex(
                fetchCovers,
                {
                    pPolicyNumber: pPolicyNumber
                },
                IDENTIFIER_COVER_INFO + pPolicyNumber,
                sortCoversSummaryObject
            );
        },

        /**
         * Calls out to the ClaimsDataService and returns in depth information about the requested cover
         * @param {Integer} pPolicyNumber Policy Number to fetch cover detail for
         * @param {String} pCoverReference Cover Reference
         * @returns {Object} Detailed information about the requested cover
         */
         fetchCoverDetails: (pPolicyNumber, pCoverReference) => {
            clearCache(IDENTIFIER_COVER_DETAIL + pPolicyNumber + pCoverReference); // for preventing future cache issues
            return callApex(
                fetchCoverDetail,
                {
                    pPolicyNumber: pPolicyNumber,
                    pCoverReference: pCoverReference
                },
                IDENTIFIER_COVER_DETAIL + pPolicyNumber + pCoverReference,
            );
        },

        /**
         * Calls out to the ClaimsDataService and returns in depth information about the requested bank details
         * @param {Integer} pPolicyNumber Policy Number to fetch bank detail for
         * @returns {Object} Detailed information about the requested bank info
         */
         fetchBankDetails: (pPolicyNumber) => {
            clearCache(IDENTIFIER_BANK_DETAIL + pPolicyNumber); // for preventing future cache issues
            return callApex(
                fetchBankDetails,
                {
                    policyNumber: pPolicyNumber
                },
                IDENTIFIER_BANK_DETAIL + pPolicyNumber,
            );
        },

        /**
         * Calls out to the ClaimsDataService and returns in depth information about the requested product claim
         * @param {String} pProductClaimId Product Claim Id, which is the 'Claim_External_Id__c' of the Product Claim.
         * @returns {Object} Detailed information about the requested product claim
         */
        fetchProductClaimInformation: (pProductClaimId) => {
            clearCache(IDENTIFIER_PRODUCTCLAIMID + pProductClaimId); // for the fix of CLAIM-975
            return callApex(
                fetchProductClaimView,
                {
                    pProductClaimId: pProductClaimId
                },
                IDENTIFIER_PRODUCTCLAIMID + pProductClaimId,
            );
        },

        /**
         * Fetches the product claim external Id through an apex method using the productClaimRecordId.
         * @param {String} productClaimRecordId Product Claim RecordId, which is the 'Id' of the Product Claim (Case).
        */
        async fetchClaimExternalId(productClaimRecordId) {
            clearCache(IDENTIFIER_RECORD_PRODUCT_CLAIMID + this.recordId); // for the fix of CLAIM-975
            return await callApex(
                fetchRecordClaimExternalId,
                {
                    pRecordId: productClaimRecordId
                },
                IDENTIFIER_RECORD_PRODUCT_CLAIMID + this.recordId
            );
        }
    }

    /**
     * Collection of methods for handling errors
     */
    ErrorHandling = {

        /**
         * Logs an error to the console, then throws an error toast event, and displays an error on the component
         * @param {Error} pEx Exception to log
         */
        logErrorFromException: (pEx) => {
            console.error(pEx);
            this.ErrorHandling.logError(getErrorMessage(pEx, 'An unhandled Exception occurred'));
        },

        /**
         * Throws a Toast Event with the error, then displays the error message in the body of the component
         * @param {String} pMessage Error message to display
         */
        logError: (pMessage) => {
            this.dispatchEvent(new ShowToastEvent({
                title: (this.componentLabel || 'A Component') + ' Has An Error',
                message: pMessage,
                variant: 'error'
            }));
            this.errorMessage = pMessage;
        },

        /**
         * Clears the error message
         */
        clearError: () => this.errorMessage = undefined

    }

    /**
     * Collection of methods for the components State (e.g loading spinner)
     */
    State = {

        /**
         * Displays the component by setting the loading boolean to false
         */
        show: () => this.isLoading = false,

        /**
         * Hides the component behind a loading spinner by setting the loading boolean to true
         */
        hide: () => this.isLoading = true

    }

    /**
     * Collection of navigational methods
     */
    Navigation = {

        /**
         * Generates a URL that when followed will display the `pComponentName` component to
         * the current user
         * @param {String} pComponentName Name of the component to navigate to
         * @param {Object} pAttributes Attributes to populate on target component
         * @returns {String} URL of this redirect
         */
        generateComponentPageLink: async (pComponentName, pAttributes) => {
            return this.Navigation.componentPage(NavigationMixin.GenerateUrl, pComponentName, pAttributes);
        },

        /**
         * Navigates the current user to a screen displaying `pComponentName`
         * @param {String} pComponentName Name of the component to navigate to
         * @param {Object} pAttributes Attributes to populate on target component
         */
        navigateToComponentPage: async (pComponentName, pAttributes) => {
            this.Navigation.componentPage(NavigationMixin.Navigate, pComponentName, pAttributes);
        },

        /**
         * Uses NavigationMixin to either navigate or generate a url to a component page
         * @param {String} pNavigationType Navigation Type (See NavigationMixin)
         * @param {String} pComponentName Name of the component to navigate to
         * @param {Object} pAttributes Attributes to populate on target component
         * @returns {String?} URL of this redirect
         */
        componentPage: async (pNavigationType, pComponentName, pAttributes) => {
            return await this[pNavigationType]({
                type: 'standard__webPage',
                attributes: {
                    url: '/one/one.app#' + btoa(JSON.stringify({
                        componentDef:'c:' + pComponentName,
                        attributes:pAttributes
                    }))
                }
            });
        },

        /**
         * Generates a URL that when followed will display the chosen record's view page
         * @param {String} pObject Object API Name of the given record Id
         * @param {String} pId Salesforce Record Id
         * @returns {String} URL of this redirect
         */
        generateViewRecordLink: async (pObject, pId) => {
            return this.Navigation.recordPage(NavigationMixin.GenerateUrl, pObject, pId);
        },

        /**
         * Navigates the current user to the given record
         * @param {String} pObject Object API Name of the given record Id
         * @param {String} pId Salesforce Record Id
         */
        navigateToRecordPage: async (pObject, pId) => {
            this.Navigation.recordPage(NavigationMixin.Navigate, pObject, pId);
        },

        /**
         * Uses NavigationMixin to either navigate or generate a url to a record page
         * @param {String} pNavigationType Navigation Type (See NavigationMixin)
         * @param {String} pObject Object API Name of the given record Id
         * @param {String} pId Salesforce Record Id
         * @returns {String?} URL of this redirect
         */
        recordPage: async (pNavigationType, pObject, pId) => {
            return await this[pNavigationType]({
                type: 'standard__recordPage',
                attributes: {
                    recordId: pId,
                    objectApiName: pObject,
                    actionName: "view"
                },
            });
        }

    }

    /*=========================================================
            Lightning Element Methods
    =========================================================*/

    /**
     * Conditional Rendering based on loading and component body
     */
    render() {
        if(this.errorMessage) {
            return ERROR_TEMPLATE;
        } else if(this.isLoading || !this.componentBody) {
            return LOADING_TEMPLATE;
        } else {
            return this.componentBody;
        }
    }


}