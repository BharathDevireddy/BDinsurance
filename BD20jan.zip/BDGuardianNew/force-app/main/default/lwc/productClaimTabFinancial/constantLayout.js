export const LAYOUT_DATA = [
    {
        id: 1,
        collapsible: true,
        heading: 'Payment Details',
        headingStyle: 'margin-left:20px; width:95%;',
        useHading: true,
        subSections:[
            {
                id: 0,
                columns: 1,
                isDeletable: false,
                style: 'margin-left: 15px;',
                rows:[
                    {
                        fields: [
                            {
                                label: 'Preferred Payment Day',
                                fieldName: 'preferredPaymentDay',
                                fieldType: 'Picklist',
                                style: 'margin-top: -20px; width: 48%;',
                                isEditable: true,
                                options: [
                                    {label: '1', value: '1'},
                                    {label: '2', value: '2'},
                                    {label: '3', value: '3'},
                                    {label: '4', value: '4'},
                                    {label: '5', value: '5'},
                                    {label: '6', value: '6'},
                                    {label: '7', value: '7'},
                                    {label: '8', value: '8'},
                                    {label: '9', value: '9'},
                                    {label: '10', value: '10'},
                                    {label: '11', value: '11'},
                                    {label: '12', value: '12'},
                                    {label: '13', value: '13'},
                                    {label: '14', value: '14'},
                                    {label: '15', value: '15'},
                                    {label: '16', value: '16'},
                                    {label: '17', value: '17'},
                                    {label: '18', value: '18'},
                                    {label: '19', value: '19'},
                                    {label: '20', value: '20'},
                                    {label: '21', value: '21'},
                                    {label: '22', value: '22'},
                                    {label: '23', value: '23'},
                                    {label: '24', value: '24'},
                                    {label: '25', value: '25'},
                                    {label: '26', value: '26'},
                                    {label: '27', value: '27'},
                                    {label: '28', value: '28'},
                                ],
                                formElementStyle: 'border-bottom:none;'
                            }
                        ]
                    },
                ]
            }
        ]
    },
    {
        id: 2,
        columns: 1,
        collapsible: true,
        heading: 'Pre Incapacity Income',
        headingStyle: 'margin-left:20px; width:95%; margin-bottom:20px;',
        useHading: true,
        subSections: [
            {
                id: 0,
                columns: 1,
                isDeletable: false,
                style: 'margin-bottom:30px; margin-left: 15px;',
                rows:[
                    {
                        fields: [
                            {
                                label: 'Earnings Amount',
                                fieldName: 'earningsAmount',
                                fieldType: 'Currency',
                                style: 'margin-top: -20px; width: 98%;',
                                isEditable: true,
                                formElementStyle: 'border-bottom:none;',
                                fieldTypeAttributes: {
                                    formatter: 'number',
                                    step: '0.01'
                                }
                            },
                            {
                                label: 'Minimum Cover Guarantee',
                                fieldName: 'minimumCoverGuarantee',
                                fieldType: 'Picklist',
                                style: 'margin-top: -20px; width: 98%;',
                                isEditable: true,
                                options: [
                                    {label: 'Yes', value: 'true'},
                                    {label: 'No', value: 'false'}
                                ],
                                formElementStyle: 'border-bottom:none;'
                            },
                            {
                                label: 'ADW Definition',
                                fieldName: 'isADW',
                                fieldType: 'Picklist',
                                style: 'margin-top: -20px; width: 98%;',
                                isEditable: true,
                                options: [
                                    {label: 'Yes', value: 'true'},
                                    {label: 'No', value: 'false'}
                                ],
                                formElementStyle: 'border-bottom:none;'
                            }
                        ]
                    },
                ]
            }
        ]
    },
    {
        id: 3,
        columns: 1,
        useHeading: true,
        heading: 'Continuing Income',
        headingStyle: 'margin-top:-20px;margin-left:20px; width:95%;',
        collapsible: true,
        subSections: [
            {
                id:'income-static',
                columns: 1,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: 'New Continuing Income',
                                fieldName: 'NewContinuingIncomeButton',
                                formElementStyle: 'border-bottom:none; border-top: 3px solid #F3F3F3; margin-top: 10px;',
                                formElementStaticStyle: 'padding-top:10px; padding-bottom:10px; margin-left:15px; width:95%;',
                                fieldType: 'Button'
                            }
                        ]
                    }

                ]
            }
        ]

    },
    {
        id: 4,
        columns: 1,
        collapsible: true,
        heading: 'Notes',
        headingStyle: 'margin-left:20px; width:95%;',
        useHeading: true,
        subSections: [
            {
                id: 0,
                columns: 1,
                isDeletable: false,
                style: 'margin-left: 15px;',
                rows: [
                    {
                        fields: [
                            {
                                fieldName: 'notes',
                                fieldType: 'RichTextArea',
                                style: 'width: 98%;',
                                fieldTypeAttributes: {
                                    formats: [
                                        'font',
                                        'size',
                                        'bold',
                                        'italic',
                                        'underline',
                                        'list',
                                        'indent',
                                        'align',
                                        'link',
                                        'clean',
                                        'table',
                                        'header'
                                    ]
                                },
                                isEditable: true,
                                formElementStyle: 'border-bottom:none;'
                            }
                        ]
                    }
                ]
            }
        ]
    }
];