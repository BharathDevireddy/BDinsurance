import {track, api, wire} from 'lwc';
import { getRecord, getFieldValue, updateRecord } from 'lightning/uiRecordApi';
import CASE_FIELD_CALCULATED from '@salesforce/schema/Case.Draft_Calculated__c';
import CASE_FIELD_CASE_ID from '@salesforce/schema/Case.Id';

//constants
import { LAYOUT_DATA } from './constantLayout.js';
import {CONTINUING_INCOME_LAYOUT_DATA} from "./continuingIncomeLayout";

//Message channel
import ProductClaimDirty__c from '@salesforce/messageChannel/ProductClaimDirty__c';
import ProductClaimRefreshData__c from '@salesforce/messageChannel/ProductClaimRefreshData__c';
import { publish, MessageContext, subscribe, APPLICATION_SCOPE} from 'lightning/messageService';

//LWC
import ClaimsComponent from 'c/claimsComponent';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import {getInitialPayLoad, getProductData, setProductData, getContinuingIncomeTypes, getUnsavedProductData} from 'c/productClaimDataHandler';
import BODY from "./productClaimTabFinancial.html";
export default class ProductClaimTabFinancial extends ClaimsComponent {

    componentLabel = 'Financial';
    componentBody = BODY;

    @wire(MessageContext)
    messageContext;
    subscription = null;

    @api claimExternalId;
    @api recordId;
    @track formData = {};
    @track tabData = {};
    @track continuingIncomeTypeList = {};
    @track tabReadOnlyData = {};
    @track isModalOpen = false;
    @track layoutData = {};
    numberOfNewContinuingIncomes = 0;
    @track isCalculateButtonInactive = false;

    isADWSelected = 'false';
    isMCGSelected = 'false';
    isEarningsAmountChanged = false;

    
    //get the Product Claim Case
    @wire(getRecord, { recordId: '$recordId', fields: [CASE_FIELD_CALCULATED] })
    case

    get isDraftCalculated() {
        return getFieldValue(this.case.data, CASE_FIELD_CALCULATED);
    }

    continuingIncomes = {
        continuingIncomeID: 0,
        continuingIncomeTypeID: 0,
        continuingIncomeType: '',
        source: '',
        amount: 0,
        startDate: '',
        endDate: ''
    }

    connectedCallback() {
        this.invokeApexMethods();
    }

    async invokeApexMethods(){
        let result1;
        let result2;
        try{
            result1 = await getContinuingIncomeTypes();
            result2 = await getInitialPayLoad(this.claimExternalId);
            setTimeout(() => {
                if (this.isDraftCalculated) {
                    this.isCalculateButtonInactive = false;
                    this.template.querySelector('c-product-claim-draft-calculation').calculateDraftData();
                }
            }, 1000);
        } finally{
            this.continuingIncomeTypeList = result1.continuingIncomesTypes;

            this.tabData = JSON.parse(result2.productDataUpdate);
            this.tabReadOnlyData = JSON.parse(result2.productDataReadOnly);
            this.State.show();
            this.subscribeToMessageChannel();
            this.loadContent(false);
        }
    }

    handleFinancialDataChange(e) {
        if(['source', 'amount', 'startDate', 'endDate', 'continuingIncomeTypeID'].indexOf(e.detail[1].replace(/[0-9]/g, '')) === -1) { // check if fieldName which returns form component equals any continuingIncome fieldName in array
            this.tabData.financial.financialAssessmentDraft[e.detail[1]] = e.detail[0];
            if(e.detail[1] == 'isADW')
                this.isADWSelected = e.detail[0];
            if(e.detail[1] == 'minimumCoverGuarantee')
                this.isMCGSelected = e.detail[0];
            if(e.detail[1] == 'earningsAmount'){
                this.isEarningsAmountChanged = true;
            }
        } else {
            if (this.tabData.financial.financialAssessmentDraft.continuingIncomes.length <= 0) {
                this.tabData.financial.financialAssessmentDraft.continuingIncomes.push(this.continuingIncomes);
                this.tabData.financial.financialAssessmentDraft.continuingIncomes[0].toDelete = false;
                this.tabData.financial.financialAssessmentDraft.continuingIncomes[0][e.detail[1]] = e.detail[0];
            } else {
                let continuingIncomeID = e.detail[1].replace(/\D/g, '');
                let continuingIncomeName = e.detail[1].replace(/[0-9]/g, '');

                if (continuingIncomeID !== '0' && continuingIncomeID.toString().includes('0000') === false) {
                    for(let continuingIncome of this.tabData.financial.financialAssessmentDraft.continuingIncomes){
                        if(continuingIncome.continuingIncomeID == continuingIncomeID){
                            continuingIncome[continuingIncomeName] = e.detail[0];
                            break;
                        }
                    }
                } else {
                    let continuingIncomeExists = false;
                    for (let continuingIncome of this.tabData.financial.financialAssessmentDraft.continuingIncomes){
                        if (continuingIncome.continuingIncomeID == continuingIncomeID) {
                            continuingIncome[continuingIncomeName] = e.detail[0];
                            continuingIncomeExists = true;
                            break;
                        }
                    }
                    if (!continuingIncomeExists) {
                        this.continuingIncomes.continuingIncomeID = continuingIncomeID;
                        this.continuingIncomes.toDelete = false;
                        this.continuingIncomes[continuingIncomeName] = e.detail[0];
                        this.tabData.financial.financialAssessmentDraft.continuingIncomes.push(this.continuingIncomes);
                    }
                }
            }
        }
        let dataToSend = JSON.parse(JSON.stringify((this.tabData)));
        console.log('before handelr');
       console.log(JSON.stringify(this.tabData));
        for(let continuingIncome of dataToSend.financial.financialAssessmentDraft.continuingIncomes){
            if(continuingIncome.continuingIncomeID.toString().includes('0000')){
                continuingIncome.continuingIncomeID = '0';
                continuingIncome.continuingIncomeID = '0';
            }
            if(continuingIncome.toDelete == null){
                continuingIncome.toDelete = false;
            }
        }
        this.isCalculateButtonInactive = false;

        if(!(this.isADWSelected == 'true' && this.isMCGSelected == 'true')){
            console.log('if');
            setProductData(dataToSend);
            publish(this.messageContext, ProductClaimDirty__c, {
                componentName: 'Financial Tab'
            });
        }else{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Warning',
                message: 'Minimum Cover Guarantee and ADW Definition fields cannot be both selected on "Yes"!',
                variant: 'info'
            }));
            publish(this.messageContext, ProductClaimRefreshData__c, {msg: 'hide!'});
        }
    }

    handleFinancialButtonClick(e) {
        if (e.detail[0] == 'New Continuing Income') {
            this.createContinuingIncomeSections([], true);
        }
        else if(e.detail[0] == 'Delete'){
            if(e.detail[2] == 'Continuing Income'){
                this.deleteContinuingIncome(e.detail[1]);
            }
        }
        if(!(this.isADWSelected == 'true' && this.isMCGSelected == 'true')) {
            setProductData(this.tabData);
            publish(this.messageContext, ProductClaimDirty__c, {
                componentName: 'Financial Tab'
            });
        }
    }

    async createContinuingIncomeSections(continuingIncomes, isNew) {
        let layout = JSON.parse(JSON.stringify(CONTINUING_INCOME_LAYOUT_DATA));
        if(this.continuingIncomeTypeList !== null){
            layout.rows[0].fields[0].options = this.continuingIncomeTypeList;
        }
        let tempName = '';

        if (!isNew) {
            this.numberOfNewContinuingIncomes = 0;
            if (continuingIncomes.length > 0) {
                this.convertContinuingIncomeTypePickListVal();
                let continuinnIncomeIdExist = true;
                for (let i = 0; i < continuingIncomes.length; i++) {
                    continuinnIncomeIdExist = true;
                    if(continuingIncomes[i].toDelete == false || continuingIncomes[i].toDelete == null){
                        if(continuingIncomes[i].continuingIncomeID === 0 || continuingIncomes[i].continuingIncomeID === '0'){
                            layout.id = continuingIncomes[i].continuingIncomeID = i;
                            continuinnIncomeIdExist = false;
                            layout.isDeletable = false;
                        } else{
                            layout.id = continuingIncomes[i].continuingIncomeID;
                            layout.isDeletable = true;
                        }
                        this.numberOfNewContinuingIncomes++;

                        layout.rows[0].fields[0].fieldName = continuinnIncomeIdExist === true ? 'continuingIncomeTypeID'+continuingIncomes[i].continuingIncomeID : 'continuingIncomeTypeID'+i ;
                        layout.rows[0].fields[1].fieldName = continuinnIncomeIdExist === true ? 'source'+continuingIncomes[i].continuingIncomeID : 'source'+i;
                        layout.rows[0].fields[2].fieldName = continuinnIncomeIdExist === true ? 'amount'+continuingIncomes[i].continuingIncomeID : 'amount'+i;
                        layout.rows[1].fields[0].fieldName = continuinnIncomeIdExist === true ? 'startDate'+continuingIncomes[i].continuingIncomeID : 'startDate'+i;
                        layout.rows[1].fields[1].fieldName = continuinnIncomeIdExist === true ? 'endDate'+continuingIncomes[i].continuingIncomeID : 'endDate'+i;

                        this.layoutData[2].subSections.splice(i - this.numberOfNewContinuingIncomes, 0, layout);

                        layout = JSON.parse(JSON.stringify((CONTINUING_INCOME_LAYOUT_DATA)));
                        if(this.continuingIncomeTypeList !== null){
                            layout.rows[0].fields[0].options = this.continuingIncomeTypeList;
                        }

                        tempName = continuinnIncomeIdExist === true ? 'continuingIncomeTypeID'+continuingIncomes[i].continuingIncomeID : 'continuingIncomeTypeID'+i; this.formData[tempName] = continuingIncomes[i].continuingIncomeTypeID;
                        tempName = continuinnIncomeIdExist === true ? 'source'+continuingIncomes[i].continuingIncomeID : 'source'+i; this.formData[tempName] = continuingIncomes[i].source;
                        tempName = continuinnIncomeIdExist === true ? 'amount'+continuingIncomes[i].continuingIncomeID : 'amount'+i; this.formData[tempName] = continuingIncomes[i].amount;
                        tempName = continuinnIncomeIdExist === true ? 'startDate'+continuingIncomes[i].continuingIncomeID : 'startDate'+i; this.formData[tempName] = continuingIncomes[i].startDate;
                        tempName = continuinnIncomeIdExist === true ? 'endDate'+continuingIncomes[i].continuingIncomeID : 'endDate'+i; this.formData[tempName] = continuingIncomes[i].endDate;
                        this.tabData.financial.financialAssessmentDraft.continuingIncomes[i].toDelete = false;

                    }
                }
            }
            else{
                this.layoutData[2].subSections.splice(0,0,layout);
                this.numberOfNewContinuingIncomes++;
            }
        } else {
            try{
                await this.creatingEmptyContinuingIncomeSection(layout);
            } finally{
                this.template.querySelector('c-form').rebuildLayout();
            }
            this.numberOfNewContinuingIncomes++;
        }
    }

    async creatingEmptyContinuingIncomeSection(layout){
        this.tabData = getUnsavedProductData();
        this.convertDataFromAPIResponseToFormLayout();
        this.formData['source0000' + this.numberOfNewContinuingIncomes.toString()] = '';
        this.formData['amount0000' + this.numberOfNewContinuingIncomes.toString()] = '';
        this.formData['startDate0000' + this.numberOfNewContinuingIncomes.toString()] = '';
        this.formData['endDate0000' + this.numberOfNewContinuingIncomes.toString()] = '';
        this.formData['continuingIncomeTypeID0000' + this.numberOfNewContinuingIncomes.toString()] = '';

        layout.id = '00' + this.numberOfNewContinuingIncomes.toString();
        layout.isDeletable = false;
        layout.rows[0].fields[0].fieldName = 'continuingIncomeTypeID0000' + this.numberOfNewContinuingIncomes.toString();
        layout.rows[0].fields[1].fieldName = 'source0000' + this.numberOfNewContinuingIncomes.toString();
        layout.rows[0].fields[2].fieldName = 'amount0000' + this.numberOfNewContinuingIncomes.toString();
        layout.rows[1].fields[0].fieldName = 'startDate0000' + this.numberOfNewContinuingIncomes.toString();
        layout.rows[1].fields[1].fieldName = 'endDate0000' + this.numberOfNewContinuingIncomes.toString();
        this.layoutData[2].subSections.splice(0 + this.numberOfNewContinuingIncomes, 0, layout);
    }

    handleRefreshMessage(message) {
        if(message.msg == 'Cancelled!'){
            this.numberOfNewContinuingIncomes = this.tabData.financial.financialAssessmentDraft.continuingIncomes.length;
            this.isEarningsAmountChanged = false;
            getProductData(this.claimExternalId).then(result => {
                this.tabData = result;
                this.State.show();
                this.loadContent(true);
            });
        }
        if(message.msg == 'Saved!'){
            if (!this.isCalculateButtonInactive) {
                this.updateDraftField(false);                
            }
            this.fetchDataFromAPI();
            // this.isEarningsAmountChanged = false;
        }
    }

    subscribeToMessageChannel() {
        if (!this.subscription) {
            this.subscription = subscribe(
                this.messageContext,
                ProductClaimRefreshData__c,
                (message) => this.handleRefreshMessage(message),
                {scope: APPLICATION_SCOPE}
            );
        }
    }

    createContinuingIncomeTypePickList(){
        if(this.continuingIncomeTypeList !== null && this.continuingIncomeTypeList.length > 0){
            this.continuingIncomeTypeList = this.continuingIncomeTypeList.map(item =>{
                return {
                    label: item.type,
                    value: item.financialAssessmentContinuingIncomeTypeID.toString() // converting response body to 'options' list which using in picklist continuingIncomeType
                }
            });
        }
    }

    convertContinuingIncomeTypePickListVal(){
        if(this.tabData.financial.financialAssessmentDraft.continuingIncomes.length > 0){
            this.tabData.financial.financialAssessmentDraft.continuingIncomes.forEach((element) =>{
                element.continuingIncomeTypeID = element.continuingIncomeTypeID.toString(); //converting integer type ID (which we get from th API) to String, to display it on picklist field
            });
        }
    }

    loadContent(isRefresh) {
        if (!isRefresh){
            this.createContinuingIncomeTypePickList();
            this.tabData.financial.financialAssessmentDraft.earningsAmount = this.tabData.financial.financialAssessmentDraft.preIncapacityIncome;
        }
        this.convertDataFromAPIResponseToFormLayout();

        if (isRefresh) {
            setTimeout(() => {
                this.template.querySelector('c-form').rebuildLayout();
                this.template.querySelector('c-form').syncFields();
            }, 1);
        }
    }

    convertDataFromAPIResponseToFormLayout(){
        this.layoutData = JSON.parse(JSON.stringify((LAYOUT_DATA)));
        this.formData = {};
        this.numberOfNewContinuingIncomes = 0;
        this.createContinuingIncomeSections(this.tabData.financial.financialAssessmentDraft.continuingIncomes, false);
        this.formData.earningsAmount = this.isEarningsAmountChanged === false ? this.tabData.financial.financialAssessmentDraft.preIncapacityIncome : this.tabData.financial.financialAssessmentDraft.earningsAmount;
        this.formData.preferredPaymentDay = this.tabData.financial.financialAssessmentDraft.preferredPaymentDay !== null && this.tabData.financial.financialAssessmentDraft.preferredPaymentDay !== undefined ? this.tabData.financial.financialAssessmentDraft.preferredPaymentDay.toString() : null;
        this.formData.notes = this.tabData.financial.financialAssessmentDraft.notes;
        this.isADWSelected = this.formData.isADW = this.tabData.financial.financialAssessmentDraft.isADW !== null && this.tabData.financial.financialAssessmentDraft.isADW !== undefined ? this.tabData.financial.financialAssessmentDraft.isADW.toString() : 'false';
        this.isMCGSelected = this.formData.minimumCoverGuarantee = this.tabData.financial.financialAssessmentDraft.minimumCoverGuarantee !== null && this.tabData.financial.financialAssessmentDraft.minimumCoverGuarantee !== undefined ? this.tabData.financial.financialAssessmentDraft.minimumCoverGuarantee.toString() : 'false';
    }

    deleteContinuingIncome(continuingIncomeID) {
        for(let continuingIncome of this.tabData.financial.financialAssessmentDraft.continuingIncomes) {
            if(continuingIncome.continuingIncomeID == continuingIncomeID){
                continuingIncome.toDelete = true;
                this.numberOfNewContinuingIncomes--;
                break;
            }
        }
        this.loadContent(true);
    }

    async fetchDataFromAPI(){
        let result;
        try{
            result = await getInitialPayLoad(this.claimExternalId);
        } finally {
            this.tabData = JSON.parse(result.productDataUpdate);
            this.tabReadOnlyData = JSON.parse(result.productDataReadOnly);
            this.loadContent(true);
        }
    }

    handleCalculateClicked(event) {
        this.isCalculateButtonInactive = true;
    }

    onDraftDataCalculated() {
        this.dispatchEvent(new CustomEvent('draftdatacalculated'));
        this.updateDraftField(true);
    }

    updateDraftField(draftCalculated){
        const fields = {};
        fields[CASE_FIELD_CASE_ID.fieldApiName] = this.recordId;
        fields[CASE_FIELD_CALCULATED.fieldApiName] = draftCalculated;
        const recordInput = {fields: fields};
        updateRecord(recordInput).then((record) => {
        console.log(record);
        });
    }
}