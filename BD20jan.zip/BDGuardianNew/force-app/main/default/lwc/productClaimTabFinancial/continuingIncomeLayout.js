export const CONTINUING_INCOME_LAYOUT_DATA = {
    id: 'income-repeating',
    columns: 2,
    style: 'border: 2px #E3E3E3 solid; margin: 10px 0px 10px 15px; width:95%; padding-bottom:5px; padding-top:3px;',
    isDeletable: false,
    rows : [
        {
            fields: [
                {
                    label: 'Type',
                    fieldName: 'continuingIncomeTypeID',
                    fieldType: 'Picklist',
                    style: 'margin-top: -20px;',
                    isEditable: true,
                    options: [],
                    formElementStyle: 'border-bottom:none;'
                },
                {
                    label: 'Source',
                    fieldName: 'source',
                    fieldType: 'Text',
                    style: 'margin-top: -20px;',
                    isEditable: true,
                    formElementStyle: 'border-bottom:none;'
                },
                {
                    label: 'Amount',
                    fieldName: 'amount',
                    fieldType: 'Currency',
                    style: 'margin-top: -20px;',
                    isEditable: true,
                    formElementStyle: 'border-bottom:none;',
                    fieldTypeAttributes: {
                        formatter: 'number',
                        step: '0.01'
                    }
                }
            ]
        },
        {
            fields: [
                {
                    label: 'Start Date',
                    fieldName: 'startDate',
                    fieldType: 'Date',
                    style: 'margin-top: -20px;',
                    isEditable: true,
                    fieldTypeAttributes: {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                    },
                    formElementStyle: 'border: none;'
                },
                {
                    label: 'End Date',
                    fieldName: 'endDate',
                    fieldType: 'Date',
                    style: 'margin-top: -20px;',
                    isEditable: true,
                    fieldTypeAttributes: {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric'
                    },
                    formElementStyle: 'border: none;'
                }
            ]
        }
    ]
}