import { LightningElement, api } from 'lwc';

export default class UWNotesLauncher extends LightningElement {
	@api recordId;

	openUWNotes(){
		window.open('/apex/Case_UWNotes?Id=' + this.recordId , '_blank', "height=800,width=800");
	}
	openUWNotesPDF(){
		window.open('/apex/Case_UWNote_PDF?Id=' + this.recordId , '_blank');
	}
	openUWNotesWord(){
		window.open('/apex/Case_UWNotes_Worddoc?Id=' + this.recordId , '_blank');
	}
}