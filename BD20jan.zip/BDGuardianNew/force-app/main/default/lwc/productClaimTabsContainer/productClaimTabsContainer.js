//Salesforce Imports
import { api, wire } from 'lwc';
import SYNC_FIELD from '@salesforce/schema/Case.Sync_Status__c';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import ClaimsComponent from 'c/claimsComponent';

//Internal Imports
import BODY from './productClaimTabsContainer.html';

export default class ProductClaimTabsContainer extends ClaimsComponent {

    /*=========================================================
            Parent Component Vars
    =========================================================*/

    componentLabel = 'Product Claim Tabs';
    componentBody = BODY;

    /*=========================================================
           Vars
    =========================================================*/
    @api recordId;
    recordClaimExternalId;
    syncStatus;

    /*=========================================================
           Events
    =========================================================*/

    onTabChange(e) { this.handleTabChange(e); }
    
    /*=========================================================
           Getters
    =========================================================*/
    
    /*=========================================================
           Setup
    =========================================================*/
    
    @wire(getRecord, {recordId:'$recordId', fields: [SYNC_FIELD]})
    myWiredRecord ({data, error}){
        if(data){
            console.log('wire');
            this.syncStatus = data.fields.Sync_Status__c.value;
            console.log(this.syncStatus);
        }
    }
    
    connectedCallbackExecuted = false;
    renderedCallback() {
        console.log('renderedcall');
        console.log(this.connectedCallbackExecuted);
        console.log(this.recordClaimExternalId);
        console.log(this.syncStatus);
        console.log(this.connectedCallbackExecuted && this.syncStatus != 'Error');
        if (!this.recordClaimExternalId) {
          setTimeout(() => {
            if (this.connectedCallbackExecuted && this.syncStatus != 'Error') {
                window.location.reload();
            }
          }, 2000);
        }
    }

    /**
     * Sets up the component. Pulls all data for the child components
     * and then share their relevant data with each of them.
     */
     async connectedCallback() {
        try {
            await Promise.all([
                this.ClaimsDataService.fetchClaimExternalId(this.recordId)
                .then(pVal => this.recordClaimExternalId = pVal)
            ]);
        } catch(ex) {
            this.ErrorHandling.logErrorFromException(ex);
            console.log('there is error!');
        } finally {
            this.State.show();
            if (!this.recordClaimExternalId) {
                this.connectedCallbackExecuted = true;
            }
        }
    }
    
    /*=========================================================
           Handlers
    =========================================================*/

    /**
     * Handles when the user clicks on a new tab. 
     * @param {Event} e OnActive event
     */
    handleTabChange(e) {
        try {
            //let selectedTab = e.target.value;
            //console.log(selectedTab);
        } catch(ex) {
            console.error(ex);
        }
    }

    onDraftDataCalculated() {
        let payoutSchedule = this.template.querySelector('c-product-claim-tab-payout-schedule');
        if (payoutSchedule) {
            payoutSchedule.getPayoutScheduleDraftData();
        }
    }
}