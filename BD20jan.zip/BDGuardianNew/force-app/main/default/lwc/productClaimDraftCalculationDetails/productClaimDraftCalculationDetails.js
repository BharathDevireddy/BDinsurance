import { LightningElement, api } from 'lwc';

export default class ProductClaimDraftCalculationDetails extends LightningElement {
    
    modalVisible=false;
    @api draftCalculationData;
    @api selectedRowInfo;
    calculationStartDate;
    
   /* connectedCallback(){
        console.log('PASSED DATA **** '+this.draftCalculationData);
        console.log('PASSED DATA ROW STRINGIFY **** '+JSON.stringify(this.selectedRowInfo));
        //console.log('period start date '+this.selectedRowInfo[0].periodStart);
       // this.calculationStartDate = this.selectedRowInfo.periodStart;
    }
*/
    renderedCallback(){
        //console.log('PASSED DATA **** '+JSON.stringify(this.draftCalculationData));
        //console.log('PASSED DATA ROW STRINGIFY **** '+JSON.stringify(this.selectedRowInfo));
        //console.log('period start date '+this.selectedRowInfo[0].periodStart);
       // this.calculationStartDate = this.selectedRowInfo.periodStart;
    }

    @api
    showModal() {
        this.modalVisible = true;
    }

    @api
    closeModal() {
        this.modalVisible = false;
    }
}