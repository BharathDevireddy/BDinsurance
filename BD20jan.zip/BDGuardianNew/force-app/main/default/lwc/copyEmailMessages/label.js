import Cancel                               from '@salesforce/label/c.Cancel';
import CopyEmailMessages_Title              from '@salesforce/label/c.CopyEmailMessages_Title';
import CopyEmailMessages_Button_Copy        from '@salesforce/label/c.CopyEmailMessages_Button_Copy';
import CopyEmailMessages_CaseLabel          from '@salesforce/label/c.CopyEmailMessages_CaseLabel';
import CopyEmailMessages_CasePlaceholder    from '@salesforce/label/c.CopyEmailMessages_CasePlaceholder';
import CopyEmailMessages_Success            from '@salesforce/label/c.CopyEmailMessages_Success';
import CopyEmailMessages_Success_RecordLink from '@salesforce/label/c.CopyEmailMessages_Success_RecordLink';
import CopyEmailMessages_Warning_NoEmails   from '@salesforce/label/c.CopyEmailMessages_Warning_NoEmails';

export {
    Cancel,
    CopyEmailMessages_Title,
    CopyEmailMessages_Button_Copy,
    CopyEmailMessages_CaseLabel,
    CopyEmailMessages_CasePlaceholder,
    CopyEmailMessages_Success,
    CopyEmailMessages_Success_RecordLink,
    CopyEmailMessages_Warning_NoEmails,
}