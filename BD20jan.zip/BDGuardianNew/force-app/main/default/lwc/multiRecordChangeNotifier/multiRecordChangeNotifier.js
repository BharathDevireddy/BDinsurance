import { api, LightningElement } from 'lwc';

/**
 * @description This is an extension to the `record-change-notifier` component
 * which supports tracking multiple Ids at a time.
 *
 * @param recordIds The ids of the records which need to be tracked.
 */
export default class MultiRecordChangeNotifier extends LightningElement {
    @api recordIds;

    onChange(e) {
        this.dispatchEvent(new CustomEvent('change', { detail: e.detail }));
    }
}