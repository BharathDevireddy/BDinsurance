import { LightningElement, api } from 'lwc';

export default class PolicyDetailPage extends LightningElement {

    @api policyRef;
    @api selectedCover;

    connectedCallback() {
        try {
            //Change Tab Name
            //Before we change it, make sure we're currently viewing the Policy Detail Page component
            //On it's own and it's not a child component elsewhere
            if('/one/one.app' == window.location.pathname && null != window.location.hash) {
                //Decode hash and decode into a JS object
                let componentBody = JSON.parse(atob(decodeURIComponent(window.location.hash.substring(1))));
                if(null != componentBody?.componentDef && componentBody.componentDef.toLowerCase() == 'c:policyDetailPage'.toLowerCase()) {
                    document.title = this.policyRef + ' | Salesforce'; //Change title to `123456 | Salesforce`
                }
            }
        } catch(ex) {
            console.error(ex); //Gracefully catch the error for now
        }
    }

}