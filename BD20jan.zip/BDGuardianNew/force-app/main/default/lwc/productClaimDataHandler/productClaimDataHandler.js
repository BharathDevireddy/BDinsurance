import updateProductClaim from "@salesforce/apex/ClaimsDataHandler_LEx.updateProductClaim";
import fetchProductClaimView from "@salesforce/apex/ClaimsDataHandler_LEx.fetchProductClaimView";
import calculateProductClaimDraft from '@salesforce/apex/ClaimsDataHandler_LEx.calculateProductClaimDraft';
import fetchContinuingIncomeTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchContinuingIncomeTypes";
import fetchMisRepTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchMisRepTypes";
import fetchMisRepCatTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchMisRepCatTypes";
import fetchMisRepRetro from "@salesforce/apex/ClaimsDataHandler_LEx.fetchMisRepRetro";
import fetchCalculationTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchCalculationTypes";
import fetchDecisionTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchDecisionTypes";
import fetchDecisionSubTypes from "@salesforce/apex/ClaimsDataHandler_LEx.fetchDecisionSubTypes";

import { callApex } from 'c/utility';

var productData = null;
var productDataReadOnly = null;
var originalProductData = null;
var isNextAxtionDate = false;
var isIncapacityDate = false;

export async function getInitialPayLoad(productClaimId) {
    console.log('getInitialPayLoad method');
    var res;
    await fetchProductClaimView({ pProductClaimId: productClaimId }).then(result => {
        var modifiedData = productData;
        console.log(JSON.stringify(JSON.parse(result.productDataUpdate)));
        productData = originalProductData = Object.assign(JSON.parse(result.productDataUpdate),productData);
        productData = Object.assign(productData, modifiedData);
        productDataReadOnly = JSON.parse(result.productDataReadOnly);
        /* try below two lines if the issue still exists for multi save*/
        // var parsedDataup = JSON.parse(result.productDataUpdate);
        // console.log(JSON.stringify({...parsedDataup, ...productData}));
        result['productDataUpdate'] = JSON.stringify(productData);
        console.log(JSON.stringify(productData));
        res = result;
    });
    return res;
}

export async function getProductData(productClaimId) {
    if (productData == null) {
        await fetchProductClaimView({ pProductClaimId: productClaimId }).then(result => {
            productData = originalProductData = JSON.parse(result.productDataUpdate);
        });
    }
    return productData;
}

export async function getContinuingIncomeTypes(){
    var continuingIncomeTypes;
        await fetchContinuingIncomeTypes().then(result => {
            continuingIncomeTypes = result;
        });
    return continuingIncomeTypes;
}

export async function getMisRepTypes(){
    var misRepTypes;
        await fetchMisRepTypes().then(result => {
            misRepTypes = result;
        });
    return misRepTypes;
}

export async function getMisRepCatTypes(){
    var misRepCatTypes;
        await fetchMisRepCatTypes().then(result => {
            misRepCatTypes = result;
        });
    return misRepCatTypes;
}

export async function getMisRepRetro(){
    var misRepRetro;
        await fetchMisRepRetro().then(result => {
            misRepRetro = result;
        });
    return misRepRetro;
}

export async function getCalculationTypes(){
    var calculationTypes;
        await fetchCalculationTypes().then(result => {
            calculationTypes = result;
        });
    return calculationTypes;
}

export async function getDecisionTypes(){
    var decisionTypes;
        await fetchDecisionTypes().then(result => {
            decisionTypes = result;
        });
    return decisionTypes;
}

export async function getDecisionSubTypes(decisionTypeId){
    var decisionSubTypes;
        await fetchDecisionSubTypes({decisionTypeId : decisionTypeId}).then(result => {
            decisionSubTypes = result;
        });
    return decisionSubTypes;
}

export async function getProductReadOnlyData(productClaimId) {
    if (productDataReadOnly == null) {
        await fetchProductClaimView({ pProductClaimId: productClaimId }).then(result => {
            productDataReadOnly = JSON.parse(result.productDataReadOnly);
        });
    }
    return productDataReadOnly;
}

export function setProductData(summaryTabData) {
    console.log('logging');
    console.log(JSON.stringify(productData));
    productData = Object.assign(productData, summaryTabData);
    console.log(JSON.stringify(productData));
    //productData = summaryTabData;
}

export function getUnsavedProductData(){
    if(productData != null)
        return productData;
}

export function cancelSave() {
    productData = JSON.parse(JSON.stringify(originalProductData));
}

export function saveProductData(productClaimId) {
    originalProductData = JSON.parse(JSON.stringify(productData));
    
    var result;
        delete originalProductData.nextActionDate;
        return callApex(
            updateProductClaim,
                {
                    pProductClaimRef: productClaimId,
                    pProductData: JSON.stringify(productData)
                },
                'SaveProductData' + productClaimId,
        );
    
    return false;
}

export function calculateProductClaimDraftData(productClaimId) {
    return callApex(
        calculateProductClaimDraft,
        {
            pRecordId: productClaimId
        },
        'CalculateProductClaimDraft' + productClaimId,
    );
}