declare module "@salesforce/apex/AssessmentEdit_LEx.getAssessment" {
  export default function getAssessment(param: {pAssessmentId: any}): Promise<any>;
}
declare module "@salesforce/apex/AssessmentEdit_LEx.saveAssessment" {
  export default function saveAssessment(param: {pAssessment: any}): Promise<any>;
}
