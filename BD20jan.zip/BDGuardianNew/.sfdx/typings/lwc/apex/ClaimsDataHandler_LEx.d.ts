declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchCovers" {
  export default function fetchCovers(param: {pPolicyNumber: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchCoverDetail" {
  export default function fetchCoverDetail(param: {pPolicyNumber: any, pCoverReference: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchPremiumHistory" {
  export default function fetchPremiumHistory(param: {pPolicyNumber: any, pCoverReference: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchBankDetails" {
  export default function fetchBankDetails(param: {policyNumber: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchProductClaimView" {
  export default function fetchProductClaimView(param: {pProductClaimId: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchContinuingIncomeTypes" {
  export default function fetchContinuingIncomeTypes(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchMisRepTypes" {
  export default function fetchMisRepTypes(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchMisRepCatTypes" {
  export default function fetchMisRepCatTypes(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchMisRepRetro" {
  export default function fetchMisRepRetro(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchCalculationTypes" {
  export default function fetchCalculationTypes(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchDecisionTypes" {
  export default function fetchDecisionTypes(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchDecisionSubTypes" {
  export default function fetchDecisionSubTypes(param: {decisionTypeId: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.fetchRecordClaimExternalId" {
  export default function fetchRecordClaimExternalId(param: {pRecordId: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.updateProductClaim" {
  export default function updateProductClaim(param: {pProductClaimRef: any, pProductData: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.calculateProductClaimDraft" {
  export default function calculateProductClaimDraft(param: {pRecordId: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsDataHandler_LEx.submitForApproval" {
  export default function submitForApproval(param: {pRecordId: any}): Promise<any>;
}
