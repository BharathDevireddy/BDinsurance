declare module "@salesforce/apex/CoverRoles_LEx.fetchAccountIdsFromPolicyNumber" {
  export default function fetchAccountIdsFromPolicyNumber(param: {pPolicyNumbers: any}): Promise<any>;
}
