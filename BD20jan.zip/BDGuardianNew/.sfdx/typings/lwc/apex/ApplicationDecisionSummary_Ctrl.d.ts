declare module "@salesforce/apex/ApplicationDecisionSummary_Ctrl.fetchApplicationMembers" {
  export default function fetchApplicationMembers(param: {applicationId: any}): Promise<any>;
}
declare module "@salesforce/apex/ApplicationDecisionSummary_Ctrl.fetchCaseApplicationMembers" {
  export default function fetchCaseApplicationMembers(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/ApplicationDecisionSummary_Ctrl.fetchCovers" {
  export default function fetchCovers(param: {memberId: any}): Promise<any>;
}
declare module "@salesforce/apex/ApplicationDecisionSummary_Ctrl.fetchUnderwritingOutcomes" {
  export default function fetchUnderwritingOutcomes(param: {memberId: any}): Promise<any>;
}
declare module "@salesforce/apex/ApplicationDecisionSummary_Ctrl.fetchValidateStatus" {
  export default function fetchValidateStatus(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/ApplicationDecisionSummary_Ctrl.makeDecision" {
  export default function makeDecision(param: {caseId: any}): Promise<any>;
}
