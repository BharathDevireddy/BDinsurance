declare module "@salesforce/apex/DisableExtranet_Ctrl.disableClientMyGuardianAccount" {
  export default function disableClientMyGuardianAccount(param: {accountId: any}): Promise<any>;
}
declare module "@salesforce/apex/DisableExtranet_Ctrl.disableAdviserDashboard" {
  export default function disableAdviserDashboard(param: {adviserId: any}): Promise<any>;
}
