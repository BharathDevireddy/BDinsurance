declare module "@salesforce/apex/PremiumHistory_LEx.fetchPremiumHistoryConfiguration" {
  export default function fetchPremiumHistoryConfiguration(): Promise<any>;
}
