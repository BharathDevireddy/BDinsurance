declare module "@salesforce/apex/PasswordResetAdviserCustomerLCController.NewGuid" {
  export default function NewGuid(): Promise<any>;
}
declare module "@salesforce/apex/PasswordResetAdviserCustomerLCController.getCharAtIndex" {
  export default function getCharAtIndex(param: {str: any, index: any}): Promise<any>;
}
declare module "@salesforce/apex/PasswordResetAdviserCustomerLCController.sendDataToProcess" {
  export default function sendDataToProcess(param: {Idrec: any, SobjectName: any}): Promise<any>;
}
