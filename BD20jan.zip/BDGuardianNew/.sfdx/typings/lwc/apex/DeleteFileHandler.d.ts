declare module "@salesforce/apex/DeleteFileHandler.getFiles" {
  export default function getFiles(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/DeleteFileHandler.deleteFiles" {
  export default function deleteFiles(param: {docId: any}): Promise<any>;
}
