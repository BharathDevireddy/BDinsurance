declare module "@salesforce/apex/UserIdUpdateAdviserCustomerLCController.NewGuid" {
  export default function NewGuid(): Promise<any>;
}
declare module "@salesforce/apex/UserIdUpdateAdviserCustomerLCController.getCharAtIndex" {
  export default function getCharAtIndex(param: {str: any, index: any}): Promise<any>;
}
declare module "@salesforce/apex/UserIdUpdateAdviserCustomerLCController.getEmailaddress" {
  export default function getEmailaddress(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UserIdUpdateAdviserCustomerLCController.sendDataToProcess" {
  export default function sendDataToProcess(param: {Idrec: any, newEmailAddr: any}): Promise<any>;
}
