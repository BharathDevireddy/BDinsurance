declare module "@salesforce/apex/AppMemberReturnMUW_Ctrl.canBeReturnedToUnderwriting" {
  export default function canBeReturnedToUnderwriting(param: {applicationMemberId: any}): Promise<any>;
}
declare module "@salesforce/apex/AppMemberReturnMUW_Ctrl.userHasPermission" {
  export default function userHasPermission(): Promise<any>;
}
declare module "@salesforce/apex/AppMemberReturnMUW_Ctrl.returnToUnderwriting" {
  export default function returnToUnderwriting(param: {applicationMemberId: any}): Promise<any>;
}
