declare module "@salesforce/apex/DecisionDocDownload_Ctrl.fetchDecisionDocument" {
  export default function fetchDecisionDocument(param: {applicationId: any}): Promise<any>;
}
declare module "@salesforce/apex/DecisionDocDownload_Ctrl.isThisPPApplication" {
  export default function isThisPPApplication(param: {appId: any}): Promise<any>;
}
