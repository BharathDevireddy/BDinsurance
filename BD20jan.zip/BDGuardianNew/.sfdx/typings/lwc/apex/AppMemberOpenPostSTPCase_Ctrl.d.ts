declare module "@salesforce/apex/AppMemberOpenPostSTPCase_Ctrl.createPostSTPCase" {
  export default function createPostSTPCase(param: {appMemberId: any}): Promise<any>;
}
