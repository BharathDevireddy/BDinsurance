declare module "@salesforce/apex/LExToolkit.fetchRecordType" {
  export default function fetchRecordType(param: {pObjectName: any, pRecordTypeDeveloperName: any}): Promise<any>;
}
