declare module "@salesforce/apex/URE_Enquiry_Canvas_Ctrl.getEnquiryId" {
  export default function getEnquiryId(param: {applicationMemberId: any}): Promise<any>;
}
