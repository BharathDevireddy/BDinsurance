declare module "@salesforce/apex/AssessmentList_LEx.getAssessmentData" {
  export default function getAssessmentData(param: {pFilters: any, pParentCaseId: any}): Promise<any>;
}
