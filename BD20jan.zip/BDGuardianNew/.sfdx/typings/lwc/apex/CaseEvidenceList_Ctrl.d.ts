declare module "@salesforce/apex/CaseEvidenceList_Ctrl.fetchEvidence" {
  export default function fetchEvidence(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseEvidenceList_Ctrl.massSetStatus" {
  export default function massSetStatus(param: {evidenceIds: any, status: any}): Promise<any>;
}
