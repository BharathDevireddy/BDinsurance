declare module "@salesforce/apex/ProductClaimsCaseSummary_LEx.getProductClaimCases" {
  export default function getProductClaimCases(param: {policyClaimId: any}): Promise<any>;
}
