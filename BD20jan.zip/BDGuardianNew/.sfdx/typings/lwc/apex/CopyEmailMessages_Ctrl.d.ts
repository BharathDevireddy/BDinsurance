declare module "@salesforce/apex/CopyEmailMessages_Ctrl.mostRecentCases" {
  export default function mostRecentCases(param: {baseRecordId: any}): Promise<any>;
}
declare module "@salesforce/apex/CopyEmailMessages_Ctrl.searchCases" {
  export default function searchCases(param: {query: any, baseRecordId: any}): Promise<any>;
}
declare module "@salesforce/apex/CopyEmailMessages_Ctrl.copyEmails" {
  export default function copyEmails(param: {sourceId: any, destId: any}): Promise<any>;
}
