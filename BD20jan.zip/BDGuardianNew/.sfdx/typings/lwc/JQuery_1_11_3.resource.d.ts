declare module "@salesforce/resourceUrl/JQuery_1_11_3" {
    var JQuery_1_11_3: string;
    export default JQuery_1_11_3;
}