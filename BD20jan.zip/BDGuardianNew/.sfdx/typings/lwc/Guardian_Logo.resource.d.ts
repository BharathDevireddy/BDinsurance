declare module "@salesforce/resourceUrl/Guardian_Logo" {
    var Guardian_Logo: string;
    export default Guardian_Logo;
}