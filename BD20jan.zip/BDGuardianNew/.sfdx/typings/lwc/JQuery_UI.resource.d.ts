declare module "@salesforce/resourceUrl/JQuery_UI" {
    var JQuery_UI: string;
    export default JQuery_UI;
}