declare module "@salesforce/resourceUrl/JQuery_highlight" {
    var JQuery_highlight: string;
    export default JQuery_highlight;
}