declare module "@salesforce/resourceUrl/ServiceCloudLogo" {
    var ServiceCloudLogo: string;
    export default ServiceCloudLogo;
}