declare module "@salesforce/resourceUrl/JQuery_dataTables" {
    var JQuery_dataTables: string;
    export default JQuery_dataTables;
}