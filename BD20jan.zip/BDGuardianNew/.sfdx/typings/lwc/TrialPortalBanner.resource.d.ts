declare module "@salesforce/resourceUrl/TrialPortalBanner" {
    var TrialPortalBanner: string;
    export default TrialPortalBanner;
}