import { api, LightningElement, track } from 'lwc';

export default class InputSearch extends LightningElement {
    @api label       = '';
    @api placeholder = "Search ...";
    @api variant     = "standard";
    @api iconName    = null;

    @api
    get value()  { return this.selectedRecord.value; }
    set value(v) {
        if(v) {
            if('string' === typeof v) {
                if(this.selectedRecord.value !== v) {
                    const record = {
                        label:    '',
                        value:    v,
                        iconName: this.iconName,
                    };
                    this.selectedRecord = record;
                    new Promise(resolve => {
                        this.dispatchEvent(new CustomEvent('textvalue', {
                            detail: {
                                value:   v,
                                respond: resolve,
                            }
                        }))
                    }).then(recordData => {
                        if(this.selectedRecord === record) {
                            this.selectedRecord = recordData;
                        }
                    });
                }
            } else {
                this.selectedRecord = v;
            }
        } else {
            this.selectedRecord = { };
        }
    }

    @api
    get dropdownAlignment() { return this._alignment; }
    set dropdownAlignment(v) { this.setDropdownAlignment(v); }

    @api
    get name() { return this.selectedRecord && this.selectedRecord.label; }

    @track inputHasFocus  = false;
    @track loadingResults = false;
    @track results        = null;
    @track selectedRecord = { };

    _alignment     = 'left';
    latestReq      = 0;
    searchQuery    = null;
    recalcListener = null;
    ignoreBlur     = false;

    get showDropdown()   { return this.inputHasFocus && (this.loadingResults || this.results.length > 0); }

    get elementClass()   { return `slds-form-element${'label-inline' === this.variant ? ' slds-form-element_horizontal' : ''}`; }
    get comboboxClass()  { return `slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click${ this.showDropdown ? ' slds-is-open' : '' } flex-direction-row`; }
    get containerClass() { return `slds-combobox_container${ this.value ? ' slds-has-selection' : '' } flex-direction-row`; }
    get showLabel()      { return 'label-hidden' !== this.variant; }

    @api
    clear() {
        this.removeSelected();
    }

    connectedCallback() {
        if('auto' === this.dropdownAlignment && !this.recalcListener) {
            this.setDropdownAlignment(this.dropdownAlignment);
        }
    }
    disconnectedCallback() {
        if(this.recalcListener) {
            window.removeEventListener('resize', this.recalcListener);
            window.removeEventListener('scroll', this.recalcListener);
        }
    }

    recalculateDropdownPosition() {
        if(this.dropdownAlignment !== 'auto') return;

        const dropdown  = this.template.querySelector('[data-dropdown]');
        const combobox  = this.template.querySelector('[data-combobox]');
        const container = this.template.querySelector('[data-combobox-container]');

        dropdown.style.position = 'fixed';
        dropdown.style.zIndex   = 9001;

        // This is a horrible workaround, please remove when/if possible
        //
        // We need the position of the dropdown box to be `fixed` so that it
        // will work in modals - i.e. it will drop outside of the modal body.
        // The idea is that we get the position of the textbox and then position
        // the dropdown next to it. Unfortunately position `0,0` in modals is
        // not position 0,0 of the window like it should be, but it's the left
        // side of the modal and top of the window. So we can't just set the
        // positions directly, otherwise the coordinates would be off.
        //
        // Instead we first calculate the offset by getting the rect of the
        // dropdown at "0,0". Then we offset the coordinates we get from doing
        // the above by those, so that we get the "relative" coordinates from
        // what the dropdown considers to be 0,0.
        dropdown.style.top   = `0px`;
        dropdown.style.left  = `0px`;

        // If `slds-is-open` isn't part of the combobox then the element doesn't
        // exist (display: none) so the bounding rect doesn't exist either. The
        // element won't be rerendered until after this function has run, so the
        // classlist might not be updated yet, so just bodge it in here so that
        // we can calculate the offset of 0,0.
        const hasIsOpen = combobox.classList.contains('slds-is-open');
        if(!hasIsOpen) combobox.classList.add('slds-is-open');

        const drect = dropdown.getBoundingClientRect();
        const doffsetx = drect.left;
        const doffsety = drect.top;

        // if `slds-is-open` wasn't originally on the element, remove it, just
        // in case
        if(!hasIsOpen) combobox.classList.remove('slds-is-open');

        const crect = container.getBoundingClientRect();

        dropdown.style.width = `${crect.width}px`;
        dropdown.style.top   = `${crect.bottom - doffsety}px`;
        dropdown.style.left  = `${crect.left   - doffsetx}px`;
        dropdown.style.right = `auto`;
    }

    async setSearchQuery(query) {
        if(this.searchQuery !== query || !query) {
            this.loadingResults = true;

            this.recalculateDropdownPosition();

            const reqId = ++this.latestReq;
            this.searchQuery = query || '';

            const results = await new Promise(resolve => {
                this.dispatchEvent(new CustomEvent('search', {
                    detail: {
                        respond:  resolve,
                        query:    this.searchQuery,
                        isLatest: () => reqId === this.latestReq,
                    }
                }));
            });
            if(reqId === this.latestReq) {
                if(results && Array.isArray(results)) {
                    this.results = results.map(({ iconName, value, label, meta }) => ({
                        iconName: iconName || this.iconName,
                        value:    value,
                        label:    label,
                        class:    `slds-media slds-listbox__option slds-listbox__option_entity${ meta ? " slds-listbox__option_has-meta" : "" }`,
                        meta:     meta,
                    }));
                } else {
                    console.warn('Invalid results received');
                    console.warn(results);
                    this.results = [ ];
                }
                this.loadingResults = false;
            }
        }
    }
    searchChanged(e) {
        this.setSearchQuery(e.target.value)
    }
    searchFocused() {
        // If this is the first time focusing, fetch the search results for an
        // empty string as if it were being "typed"
        if(null === this.results) {
            this.results = [ ];
            this.setSearchQuery('');
        }
        this.recalculateDropdownPosition();
        this.inputHasFocus = true;
    }
    searchBlurred(e) {
        if(this.ignoreBlur) {
            this.ignoreBlur = false;
            // We want to refocus the element - it shouldn't have been blurred
            e.target.focus();
        } else {
            this.inputHasFocus = false;
        }
    }
    clearSearchQuery() {
        this.setSearchQuery('');
        this.template.querySelector('input').value = '';
    }
    listMousedown() {
        // If we mousedown on an element on the list, we will immediately blur
        // the search box, which will happen before the `onclick` event is
        // fired, so this tells the element to ignore the next `blur` event
        this.ignoreBlur = true;
    }
    resultSelected(e) {
        const idx = e.currentTarget.dataset.targetIdx;
        this.clearSearchQuery();
        this.selectedRecord = this.results[idx];
        this.dispatchEvent(new CustomEvent('change', {
            detail: Object.assign({ }, this.selectedRecord),
        }));
    }
    removeSelected() {
        this.selectedRecord = { };
        this.clearSearchQuery();
        this.dispatchEvent(new CustomEvent('change', {
            detail: {
                value: null
            }
        }));
    }

    setDropdownAlignment(value) {
        if('auto' === value) {
            if(!this.recalcListener) {
                // Add some callbacks to handling scrolling and window resizing
                // so that the dropdown is consistently in the correct position
                this.recalcListener = () => {
                    if(this.showDropdown) {
                        this.recalculateDropdownPosition();
                    }
                }
                window.addEventListener('scroll', this.recalcListener);
                window.addEventListener('resize', this.recalcListener);
                // TODO this doesn't handle rerenders which move this element
                // without forcing the element itself to rerender (e.g. adding a
                // child to the DOM above this element). Note that this doesn't
                // work with lightningcomboboxes either.

                this.recalcListener();
            }
        } else {
            if(this.recalcListener) {
                window.removeEventListener('resize', this.recalcListener);
                window.removeEventListener('scroll', this.recalcListener);

                this.recalcListener = null;
            }
        }
        this._alignment = value;
    }
}