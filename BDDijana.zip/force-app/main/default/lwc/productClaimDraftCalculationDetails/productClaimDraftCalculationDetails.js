import { LightningElement, api } from 'lwc';
import { mockObject } from './mockObject';
import IPLabel from '@salesforce/label/c.Income_Protection_Calculation';
import ADWLabel from '@salesforce/label/c.Activities_of_Daily_Work_Calculation';

export default class ProductClaimDraftCalculationDetails extends LightningElement {
    
    modalVisible=false;
    @api draftCalculationData;
    @api selectedRowInfo;
    //calculationStartDate;
    calcData;
    calculationName;
    
    connectedCallback(){
        this.calcData = JSON.parse(JSON.stringify(mockObject));
        if(Object.keys(this.calcData.adwCalculation).length === 0)
        {
            this.calculationName = IPLabel;
        }
        else if(Object.keys(this.calcData.ipCalculation).length === 0){
            this.calculationName = ADWLabel;
        }
    }

    @api
    showModal() {
        this.modalVisible = true;
    }

    @api
    closeModal() {
        this.modalVisible = false;
    }
}