export const COLUMNS = [
  {
    label: 'Detail view',
    type: 'button-icon',
    fixedWidth: 90,
    typeAttributes:
    {
      iconName: 'utility:preview',
      name: 'preview'
    }
  },
  {
    label: 'Expense ID', fieldName: 'productClaimExpenseID', type: 'text',
    typeAttributes: { linkify: true }
  },
  { label: 'Expense Type', fieldName: 'productClaimExpenseType' },
  { label: 'Description', fieldName: 'description' },
  { label: 'Amount', fieldName: 'amount' },
  { label: 'Payee', fieldName: 'payee' },
  { label: 'Approval  Date', fieldName: 'expenseDate' },
  {
    label: 'Delete',
    type: 'button-icon',
    fixedWidth: 90,
    typeAttributes:
    {
      iconName: 'utility:delete',
      name: 'delete'
    }
  }
];

export const EXPENSE_TYPE = [
  { label: 'Investigative', value: 1 },
  { label: 'Medical', value: 2 },
  { label: 'Rehabilitation', value: 3 },
  { label: 'Other', value: 4 }
]

export const EXPENSE_TYPE_INVESTIGATIVE = [
  { label: 'Desk Top Enquiries', value: 8 },
  { label: 'Forensic Accounting', value: 9 },
  { label: 'Interview', value: 10 },
  { label: 'PI', value: 11 },
  { label: 'Surveillance', value: 12 },
  { label: 'Other', value: 1 }
]

export const EXPENSE_TYPE_MEDICAL = [
  { label: 'Consultant Reports', value: 2 },
  { label: 'GP Reports / Records', value: 3 },
  { label: 'Functional Capacity Evaluation', value: 4 },
  { label: 'Independent Medical Examination', value: 5 },
  { label: 'Other Medical Specialist', value: 6 },
  { label: 'Desktop Review of Medical Evidence', value: 7 }
]

export const EXPENSE_TYPE_REHABILITATION = [
  { label: 'Initial Assessment', value: 13 },
  { label: 'In Claim Assessment Review', value: 14 },
  { label: 'Rehab - Combined Treatment & Vocational', value: 15 },
  { label: 'Rehab - Treatment ', value: 16 },
  { label: 'Rehab - Vocationa', value: 17 },
  { label: 'Treatment funding', value: 18 }
]

export const EXPENSE_TYPE_OTHER = [
  { label: 'Accountant', value: 19 },
  { label: 'Legal', value: 20 },
  { label: 'Policyholder - expense', value: 21 },
  { label: 'Policyholder - HALO', value: 22 },
  { label: 'Other', value: 1 }
]

export const EXPENSE_OBJECT = [
  { label: 'productClaimExpenseDescription', value: '' },
  { label: 'maximumAmountPermitted', value: 0 },
  { label: 'amount', value: 0 },
  { label: 'amountReclaimable', value: 0 },
  { label: 'additionalInformation', value: '' },
  { label: 'payee', value: '' },
  { label: 'invoiceNumber', value: '' },
  { label: 'descriptione', value: '' },
  { label: 'salesForceCaseNumber', value: '' },
  { label: 'financeNotificationDate', value: '' },
  { label: 'expenseDate', value: '' }
]