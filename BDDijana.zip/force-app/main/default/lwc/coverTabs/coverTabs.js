//LWC Imports
import { api, track } from 'lwc';

//Component Imports
import ClaimsComponent from 'c/claimsComponent';

//Internal Imports
import BODY from './coverTabs.html';

export default class CoverTabs extends ClaimsComponent {

    /*=========================================================
            Parent Component Vars
    =========================================================*/

    componentLabel = 'Cover Tabs';
    componentBody = BODY;

    /*=========================================================
           Vars
    =========================================================*/
    
    @api policyref;
    @api coverDefault;

    @track isLoading = true;
    @track openTab;
    @track tabs = [];

    @track errorMessage;

    /*=========================================================
           Events
    =========================================================*/

    onTabChange(e) { this.handleTabChange(e); }
    
    /*=========================================================
           Getters
    =========================================================*/
    
    /*=========================================================
           Setup
    =========================================================*/
    
    /**
     * Sets up the component. Pulls Cover Summary info, then creates tabs based on active/inactive covers,
     * then sets the open tab to be the one passed in `this.coverDefault`
     */
    async connectedCallback() {
        try {
            //Grab covers
            let covers = await this.ClaimsDataService.fetchCoverInformation(this.policyref);
            //Create new tabs
            let index = 0;
            let activeTab = this.createTab(`Active (${covers.Active.length})`, index++, covers.Active);
            let inactiveTab = this.createTab(`Inactive (${covers.Inactive.length})`, index++, covers.Inactive);
            //Update tabs
            activeTab.active = true;
            inactiveTab.active = false;
            //Add tabs to the array
            this.tabs.push(activeTab, inactiveTab);
            //Set the default open tab, defaulting to the active covers
            this.openTab = inactiveTab.openTab != null ? inactiveTab.id : activeTab.id;
        } catch(ex) {
            this.ErrorHandling.logErrorFromException(ex);
        } finally {
            this.State.show();
        }
    }
    
    /*=========================================================
           Helpers
    =========================================================*/

    /**
     * Creates a tab based on the passed information. This will parse the covers into
     * a new tab format. This method is in an attempt to prevent duplicated code from ConnectedCallback
     * @param {String} pLabel Tab Label
     * @param {String} pValue Tab Value
     * @param {Object[]} pCovers Covers for sub tabs
     * @returns {Object} The new tab
     */
    createTab(pLabel, pValue, pCovers) {
        let coverIndex = 0;
        let newTab = {
            id: pValue,
            tabLabel: pLabel,
            covers: pCovers.map(cover => ({
                id: coverIndex++,
                tabLabel: cover.TabLabel,
                coverReference: cover.CoverReference
            }))
        }
        newTab.openTab = newTab.covers.find(cover => cover.coverReference == this.coverDefault)?.id;
        return newTab;
    }
    
    /*=========================================================
           Handlers
    =========================================================*/

    /**
     * Handles when the user clicks on a new tab. Currently this method will update the locally
     * stored "OpenTab" variable for either the top level tabs or any of the child tabs, we store
     * this information in case the tabs need to be refreshed, the same tab will be open.
     * @param {Event} e OnActive event
     */
    handleTabChange(e) {
        try {
            let parentTabId = e.target.getAttribute('data-parent-tab');
            let newVal = e.target.value;
            if(parentTabId) {
                let parentTab = this.tabs.find(tab => tab.id == parentTabId);
                if(parentTab) parentTab.openTab = newVal;
            } else {
                this.openTab = newVal;
            }
        } catch(ex) {
            console.error(ex);
        }
    }

}