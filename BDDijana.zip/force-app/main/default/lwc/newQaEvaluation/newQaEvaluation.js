import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getDefaults from "@salesforce/apex/newQaEvaluation_LEX.findDefaultVals";
import { encodeDefaultFieldValues } from 'lightning/pageReferenceUtils';


export default class NewQaEvaluation extends NavigationMixin(LightningElement) {
	isExecuting = false;    

	@api recordId;

   @api async invoke() {
		
		let defaultsObj = await getDefaults({CaseId: this.recordId});
		
		// console.log('defaultsObj stringed =' + JSON.stringify(defaultsObj));

		const defaultValues = encodeDefaultFieldValues({
			// recordTypeId: defaultsObj.RecordTypeId,
			Case__c:this.recordId,
			Status__c:'Draft',
			Life_Decision_correct__c: defaultsObj.lifeCover ? '' : 'N/A',
			Life_Decision_entered_correctly__c: defaultsObj.lifeCover ? '' : 'N/A',
			CI_Decision_correct__c: defaultsObj.CICover ? '' : 'N/A',
			CI_Decision_entered_correctly__c: defaultsObj.CICover ? '' : 'N/A',
			ACI_Decision_correct__c: defaultsObj.ACICover ? '' : 'N/A',
			ACI_Decision_entered_correct__c: defaultsObj.ACICover ? '' : 'N/A',
			TPD_Decision_correct__c: defaultsObj.TPDCover ? '' : 'N/A',
			TPD_Decision_entered_correctly__c: defaultsObj.TPDCover ? '' : 'N/A'
	  	});

	  	console.log(defaultValues);

	  	this[NavigationMixin.GenerateUrl]({
			type: 'standard__objectPage',
			attributes: {
				 objectApiName: 'QA_Evaluation__c',
				 actionName: 'new'
			},
			state: {
				defaultFieldValues: defaultValues,
				recordTypeId:defaultsObj.RecordTypeId
			}
	  	}).then(url => {
			window.open(url, "_blank" , "height=800,width=800");
	  	});
   }

	
}