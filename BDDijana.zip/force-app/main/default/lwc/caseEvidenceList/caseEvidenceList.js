import { api, track, wire, LightningElement } from 'lwc';

import * as empApi         from 'lightning/empApi';
import { NavigationMixin } from 'lightning/navigation';
import { getObjectInfos }  from 'lightning/uiObjectInfoApi';

import { deleteRecord, getRecord, getFieldValue, getRecordNotifyChange } from 'lightning/uiRecordApi';

import * as Label  from './label.js';
import Schema      from './schema.js';
import * as Apex   from './apex.js';

import CURRENT_USER_ID from '@salesforce/user/Id';

import { GetObjectInfosConverter, WireConverter, getErrorMessage, getIconNameFromUrl } from 'c/utility';

const CASE_REQUIRED_FIELDS = [
    Schema.Case.Application_Member__c,
];

function toUrlEncodedString(obj) {
    const chunks = [ ];
    for(const [key, value] of Object.entries(obj)) {
        chunks.push(`${encodeURI(key)}=${null == value ? '' : encodeURI(value)}`);
    }
    return chunks.join(',');
}
function sortByField(field, direction) {
    const mul = direction === 'desc' ? -1 : direction === 'asc' ? 1 : 0;
    return (lhs, rhs) => {
        let lhsValue = lhs[field];
        let rhsValue = rhs[field];
        if(null == lhsValue) lhsValue = '';
        if(null == rhsValue) rhsValue = '';
        return (lhsValue > rhsValue ? 1 : lhsValue < rhsValue ? -1 : 0) * mul;
    };
}

class EvidenceWrapper {
    constructor(data) {
        Object.assign(this, data);
    }

    get recordLink() { return `/lightning/r/${Schema.Evidence__c.sObjectType.objectApiName}/${this.Id}/view`; }

    static buildColumns(objectInfo) {
        const actions = [ ];
        if(objectInfo.updateable) {
            actions.push({
                label: Label.CaseEvidenceList_Action_Edit,
                name:  'edit',
            });
        }
        if(objectInfo.deletable) {
            actions.push({
                label: Label.CaseEvidenceList_Action_Delete,
                name:  'delete',
            });
        }
        return [
            {
                label:     objectInfo.fields[Schema.Evidence__c.Name.fieldApiName].label,
                fieldName: 'recordLink',
                type:      'url',
                sortable:  true,
                typeAttributes: {
                    label: {
                        fieldName: Schema.Evidence__c.Name.fieldApiName,
                    },
                    tooltip: {
                        fieldName: Schema.Evidence__c.Name.fieldApiName,
                    },
                }
            },
            {
                label:     objectInfo.fields[Schema.Evidence__c.Type__c.fieldApiName].label,
                fieldName: Schema.Evidence__c.Type__c.fieldApiName,
                type:      'text',
                sortable:  true,
            },
            {
                label:     objectInfo.fields[Schema.Evidence__c.SubtypeSubjects__c.fieldApiName].label,
                fieldName: Schema.Evidence__c.SubtypeSubjects__c.fieldApiName,
                type:      'text',
                sortable:  true,
            },
            {
                label:     objectInfo.fields[Schema.Evidence__c.Status__c.fieldApiName].label,
                fieldName: Schema.Evidence__c.Status__c.fieldApiName,
                type:      'text',
                sortable:  true,
            },
            {
                label:     objectInfo.fields[Schema.Evidence__c.LastModifiedDate.fieldApiName].label,
                fieldName: Schema.Evidence__c.LastModifiedDate.fieldApiName,
                type:      'date',
                sortable:  true,
                typeAttributes: {
                    year:   '2-digit',
                    month:  '2-digit',
                    day:    '2-digit',
                    hour:   '2-digit',
                    minute: '2-digit',
                }
            },
            {
                label:     objectInfo.fields[Schema.Evidence__c.Instructions__c.fieldApiName].label,
                fieldName: Schema.Evidence__c.Instructions__c.fieldApiName,
                type:      'text',
                sortable:  true,
            },
            {
                label:          '',
                type:           'action',
                sortable:       false,
                typeAttributes: {
                    rowActions: actions,
                }
            }
        ];
    }
}

export default class CaseEvidenceList extends NavigationMixin(LightningElement) {
    @api
    recordId;

    @track error               = null;
    @track evidenceRecordsById = { };
    @track fullViewUrl         = '';
    @track loading             = 'Loading data';
    @track objectDetails       = { };
    @track sortBy              = Schema.Evidence__c.CreatedDate.fieldApiName;
    @track sortDirection       = 'asc';
    @track selectedRecords     = [ ];
    @track showSetStatusModal  = false;
    @track selectedStatus      = null;
    @track modalLoading        = null;
    @track availableStatuses   = [ ];
    @track deleteRecordId      = null;

    availableStatuses = [ ];
    caseRecord = { };

    get evidenceRecords()         { return Object.values(this.evidenceRecordsById).sort(sortByField(this.sortBy, this.sortDirection)); }
    get disableSetStatus()        { return 0 === this.selectedRecords.length; }
    get disableConfirmSetStatus() { return !this.selectedStatus; }
    get tableTitle()              { return `${this.objectDetails.labelPlural || ''} (${Object.keys(this.evidenceRecordsById).length})`; }
    get showDeleteEvidenceModal() { return !!this.deleteRecordId; }

    get refreshIds() {
        return [
            {
                recordId: this.recordId,
                objectApiName: Schema.Case.sObjectType.objectApiName,
            },
            ...Object.keys(this.evidenceRecordsById).map(recordId => ({
                recordId,
                objectApiName: Schema.Evidence__c.sObjectType.objectApiName,
            }))
        ];
    }

    get Label()  { return Label; };
    get Schema() { return Schema; };

    objectInfosAwaiter      = new GetObjectInfosConverter();
    caseRecordAwaiter       = new WireConverter();
    evidencePicklistAwaiter = new WireConverter();
    subscription            = null;

    @wire(getObjectInfos, { objectApiNames: [ Schema.Evidence__c.sObjectType, Schema.Case.sObjectType ] })
    handleObjectInfos(result) {
        this.objectInfosAwaiter.handleResult(result);
    }
    @wire(getRecord, { recordId: "$recordId", fields: CASE_REQUIRED_FIELDS })
    handleRecordInfo(result) {
        this.caseRecordAwaiter.handleResult(result);
    }

    async fullViewParameters() {
        const objectInfos  = await this.objectInfosAwaiter.fetch();
        const caseObjInfo  = objectInfos[Schema.Case.sObjectType.objectApiName];
        const relationship = caseObjInfo.childRelationships.find(r =>
            r.childObjectApiName === Schema.Evidence__c.sObjectType.objectApiName &&
            r.fieldName          === Schema.Evidence__c.Case__c.fieldApiName
        );

        return {
            type: 'standard__recordRelationshipPage',
            attributes: {
                recordId:            this.recordId,
                objectApiName:       Schema.Case.sObjectType.objectApiName,
                relationshipApiName: relationship.relationshipName,
                actionName:          'view',
            }
        }
    }

    async connectedCallback() {
        try {
            this.subscription = await empApi.subscribe('/data/Evidence__ChangeEvent', -1, msg => {
                if(msg.data.payload.ChangeEventHeader.commitUser !== CURRENT_USER_ID) return;
                if(msg.data.payload.ChangeEventHeader.changeType !== 'CREATE') return;

                this.loadData();
            });
            empApi.onError(err => {
                console.error(JSON.parse(JSON.stringify(err)));
            });

            const objectInfos = await this.objectInfosAwaiter.fetch();
            this.caseRecord = await this.caseRecordAwaiter.fetch();

            const evidenceObjectInfo = objectInfos[Schema.Evidence__c.sObjectType.objectApiName];
            this.objectDetails = {
                icon:        getIconNameFromUrl(evidenceObjectInfo.themeInfo.iconUrl),
                label:       evidenceObjectInfo.label,
                labelPlural: evidenceObjectInfo.labelPlural,
                columns:     EvidenceWrapper.buildColumns(evidenceObjectInfo)
            };

            this.fullViewUrl = await this[NavigationMixin.GenerateUrl](await this.fullViewParameters());
            await this.loadData();
        } catch(err) {
            console.error(err);
            this.error = getErrorMessage(err);
        }
        this.loading = null;
    }

    disconnectedCallback() {
        empApi.unsubscribe(this.subscription);
        this.subscription = null;
    }

    async loadData() {
        try {
            const evidence = await Apex.fetchEvidence(this.recordId);
            this.evidenceRecordsById = evidence.reduce(
                (obj, ev) => {
                    obj[ev.Id] = new EvidenceWrapper(ev);
                    return obj;
                },
                { }
            );
        } catch(err) {
            console.error(err);
            this.error = getErrorMessage(err);
        }
    }

    async refreshData() {
        this.loading = 'Refreshing data';
        await this.loadData();
        this.loading = null;
    }
	 

    newEvidence() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: Schema.Evidence__c.sObjectType.objectApiName,
                actionName:    'new',
            },
            state: {
                defaultFieldValues: toUrlEncodedString({
                    [Schema.Evidence__c.Name.fieldApiName]:                  '-',
                    [Schema.Evidence__c.Case__c.fieldApiName]:               this.recordId,
                    [Schema.Evidence__c.Application_Member__c.fieldApiName]: getFieldValue(this.caseRecord, Schema.Case.Application_Member__c),
                    [Schema.Evidence__c.Status__c.fieldApiName]:             'Requested',
                }),
                navigationLocation: 'RELATED_LIST'
            },
        });
    }
    async fullView(e) {
        e.preventDefault();
        e.stopPropagation();

        this[NavigationMixin.Navigate](await this.fullViewParameters());
    }
    setSorting(e) {
        this.sortBy        = e.detail.fieldName;
        this.sortDirection = e.detail.sortDirection;
    }
    selectRows(e) {
        this.selectedRecords = e.detail.selectedRows;
    }
    setStatus() {
        this.showSetStatusModal = true;
    }
    setSelectedStatus(e) {
        this.selectedStatus = e.detail.value;
    }
    async confirmSetStatus() {
        if(this.modalLoading) return;

        this.modalLoading = 'Setting status';
        try {
            await Apex.massSetStatus(this.selectedRecords.map(ev => ev.Id), this.selectedStatus);
            this.modalLoading = null;
            this.closeModals();
            getRecordNotifyChange(this.selectedRecords.map(ev => ({ recordId: ev.Id })));
        } catch(err) {
            console.error(err);
            this.modalErr = getErrorMessage(err);
        }
        this.modalLoading = null;

    }
    handleRowAction(e) {
        const action = e.detail.action.name;
        switch(action) {
            case 'edit':
                this[NavigationMixin.Navigate]({
                    type: 'standard__recordPage',
                    attributes: {
                        recordId:      e.detail.row.Id,
                        objectApiName: Schema.Evidence__c.sObjectType.objectApiName,
                        actionName:    'edit'
                    }
                });
                break;
            case 'delete':
                this.deleteRecordId = e.detail.row.Id;
                break;
            default:
                console.error(`Unhandled action ${action}`);
                break;
        }
    }

    async confirmDeleteEvidence() {
        if(this.modalLoading) return;

        this.modalLoading = 'Deleting evidence';
        try {
            await deleteRecord(this.deleteRecordId);
            this.modalLoading = null;
            this.closeModals();
        } catch(err) {
            console.error(err);
            this.modalErr = getErrorMessage(err);
        }
        this.modalLoading = null;
    }

    closeModals() {
        if(this.modalLoading) return;

        this.showSetStatusModal = false;
        this.selectedStatus     = null;
        this.deleteRecordId     = null;
        this.modalErr           = null;
    }
}