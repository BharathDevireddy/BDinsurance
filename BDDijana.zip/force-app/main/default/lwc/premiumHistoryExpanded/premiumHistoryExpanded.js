import { api, track, wire } from 'lwc';

//Object Imports
import ACCOUNT_OBJECT from '@salesforce/schema/Account';

import { fetchPremiumHistoryFull} from 'c/claimsDataHandler';
import fetchAccountForPolicyNumber from '@salesforce/apex/PolicyHeader_LEx.fetchAccountForPolicyNumber';

import ClaimsComponent from 'c/claimsComponent';
import BODY from './premiumHistoryExpanded.html';


// Dummy action column to reserve space and prevent v scrollbar from obscuring last column data
const actions = [
];

export default class PremiumHistoryExpanded extends ClaimsComponent {

    componentLabel = 'Policy Premium History';
    componentBody = BODY;

    @api coverRef;
    @api policyRef;
    @api premiums;

    @track cardTitle = 'Policy Premium History';
    @track columns = [
        {
            label: 'Payment Date', 
            fieldName: 'PaymentDate', 
            type: 'date',
            typeAttributes: { 
                day: '2-digit', 
                month: '2-digit', 
                year: 'numeric' 
            }
        },
        {
            label: 'Type', 
            fieldName: 'Type' 
        },
        {
            label: 'Debit', 
            fieldName: 'Debit', 
            type: 'number',
            typeAttributes: {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }  
        },
        {
            label: 'Credit', 
            fieldName: 'Credit', 
            type: 'number' ,
            typeAttributes: {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            } 
        },
        {
            type: 'action', 
            typeAttributes: { 
                rowActions: actions, 
                menuAlignment: 'right' 
            }, 
            cellAttributes: {
                class:'slds-hidden' 
            }
        }
    ];

    @track account;
    
    @track coverDetailsUrl;
    @track accountUrl;

    @wire(fetchAccountForPolicyNumber, {pPolicyNumber:'$policyRef'}) //account;
    handleAccount({ error, data }) {
        if(data) {
            console.log('+++ data ' + JSON.stringify(data));
            console.log('+++ error ' + error);
            this.account = data;
            console.log('##Item : account : ' + JSON.stringify(ACCOUNT_OBJECT));
            this.Navigation.generateViewRecordLink(
                ACCOUNT_OBJECT.objectApiName, 
                this.account.Id
            ).then(pUrl => this.accountUrl = pUrl);
        }
        if(error) {
            this.ErrorHandling.logErrorFromException(ex);
        }
    }

    get policyBreadcrumb() { return `${this.policyRef} Cover Detail `};

    get numberOfItems() { return this.premiums?.length; }    

    async connectedCallback() {
        try {
            let details = await fetchPremiumHistoryFull(this.policyRef, this.coverRef);
            this.premiums = details.PremiumHistory;
            //Generate Cover Detail URL
            this.Navigation.generateComponentPageLink(
                'policyDetailPage', 
                { 
                    policyRef: this.policyRef, 
                    selectedCover: this.coverRef
                }
            ).then(pUrl => this.coverDetailsUrl = pUrl);
        } catch(ex) {
            this.ErrorHandling.logErrorFromException(ex);
        } finally {
            this.State.show();
        }   
    }

    renderedCallback() {
        // if we declaratively specify a fixed height table in markup this causes a page rendering issue
        // when this component is loaded by Claim Component especially if loader does not have time to appear
        // the 100 is the approx height of the header
        const tableContainer = this.template.querySelector('[data-identifier="TableContainer"]');
        if (tableContainer) this.template.querySelector('[data-identifier="TableContainer"]').style="height: calc(100% - 100px)";
    }

}