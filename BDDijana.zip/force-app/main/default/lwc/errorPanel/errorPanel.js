import { LightningElement, api } from 'lwc';

export default class ErrorPanel extends LightningElement {
    @api type;
    @api text;

    get isWarning() { return this.message && this.type === 'warning' }
    get isError()   { return this.message && this.type === 'error' }
    get message()   { return this.text }
}