//LWC Imports
import { LightningElement, api, track } from 'lwc';

//Component imports
import ClaimsComponent from 'c/claimsComponent';

//Constants
import BODY from './premiumDetail.html';
import { PREMIUM_DETAIL_LAYOUT, PREMIUM_TABLE_COLUMNS } from './constants.js';

export default class PremiumDetail extends ClaimsComponent {

    /*=========================================================
            Parent Component Vars
    =========================================================*/

    componentLabel = 'Premium Detail';
    componentBody = BODY;

    /*=========================================================
           Vars
    =========================================================*/
    
    @api policyRef;
    @api coverRef;

    @track isLoading = true;
    @track errorMessage;

    @track formData = {};
    @track premiumData = [];

    layout = PREMIUM_DETAIL_LAYOUT;
    columns = PREMIUM_TABLE_COLUMNS;
    
    /*=========================================================
           Setup
    =========================================================*/
    
    /**
     * Once connected, callout to the claims data service to fetch the details for the provided cover,
     * then create the form data object needed to display it in the UI
     */
    async connectedCallback() {
        try {
            let [coverDetail, coverSummary] = await Promise.all([
                this.ClaimsDataService.fetchCoverDetails(this.policyRef, this.coverRef).then(details => {
                    this.formData = {
                        PaidToDate: details.CurrentPremiumSummary.PaidToDate,
                        TotalPremium: details.CurrentPremiumSummary.TotalPremium,
                        PaymentDate: details.CurrentPremiumSummary.PremiumPaymentDay,
                        BillingCycle: details.CurrentPremiumSummary.BillingCycleText
                    };
                    Object.assign(this.formData, details.CurrentPremiumSummary.PremiumBankAccount);
                    return details;
                }),
                this.ClaimsDataService.fetchCoverInformation(this.policyRef)
            ]);
            // get the (cached) cover information as it will contain the correct sort order
            let premiums = coverDetail.CurrentPremiumSummary.CurrentPremiums;
            let allCovers = [...coverSummary.Active, ...coverSummary.Inactive];
    
            // loop over all of the covers and pull out the corresponding premium, if it exists
            // so that they appear in the same order
            var sortedPremiums = [];
            let premiumsByCoverReference = {};
            for(const premium of premiums) {
                let storedPremiums = premiumsByCoverReference[premium.CoverReference];
                if(!storedPremiums) {
                    storedPremiums = [];
                }
                storedPremiums.push(premium);
                premiumsByCoverReference[premium.CoverReference] = storedPremiums;
            }
            for(const cover of allCovers) {
                let storedPremiums = premiumsByCoverReference[cover.CoverReference];
                if(storedPremiums) sortedPremiums.push(...storedPremiums);
            }
            this.premiumData = sortedPremiums;
        } catch(ex) {
            this.ErrorHandling.logErrorFromException(ex);
        } finally {
            this.State.show();
        }
    }

    async sortPremiums(premiums) {
        return(sortedPremiums);
    }
}