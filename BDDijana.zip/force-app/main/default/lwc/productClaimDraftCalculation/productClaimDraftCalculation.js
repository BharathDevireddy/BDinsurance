import { LightningElement, api, track } from 'lwc';
import { calculateProductClaimDraftData } from 'c/productClaimDataHandler';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import productClaimCalculationError from '@salesforce/label/c.Product_Claim_Calculation_Error'

const columns = [
        // VM- CLAIM-1124 : Removing ID Column
        // {
        //     label: 'ID',
        //     fieldName: 'dayRateID',
        //     type: 'number'
        // },
        {
            label: 'Detail view',
            type: 'button-icon',
            fixedWidth: 90,
            typeAttributes:
                {
                    iconName: 'utility:preview',
                    name: 'preview'
                }
        },
        {
            label: 'Period Start',
            fieldName: 'periodStart',
            type: 'date'
        },
        {
            label: 'Period End',
            fieldName: 'periodEnd',
            type: 'date'
        },
        {
            label: 'Day Count',
            fieldName: 'dayCount',
            type: 'number'
        },
        {
            label: 'Day Rate',
            fieldName: 'dayRate',
            type: 'currency'
        },
        {
            label: 'Period Total',
            fieldName: 'periodTotal',
            type: 'currency'
        },
];

export default class ProductClaimDraftCalculation extends LightningElement {
    @api recordId;

    @track calculationDataExists = false;
    @track DraftCalculationColumns = columns;
    @track showCalculationDetails = false;
    @track draftCalculationData;
    @track showSpinner;
    @api calculateButtonInactive;

   handleRowAction(event){
    const dataRow = event.detail.row;
      this.contactRow = dataRow;
      // commented out because constantly showing on the page
      //this.showSpinner = true; 
      this.showCalculationDetails = true;
    if(event.detail.action.name === 'preview'){
        this.template.querySelector("[data-id='calculationDetailsModal']").showModal();
    }    
   }

    @api calculateDraftData() {
       this.showSpinner = true;
       this.dispatchEvent(new CustomEvent('calculationbuttonclicked'));

       calculateProductClaimDraftData(this.recordId)
       .then(result => {
           this.calculationDataExists = true;
           this.draftCalculationData = result.claimWindows;
           this.dispatchEvent(new CustomEvent('draftdatacalculated'));
       })
       .catch(error => {
           if(error.body.message.split(';')[0] === '400'){
               let errorMessage = '';
               let wholeMessage = error.body.message.split(';')[2].split(',');
               for(let msg of wholeMessage){
                 errorMessage += msg.split(':')[1] + '\n'
               }
               this.showNotification('Error' , errorMessage , 'error');
           }else{
               this.showNotification('Error' , productClaimCalculationError , 'error');
           }
       })
       .finally(() => {
           this.showSpinner = false;
       });
   }

   closeModalAction(){
      this.showCalculationDetails = false;
   }

   showNotification(title, message, variant) {
       const evt = new ShowToastEvent({
           title: title,
           message: message,
           variant: variant,
       });
       this.dispatchEvent(evt);
   }
}