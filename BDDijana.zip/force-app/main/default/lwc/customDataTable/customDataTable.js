import LightningDatatable  from 'lightning/datatable';

import CONDITIONAL_LINK_TEMPLATE from "./conditionalLink.html";

export default class CustomDataTable extends LightningDatatable {
	static customTypes = {
		conditionalLink: {
			template: CONDITIONAL_LINK_TEMPLATE,
			typeAttributes: [
                //Custom
                'displayUrl',
                //Text
                'linkify',
                //URL
                'link',
                'tabIndex',
                'target',
                'tooltip'
            ]
		}
	}

}