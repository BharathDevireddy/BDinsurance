/*=========================================================
        Imports
=========================================================*/
import { refreshApex } from '@salesforce/apex';

import ERROR_UNKNOWN from '@salesforce/label/c.Generic_Error_Unknown';
import SORT_OBJECT_ERROR_PROPERTYINFO_NULL from '@salesforce/label/c.Utility_SortObjectError_Property_Null';
import SORT_OBJECT_ERROR_PROPERTY_NULL from '@salesforce/label/c.Utility_SortObjectError_PropertyToSort_Null';

/*=========================================================
        Constants
=========================================================*/

const PROMISE_QUEUE = {};
const CACHED_DATA = {};
const CACHE_LIFESPAN = 60000;

/*=========================================================
        Exported Constants
=========================================================*/

const SORT_ASCENDING = 'ASC';
const SORT_DESCENDING = 'DESC';
export { SORT_ASCENDING, SORT_DESCENDING }

/*=========================================================
        Utility Methods
=========================================================*/

/**
 * Compares the two objects based on the property/properties given in `pProperty`.
 * If `pProperty` is an Array, then we will use the first element in the array to compare the objects,
 * and if that comparison comes out equal, we then compare using the next element in the array until
 * we either find a difference or reach the end of the properties array, at which point we return 0
 * @param {Object} pValA 
 * @param {Object} pValB 
 * @param {Object|Object[]} pProperty Properties of the given objects to compare
 * @param {String} pProperty.direction Direction of Sort. 
 * @param {String} pProperty.property Property to Sort. 
 * @returns {Integer} Sort direction
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort
 */
export function sortObject(pValA, pValB, pProperty) {
    //Grab property value
    let propertyInfo = Array.isArray(pProperty) ? (pProperty = [...pProperty]).shift() : pProperty;
    //Validate
    if(null == propertyInfo) throw new Error(SORT_OBJECT_ERROR_PROPERTYINFO_NULL);
    else if(null == propertyInfo.property) throw new Error(SORT_OBJECT_ERROR_PROPERTY_NULL);
    //Sort!
    if(pValA[propertyInfo.property] == pValB[propertyInfo.property]) {
        return Array.isArray(pProperty) && pProperty.length > 0 ? sortObject(pValA, pValB, pProperty) : 0;
    } else {
        let directionModifier = propertyInfo.direction == null || propertyInfo.direction == SORT_ASCENDING ? 1 : -1;
        return pValA[propertyInfo.property] < pValB[propertyInfo.property] ? (-1 * directionModifier) : (1 * directionModifier);
    }
}

/**
 * @description Gets the error messages from a thrown exception. The following
 * types of error are handled (in this order):
 *
 * - `AuraHandledExceptions` from Apex
 * - The javascript `Error` type
 *
 * If the error does not match either of the above then we return the supplied
 * fallback error. If the fallback error is not defined, we fallback to a
 * generic error message
 * @param {any} err The error which we want to get the message from
 * @param {string?} orMessage The fallback error if we don't know what sort of
 * error it is
 * @return {string} The error message
 */
export function getErrorMessage(err, orMessage) {
    if(err.body && err.body.message) {
        return err.body.message;
    } else if(err instanceof Error) {
        return err.message;
    } else if(orMessage) {
        return orMessage;
    } else {
        return ERROR_UNKNOWN;
    }
}


/**
 * @description When querying getObjectInfo, we get the Object's icon back from
 * `themeInfo.iconUrl` which returns an image url, like this:
 *
 * https://my-domain.my.salesforce.com/img/icon/{something}/{section}/{icon}_120.png
 *
 * The only things we care about are `section` and `icon`. `section` will be
 * either `standard` (for Standard objects) or `custom` (for custom), and `icon`
 * is the actual icon within the set. These align with the lightning icon names,
 * which following the format of {section}:{icon}
 *
 * This function returns the lightning icon name when given the value in
 * `ObjectInfo.themeInfo.iconUrl`
 *
 * @param {string} iconUrl The url from `ObjectInfo.themeInfo.iconUrl`
 * @returns {string} The icon name which can be passed into things which expect
 * a lightning iconName.
 */
export function getIconNameFromUrl(iconUrl) {
    // The approach here is to ignore everything except the filename and
    // the enclosing folder of the url. After that, we remove the size and the
    // extension from the filename, leaving us with the `section` and `icon`.
    const urlParts = iconUrl.split('/');

    const idxFilename = urlParts.length - 1;
    const idxSection  = urlParts.length - 2;

    const filename     = urlParts[idxFilename];
    const section      = urlParts[idxSection];
    const [ iconName ] = filename.split('_');

    return `${section}:${iconName}`;
}

/**
 * Attempts to return any cached data for the passed in identifier, if there is
 * no cache available, it will callout to the apex method given and resolve the
 * promise with the result and will update the cache. If an error occurs whilst 
 * calling out to the apex, the promise is rejected with the exception
 * @param {Function} pMethod Apex method to call
 * @param {Object} pParams Parameters to pass to the apex method
 * @param {String} pIdentifier Identifier for caching
 * @returns {Promise<Object>} Result of the apex callout
 */
export function callApex(pMethod, pParams, pIdentifier, pOnBeforeCache) {
    return new Promise((resolve, reject) => {
        if(null == pIdentifier) pIdentifier = pMethod.name + (pParams ? Object.values(pParams).join('') : ''); 
        //Grab the cached data
        let data = getCachedData(pIdentifier);
        //If it's undefined, we have no cache
        if(pIdentifier.includes('SaveProductData')){
            data = undefined;
        }
        if(!data) {
            let wasFirst = queuePromise(pIdentifier, resolve, reject);
            if(wasFirst) {
                let promiseQueue = PROMISE_QUEUE[pIdentifier];
                pMethod(pParams).then(responseData => {
                    if(pOnBeforeCache) responseData = pOnBeforeCache(responseData);
                    promiseQueue.splice(0,promiseQueue.length).forEach(prom => prom.resolve(responseData));
                    storeCachedData(pIdentifier, responseData);
                }).catch(ex => {
                    //Maybe cache the error?
                    promiseQueue.splice(0,promiseQueue.length).forEach(prom => prom.reject(ex));
                });
            }
        } else {
            //Return the cached data
            resolve(data);
        }

    });
}

/**
 * Clears all cached data created by the `callApex` method
 * @param {String} pIdentifier Identifier to clear cache for. Leave blank to clear all cache
 */
export function clearCache(pIdentifier) {
    if(pIdentifier) {
        CACHED_DATA[pIdentifier] = undefined;
    } else {
        Object.keys(CACHED_DATA).forEach(key => CACHED_DATA[key] = undefined);
    }
}


/*=========================================================
        Helper Methods
=========================================================*/

/**
 * Queues a promise onto a Promise Queue of the given identifier
 * @param {String} pIdentifier Cache Identifier
 * @param {Function} pResolve Promise resolve method
 * @param {Function} pReject Promise reject method
 * @returns {Boolean} returns true if the queue now has a size of 1, false otherwise
 */
function queuePromise(pIdentifier, pResolve, pReject) {
    (PROMISE_QUEUE[pIdentifier] = PROMISE_QUEUE[pIdentifier] || []).push({resolve: pResolve, reject: pReject});
    return PROMISE_QUEUE[pIdentifier].length == 1;
}

/**
 * Stores the given data in the Cache storage for the given Identifier
 * @param {String} pIdentifier Cache Identifier
 * @param {Object} pData Data to cache
 */
function storeCachedData(pIdentifier, pData) {
    CACHED_DATA[pIdentifier] = {
        Data: pData,
        Timestamp: new Date().getTime()
    };
}

/**
 * @param {String} pIdentifier Cache Identifier
 * @returns {Object} The cached data, undefined if data is older than `CACHE_LIFESPAN`
 */
function getCachedData(pIdentifier) {
    let cachedData = CACHED_DATA[pIdentifier];
    if(cachedData) {
        if(cachedData.Timestamp + CACHE_LIFESPAN > new Date().getTime()) {
            return cachedData.Data;
        } else {
            CACHED_DATA[pIdentifier] = undefined;
        }
    }
    return undefined;
}

/*=========================================================
        Classes
=========================================================*/

/**
 * @description A class which tries to convert Wire methods into a more
 * usable style for use within functions.
 *
 * To use this you need to use a function-style wire adapter and store an
 * instance of the class within your component. In the function you call the
 * `.handleResult()` function of the instance, passing in the result of the wire
 * method.
 *
 * When you want to get the result, you call `.fetch()`, which will return a
 * Promise of the `data` part of the wire. If there is an error, the Promise
 * will be rejected with the `error` part of the wire.
 * @example
 * ```
 * accountObjectInfo = new WireConverter();
 * @wire(getObjectInfo, { objectApiName: 'Account' }) myAccounts(result) {
 *     accountObjectInfo.handleResult(result);
 * }
 *
 * // ...
 *
 * let accountObjectInfo = await this.accountObjectInfo.fetch();
 * let accountLabel = accountObjectInfo.label;
 *
 * // ...
 * ```
 */
export class WireConverter {
    awaiters = [ ];
    result   = null;

    /**
     * @description Stores the result and resolves any outstanding Promises
     * waiting on this WireConverter
     *
     * @param {object} result The result object which is passed into a Wire
     * function
     */
    handleResult(result) {
        // If we get nothing, don't bother doing anything.
        if(!result.data && !result.error) return;

        this.result = result;

        // Resolve any of the promises currently waiting for a result
        if(this.result.data) {
            for(const { resolve } of this.awaiters.splice(0)) {
                resolve(this.result.data);
            }
        } else {
            for(const { reject } of this.awaiters.splice(0)) {
                reject(this.result.error);
            }
        }
    }

    /**
     * @description Fetch the result of the Wire Method. If the wire method has
     * yet to have been called, this will return a Promise that resolves when
     * it has.
     *
     * @return {Promise<any>} A Promise which resolves when the Wire function
     * has been called.
     */
    async fetch() {
        return new Promise((resolve, reject) => {
            if(null === this.result) {
                this.awaiters.push({ resolve, reject });
            } else if(this.result.data) {
                resolve(this.result.data);
            } else {
                reject(this.result.error);
            }
        });
    }

    /**
     * @description Mark the result as being stale and that the results need to
     * be refetched.
     *
     * @return {Promise<any>} A Promise which resolves when the Wire function
     * has been called again.
     */
    async reset() {
        if(null !== this.result) {
            refreshApex(this.result);
            this.result = null;
        }
        return this.fetch();
    }
}

/**
 * @description A `WireConverter` which converts the output of `getObjectInfos`
 * into a more usable format.
 *
 * If there are any errors, then the resulting Promise will be rejected. As the
 * function returns multiple results, each individual item can have errors. This
 * adapter makes it so that any error will blow the whole.
 *
 * The resulting object matches the following format:
 *
 * ```javascript
 * {
 *     <<objectApiName>>: <<objectInfo>>
 * }
 * ```
 * @example
 * ```
 * objectInfosConverter = new GetObjectInfosConverter();
 * @wire(getObjectInfos, { objectApiNames: [ 'Account', 'Contact' ] }) myAccounts(result) {
 *     objectInfosConverter.handleResult(result);
 * }
 *
 * // ...
 *
 * let objectInfos = await this.objectInfosConverter.fetch();
 * let accountLabel = objectInfos.Account.label;
 * let contactLabel = objectInfos.Contact.label;
 *
 * // ...
 * ```
 */
export class GetObjectInfosConverter extends WireConverter {
    /**
     * @description Convers the result into the specified format (see class
     * documentation) and resolves any outstanding Promises waiting.
     *
     * @param {object} result The result object which is passed into a the
     * `getObjectInfos` Wire function
     */
    handleResult(result) {
        if(result.data) {
            // Check if there were any errors fetching the object info
            const errors = result.data.results
                .filter(data => 200 !== data.statusCode)
                .map(data => data.result)
                .flat();

            if(errors.length > 0) {
                result = {
                    error: new Error(errors.join("\n"))
                };
            } else {
                // Convert the list into an object structure, so that you can
                // get a specific object without having to filter through an
                // Array
                const output = result.data.results
                    .reduce(
                        (build, data) => Object.defineProperty(build, data.result.apiName, { value: data.result }),
                        { }
                    );

                result = {
                    data: output
                };
            }
        }

        // Call the base class's handleResult with the updated result
        super.handleResult(result);
    }
}