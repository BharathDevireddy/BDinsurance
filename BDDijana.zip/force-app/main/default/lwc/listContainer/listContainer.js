import { api, LightningElement } from 'lwc';

export default class ListContainer extends LightningElement {
    @api iconName   = null;
    @api footerless = false;

    get showIcon()  { return !!this.iconName; }
}