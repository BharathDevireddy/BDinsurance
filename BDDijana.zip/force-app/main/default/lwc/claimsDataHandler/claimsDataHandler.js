/*=========================================================
        Imports
=========================================================*/

//Apex
import fetchCovers from "@salesforce/apex/ClaimsDataHandler_LEx.fetchCovers";
import fetchCoverDetail from "@salesforce/apex/ClaimsDataHandler_LEx.fetchCoverDetail";
import fetchPremiumHistory from "@salesforce/apex/ClaimsDataHandler_LEx.fetchPremiumHistory";


//LWC
import { callApex, sortObject, SORT_ASCENDING } from 'c/utility';

/*=========================================================
        Vars
=========================================================*/

const IDENTIFIER_COVER_INFO = 'CoverInfo';
const IDENTIFIER_COVER_DETAIL = 'CoverDetail';
const IDENTIFIER_PREMIUM_HISTORY = 'PremiumHistory';

const COVER_SUMMARY_SORTING_FIELDS = [
    {
        property: 'Cover',
        direction: SORT_ASCENDING
    },
    {
        property: 'CoverReference',
        direction: SORT_ASCENDING
    }
]

/*=========================================================
        Apex Calls
=========================================================*/

export function fetchCoverInformation(pPolicyNumber) {
    return callApex( 
        fetchCovers,
        {
            pPolicyNumber: pPolicyNumber
        },
        IDENTIFIER_COVER_INFO + pPolicyNumber,
        sortCoversSummaryObject
    );
}

export function fetchCoverDetails(pPolicyNumber, pCoverReference) {
    return callApex( 
        fetchCoverDetail,
        {
            pPolicyNumber: pPolicyNumber,
            pCoverReference: pCoverReference
        },
        IDENTIFIER_COVER_DETAIL + pPolicyNumber + pCoverReference,
    );
}

export function fetchPremiumHistoryFull(pPolicyNumber, pCoverReference) {
    return callApex( 
        fetchPremiumHistory,
        {
            pPolicyNumber: pPolicyNumber,
            pCoverReference: pCoverReference
        },
        IDENTIFIER_PREMIUM_HISTORY + pPolicyNumber + pCoverReference,
    );
}

/*=========================================================
        Helper Methods
=========================================================*/

/**
 * This helper method will sort the covers gotten from before the caching of the callout
 * and order them based on: `Cover ASC, Reference ASC`, with rider covers being sorted separately
 * and placed under their parent cover for Active covers only. 
 * @param {Object} pData Data returned from ClaimsDataHandler
 * @param {Object[]} pData.Active Active covers 
 * @param {Object[]} pData.Inactive Inactive covers 
 * @returns {Object} Returns pData with updated ordering
 */
function sortCoversSummaryObject(pData) {
    if(pData) {
        let ret = {};
        ret.Active = sortCovers(pData.Active);
        ret.Inactive = sortCovers(pData.Inactive);
        return ret;
    }
}

/**
 * Orders the covers based on: `Cover ASC, Reference ASC`, with rider covers being sorted separately
 * and placed under their parent cover for Active covers only. Orphan Riders in the case of inactive
 * covers will be placed last in the list sorted in the same order as the primary covers
 * @param {Object[]} pData Covers to sort
 * @returns {Object[]} Returns pData sorted
 */
function sortCovers(pData) {
    //Sorting method
    let sortingMethod = (pCoverA, pCoverB) => sortObject(pCoverA, pCoverB, COVER_SUMMARY_SORTING_FIELDS);
    //Init Vars
    let sortedCovers = [];
    let primaryCovers = [];
    let riderCoverMap = Object.create(null);
    //Loop over array and group based on ParentReference
    for(let cover of pData) {
        if(cover.ParentReference) {
            (riderCoverMap[cover.ParentReference] = riderCoverMap[cover.ParentReference] || []).push(cover);
        } else {
            primaryCovers.push(cover);
        }
    }
    //Sort primary covers
    primaryCovers.sort(sortingMethod);
    //Sort Riders under their primary cover
    for(let cover of primaryCovers) {
        sortedCovers.push(cover);
        let riderCovers = riderCoverMap[cover.CoverReference];
        riderCoverMap[cover.CoverReference] = undefined; //Remove array from map for cleanup after
        if(riderCovers) {
            sortedCovers.push(...riderCovers.sort(sortingMethod));
        }
    }
    //Add any orphan riders from `riderCoverMap` values.
    //We don't want to add any undefined or null values, then we compress all the ophan riders into a singular
    //list and sort them together
    sortedCovers.push(
        ...Object.values(
            riderCoverMap
        ).filter(
            x => x != null && Array.isArray(x)
        ).reduce(
            (arr, riderCovers) => { arr.push(...riderCovers); return arr }, 
            []
        ).sort(sortingMethod)
    );
    //Return result
    return sortedCovers;

}