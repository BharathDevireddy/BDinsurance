import {LightningElement, track, api} from 'lwc';

import {calculateProductClaimDraftData, getProductReadOnlyData} from 'c/productClaimDataHandler';

import {
    DRAFT_PAYOUT_SCHEDULE_COLUMNS,
    PUBLISHED_FUTURE_PAYOUT_SCHEDULE_COLUMNS,
    PUBLISHED_PAID_PAYOUT_SCHEDULE_COLUMNS
} from "./tablesConfiguration";

import {ShowToastEvent} from "lightning/platformShowToastEvent";

export default class ProductClaimTabPayoutSchedule extends LightningElement {

    @api recordId;
    @track draftPayoutScheduleColumns = DRAFT_PAYOUT_SCHEDULE_COLUMNS;
    @track publishedFuturePayoutScheduleColumns = PUBLISHED_FUTURE_PAYOUT_SCHEDULE_COLUMNS;
    @track publishedPaidPayoutScheduleColumns = PUBLISHED_PAID_PAYOUT_SCHEDULE_COLUMNS;
    @track draftPayoutScheduleData = [];
    @track publishedFuturePayoutScheduleData = [];
    @track publishedPaidPayoutScheduleData = [];
    showSpinner = false;

    connectedCallback() {
        this.getPayoutScheduleData();
    }

    @api
    getPayoutScheduleDraftData() {
        this.showSpinner = true;
        calculateProductClaimDraftData(this.recordId)
            .then(result => {
                this.draftPayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule);
            })
            .catch(error => {
                this.showNotification('Error' , 'Cannot retrieve calculation result' , 'error');
            })
            .finally(() => {
                this.showSpinner = false;
            });
    }

    @api
    getPayoutScheduleData() {
        this.showSpinner = true;
        getProductReadOnlyData(this.recordId)
            .then(result => {
                if (result.payoutSchedule) {
                    this.draftPayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.draftPayoutSchedule);
                    this.publishedFuturePayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.publishedFuturePayoutSchedule);
                    this.publishedPaidPayoutScheduleData = this.processPayoutScheduleData(result.payoutSchedule.publishedPaidPayoutSchedule);
                }
            })
            .catch(error => {
                this.showNotification('Error' , 'Cannot retrieve calculation result' , 'error');
            })
            .finally(() => {
                this.showSpinner = false;
            });
    }

    processPayoutScheduleData(payoutScheduleData) {
        let mainIndex = 1;
        const dateReference = new Date().setMonth(new Date().getMonth() + 6);
        payoutScheduleData = payoutScheduleData.filter(payoutScheduleDataItem => {
           return new Date(payoutScheduleDataItem.startDate) <= dateReference;
        });
        payoutScheduleData.forEach(payoutScheduleDataItem => {
            payoutScheduleDataItem._children = payoutScheduleDataItem.details;
            payoutScheduleDataItem.key = mainIndex;
            mainIndex++;
            let childIndex = 1;
            payoutScheduleDataItem._children.forEach(child => {
                child.key = mainIndex + '-' + childIndex;
                childIndex++;
            });
            if (payoutScheduleDataItem._children && payoutScheduleDataItem._children.length === 1) {
                payoutScheduleDataItem.dayRate = payoutScheduleDataItem._children[0].dayRate;
                payoutScheduleDataItem.annualisedPayout = payoutScheduleDataItem._children[0].annualisedPayout;
                delete payoutScheduleDataItem._children;
            }
        });
        return payoutScheduleData;
    }

    showNotification(title, message, variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }

    showNotification(title,message,variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }
}