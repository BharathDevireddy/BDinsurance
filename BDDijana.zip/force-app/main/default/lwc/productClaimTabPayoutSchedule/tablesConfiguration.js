export const DRAFT_PAYOUT_SCHEDULE_COLUMNS = [
    {
        label: 'Payout Start Period',
        fieldName: 'startDate',
        type: 'date'
    },
    {
        label: 'Payout End Period',
        fieldName: 'endDate',
        type: 'date'
    },
    {
        label: 'Day Count',
        fieldName: 'dayCount',
        type: 'number'
    },
    {
        label: 'Day Rate',
        fieldName: 'dayRate',
        type: 'currency'
    },
    {
        label: 'Amount',
        fieldName: 'amount',
        type: 'currency'
    },
    {
        label: 'Annualised Payout',
        fieldName: 'annualisedPayout',
        type: 'currency'
    }
];

export const PUBLISHED_FUTURE_PAYOUT_SCHEDULE_COLUMNS = [
    {
        label: 'Payout Start Period',
        fieldName: 'startDate',
        type: 'date'
    },
    {
        label: 'Payout End Period',
        fieldName: 'endDate',
        type: 'date'
    },
    {
        label: 'Day Count',
        fieldName: 'dayCount',
        type: 'number'
    },
    {
        label: 'Day Rate',
        fieldName: 'dayRate',
        type: 'currency'
    },
    {
        label: 'Annualised Payout',
        fieldName: 'annualisedPayout',
        type: 'currency'
    },
    {
        label: 'Amount',
        fieldName: 'amount',
        type: 'currency'
    }
];

export const PUBLISHED_PAID_PAYOUT_SCHEDULE_COLUMNS = [
    {
        label: 'Payout Start Period',
        fieldName: 'startDate',
        type: 'date'
    },
    {
        label: 'Payout End Period',
        fieldName: 'endDate',
        type: 'date'
    },
    {
        label: 'Day Count',
        fieldName: 'dayCount',
        type: 'number'
    },
    {
        label: 'Day Rate',
        fieldName: 'dayRate',
        type: 'currency'
    },
    {
        label: 'Annualised Payout',
        fieldName: 'annualisedPayout',
        type: 'currency'
    },
    {
        label: 'Amount',
        fieldName: 'amount',
        type: 'currency'
    },
    {
        label: 'Payment Date',
        fieldName: 'paymentDate',
        type: 'date'
    },
    {
        label: 'Status',
        fieldName: 'status',
        type: 'text'
    }
];