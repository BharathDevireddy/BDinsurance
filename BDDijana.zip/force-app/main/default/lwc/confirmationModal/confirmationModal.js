//Lightning Imports
import { LightningElement, api, track } from 'lwc';

//Label Imports
import DEFAULT_TITLE from '@salesforce/label/c.Confirmation_Modal_Default_Title';
import DEFAULT_MESSAGE from '@salesforce/label/c.Confirmation_Modal_Default_Message';
import DEFAULT_ACCEPT_LABEL from '@salesforce/label/c.Confirmation_Modal_Default_Accept_Label';
import DEFAULT_REJECT_LABEL from '@salesforce/label/c.Confirmation_Modal_Default_Reject_Label';

export default class ConfirmationModal extends LightningElement {

    /*=========================================================
            API Vars
    =========================================================*/

    @api title = DEFAULT_TITLE;
    @api confirmationMessage = DEFAULT_MESSAGE;
    @api acceptLabel = DEFAULT_ACCEPT_LABEL;
    @api rejectLabel = DEFAULT_REJECT_LABEL;

    /*=========================================================
            Tracked Vars
    =========================================================*/

    @track isOpen;
    @track hasCustomSlot = false;
    @track promiseVars = { resolve: undefined, reject: undefined };

    /*=========================================================
            Events
    =========================================================*/
    
    onSlotChange(e) { this.handleSlotChange(e); }
    onReject() { this.handleReject(); }
    onAccept() { this.handleAccept(); }

    /*=========================================================
            API Methods
    =========================================================*/

    /**
     * This method is an attempt at minimising the steps required for requesting confirmation from a user, making it easier to handle through
     * the use of a promise that will resolve when the user confirms, or rejects if they cancel. Calling this method will cause a modal to appear
     * with a confirmation message, and two buttons for Rejecting and Accepting the confirmation
     * @returns {Promise<void>} Returns a promise that will be resolved when the user accepts, or rejected if they cancel
     */
    @api getConfirmation() {
        return new Promise((resolve, reject) => {
            this.promiseVars.resolve = resolve;
            this.promiseVars.reject = reject;
            this.isOpen = true;
        });
    }

    /*=========================================================
            Handlers
    =========================================================*/

    /**
     * This method handles the slot change event, and updates `hasCustomSlot` to true if the slot has children, otherwise it is set to false.
     * This is so we can display the default message if the slot is not populated, or display the slot instead of the default message.
     * @param {Event} e SlotChangeEvent
     */
    handleSlotChange(e) {
        this.hasCustomSlot = e.target.assignedElements().length != 0;
    }

    /**
     * Handles when the user clicks on the reject button
     */
    handleReject() {
        this.promiseVars.reject();
        this.resetVars();
    }
    
    /**
     * Handles when the user clicks on the accept button
     */
    handleAccept() {
        this.promiseVars.resolve();
        this.resetVars();
    }

    /*=========================================================
            Helpers
    =========================================================*/

    /**
     * Helper method to reset the vars once a choice has been made
     */
    resetVars() {
        this.isOpen = false;
        this.promiseVars.resolve = undefined;
        this.promiseVars.reject = undefined;
    }

}