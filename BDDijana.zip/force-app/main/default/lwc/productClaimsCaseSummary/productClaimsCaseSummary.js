import { LightningElement,api,track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import getProductClaimCases from '@salesforce/apex/ProductClaimsCaseSummary_LEx.getProductClaimCases';

import ProductClaims_Warning_RecordsNotFound from '@salesforce/label/c.ProductClaims_Warning_RecordsNotFound'
import ProductClaims_ErrorTitle_FetchingProblem from '@salesforce/label/c.ProductClaims_ErrorTitle_FetchingProblem'
import ProductClaims_Error_FetchingProblem from '@salesforce/label/c.ProductClaims_Error_FetchingProblem'

const columns = [
    { label: 'Case', fieldName: 'url' , type: 'url' ,
    typeAttributes: {label: { fieldName: 'CaseNumber' }, target: '_self'}},
    { label: 'Type', fieldName: 'ClaimType__c'},
    { label: 'Status', fieldName: 'Status'},
];

export default class ProductClaimsCaseSummary extends NavigationMixin(LightningElement) {
    @api recordId;
    caseColumns = columns;
    @track isCasesExists = false;
    @track caseData;
    @track error;
    label = {ProductClaims_Warning_RecordsNotFound}

    connectedCallback() {
        this.getAllProductClaimsCases();
    }

    getAllProductClaimsCases() {
        getProductClaimCases({policyClaimId : this.recordId})
        .then(result => {
            this.populateHyperlinkForCases(result);
            this.isCasesExists = result.length > 0;
            this.error = null;
            })
        .catch(error => {
            this.error = error;
            this.isCasesExists = false;
            this.caseData = [];
            this.showNotification(ProductClaims_ErrorTitle_FetchingProblem,ProductClaims_Error_FetchingProblem,'error')
        });
    }

    async populateHyperlinkForCases(cases){
        this.caseData = await Promise.all(cases.map(async(row) =>  {
            let url = await this.generateRecordUrl(row).then((val) => {return val});
            return {...row , url};
        }));
     }  
 
    generateRecordUrl(record){
        return this[NavigationMixin.GenerateUrl]({
            type: 'standard__recordPage',
            attributes: {
                recordId: record.Id,
                actionName: 'view',
            },
        })
    }

    showNotification(title,message,variant) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(event);
    }
}