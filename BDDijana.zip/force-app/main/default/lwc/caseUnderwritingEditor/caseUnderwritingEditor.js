import { api, LightningElement, track, wire } from 'lwc';
import { getRecordUi }                        from 'lightning/uiRecordApi';
import { getRecordNotifyChange }              from 'lightning/uiRecordApi';
import { publish, MessageContext }            from 'lightning/messageService';

import CaseUnderwritingEditorState__c from '@salesforce/messageChannel/CaseUnderwritingEditorState__c';

import UnderwritingOutcome__c from '@salesforce/schema/UnderwritingOutcome__c';

import UnderwritingOutcome__Cover__c from '@salesforce/schema/UnderwritingOutcome__c.Cover__c';

import UnderwritingOutcome__UREExclusions__c               from '@salesforce/schema/UnderwritingOutcome__c.UREExclusions__c';
import UnderwritingOutcome__URERemovals__c                 from '@salesforce/schema/UnderwritingOutcome__c.URERemovals__c';
import UnderwritingOutcome__URE_PerMillePermanentRating__c from '@salesforce/schema/UnderwritingOutcome__c.URE_PerMillePermanentRating__c';
import UnderwritingOutcome__URE_PostponeDuration__c        from '@salesforce/schema/UnderwritingOutcome__c.URE_PostponeDuration__c';

import UnderwritingOutcome__UW_MortalityRating__c         from '@salesforce/schema/UnderwritingOutcome__c.UW_MortalityRating__c';
import UnderwritingOutcome__UW_PerMillePermanentRating__c from '@salesforce/schema/UnderwritingOutcome__c.UW_PerMillePermanentRating__c';
import UnderwritingOutcome__UW_PerMilleTemporaryRating__c from '@salesforce/schema/UnderwritingOutcome__c.UW_PerMilleTemporaryRating__c';
import UnderwritingOutcome__UW_TemporaryDuration__c       from '@salesforce/schema/UnderwritingOutcome__c.UW_TemporaryDuration__c';
import UnderwritingOutcome__UW_PostponeDuration__c        from '@salesforce/schema/UnderwritingOutcome__c.UW_PostponeDuration__c';
import UnderwritingOutcome__UW_GIOEligibility__c          from '@salesforce/schema/UnderwritingOutcome__c.UW_GIOEligibility__c';
import UnderwritingOutcome__UW_UpsellEligibility__c       from '@salesforce/schema/UnderwritingOutcome__c.UW_UpsellEligibility__c';
import UnderwritingOutcome__UW_UpsellAmount__c            from '@salesforce/schema/UnderwritingOutcome__c.UW_UpsellAmount__c';
import UnderwritingOutcome__UWExclusions__c               from '@salesforce/schema/UnderwritingOutcome__c.UWExclusions__c';
import UnderwritingOutcome__UWRemovals__c                 from '@salesforce/schema/UnderwritingOutcome__c.UWRemovals__c';
import UnderwritingOutcome__UW_ACI_FreeText__c            from '@salesforce/schema/UnderwritingOutcome__c.UW_ACI_FreeText__c';
import UnderwritingOutcome__UW_FreeTextCITPDExclusion__c  from '@salesforce/schema/UnderwritingOutcome__c.UW_FreeTextCITPDExclusion__c';
import UnderwritingOutcome__UW_FreeTextCITPDRemoval__c    from '@salesforce/schema/UnderwritingOutcome__c.UW_FreeTextCITPDRemoval__c';
import UnderwritingOutcome__UW_DecisionReason__c          from '@salesforce/schema/UnderwritingOutcome__c.UW_DecisionReason__c';
import UnderwritingOutcome__UW_Health_Reason__c           from '@salesforce/schema/UnderwritingOutcome__c.UW_Health_Reason__c';
import UnderwritingOutcome__URE_ReasonForGPR__c           from '@salesforce/schema/UnderwritingOutcome__c.URE_ReasonForGPR__c';
//IP fields
import UnderwritingOutcome__UW_Free_Format_IP_Exclusion__c from '@salesforce/schema/UnderwritingOutcome__c.UW_Free_Format_IP_Exclusion__c';
import UnderwritingOutcome__UW_Alternative_DP__c         from '@salesforce/schema/UnderwritingOutcome__c.UW_Alternative_DP__c';
import UnderwritingOutcome__UW_Alternative_DP_Text__c    from '@salesforce/schema/UnderwritingOutcome__c.UW_Alternative_DP_Text__c';


// These fields are used but (for ergonomic and readability reasons) the
// imported schema version is not used. We still want to import it so that
// Salesforce knows that the component is using this field.
import Case__SourceApplication__c          from '@salesforce/schema/Case.SourceApplication__c';
import UnderwritingOutcome__UW_Decision__c from '@salesforce/schema/UnderwritingOutcome__c.UW_Decision__c';

import STARTING_COMPONENT  from '@salesforce/label/c.CaseUnderwritingEditor_Starting';
import SAVING_UNDERWRITING from '@salesforce/label/c.CaseUnderwritingEditor_Saving';
import ERROR_SAVING        from '@salesforce/label/c.CaseUnderwritingEditor_Error_Saving';
import ERROR_UNKNOWN       from '@salesforce/label/c.CaseUnderwritingEditor_Error_Unknown';

import { WireConverter, getErrorMessage } from 'c/utility';

import getDisplayDensity from '@salesforce/apex/CaseUnderwritingEditor_Ctrl.getDisplayDensity';
import fetchDataForInit  from '@salesforce/apex/CaseUnderwritingEditor_Ctrl.fetchDataForInit';
import saveRecords       from '@salesforce/apex/CaseUnderwritingEditor_Ctrl.saveRecords';
import fetchExclusions   from '@salesforce/apex/CaseUnderwritingEditor_Ctrl.fetchExclusions';
import fetchRemovals     from '@salesforce/apex/CaseUnderwritingEditor_Ctrl.fetchRemovals';
import fetchPostpones    from '@salesforce/apex/CaseUnderwritingEditor_Ctrl.fetchPostpones';

function picklistOptions(opts) {
    return [ { label: '--None--', value: '' }, ...(opts || []) ];
}

const HIDDEN_FIELD_CONDITIONS = {
    [UnderwritingOutcome__UW_MortalityRating__c.fieldApiName]: {
        show(obj) { return 'Non-Standard Terms' === obj.UW_Decision__c; },
    },
    [UnderwritingOutcome__URE_PerMillePermanentRating__c.fieldApiName]: {
        show(obj, cmp) {
            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return true;
                default:
                    return obj.Cover__c === 'life';
            }

        },
    },
    [UnderwritingOutcome__UW_PerMillePermanentRating__c.fieldApiName]: {
        show(obj, cmp) {
            const baseVisibility = 'Non-Standard Terms' === obj.UW_Decision__c;

            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return baseVisibility && ((obj.Cover__c === 'ci' && cmp.hasCi) || obj.Cover__c === 'life');
                default:
                    return baseVisibility && obj.Cover__c === 'life';
            }

        },
    },
    [UnderwritingOutcome__UW_PerMilleTemporaryRating__c.fieldApiName]: {
        show(obj) { return 'Non-Standard Terms' === obj.UW_Decision__c; },
    },
    [UnderwritingOutcome__UW_TemporaryDuration__c.fieldApiName]: {
        show(obj) { return 'Non-Standard Terms' === obj.UW_Decision__c; },
    },
    [UnderwritingOutcome__UW_PostponeDuration__c.fieldApiName]: {
        show(obj) { return 'Postpone' === obj.UW_Decision__c; },
    },
    [UnderwritingOutcome__UW_GIOEligibility__c.fieldApiName]: {
        show(obj) { return 'Non-Standard Terms' === obj.UW_Decision__c || 'Standard Terms' === obj.UW_Decision__c; },
    },
    [UnderwritingOutcome__UW_UpsellEligibility__c.fieldApiName]: {
        show(obj) { return 'Non-Standard Terms' === obj.UW_Decision__c || 'Standard Terms' === obj.UW_Decision__c; },
    },
    [UnderwritingOutcome__UW_UpsellAmount__c.fieldApiName]: {
        show(obj) {
            return HIDDEN_FIELD_CONDITIONS.UW_UpsellEligibility__c.show(obj) && 'Yes' === obj.UW_UpsellEligibility__c;
        },
    },
    [UnderwritingOutcome__UWExclusions__c.fieldApiName]: {
        show(obj) { return 'Non-Standard Terms' === obj.UW_Decision__c || 'Standard Terms' === obj.UW_Decision__c || 'Own' === obj.UW_Decision__c || 'Activities' === obj.UW_Decision__c; },
    },
    [UnderwritingOutcome__UWRemovals__c.fieldApiName]: {
        show(obj) { return 'Non-Standard Terms' === obj.UW_Decision__c || 'Standard Terms' === obj.UW_Decision__c; },
    },
    [UnderwritingOutcome__UW_ACI_FreeText__c.fieldApiName]: {
        show(_, cmp) { return cmp.hasAci; },
    },
    [UnderwritingOutcome__UW_FreeTextCITPDExclusion__c.fieldApiName]: {
        show(_, cmp) {
            for(const record of Object.values(cmp.recordsById).map(v => v.liveData)) {
					if(!record.Cover__c.includes('ip')){
						const exclusions = new Set((record.UWExclusions__c || '').split(';'));
						if(exclusions.has('9999-Free Format Exclusion') || exclusions.has('9999')) {
							 return true;
						} 
					}
            }

            return false;
        },
    },
    [UnderwritingOutcome__UW_FreeTextCITPDRemoval__c.fieldApiName]: {
        show(obj) { 
            const removals = new Set((obj.UWRemovals__c || '').split(';'));
            if(removals.has('9998-Free Format Removal') || removals.has('9998')) {
                return true; 
            } 
            return false;
        },
    },
	 [UnderwritingOutcome__UW_Free_Format_IP_Exclusion__c.fieldApiName]: {
		show(obj) { 
			const exclusions = new Set((obj.UWExclusions__c || '').split(';'));
			if(exclusions.has('9999-Free Format Exclusion') || exclusions.has('9999')) {
				 return true; 
			} 
			return false;
		},
	},
    [UnderwritingOutcome__UW_DecisionReason__c.fieldApiName]: {
        show(obj) { return obj.UW_Decision__c && 'Standard Terms' !== obj.UW_Decision__c; },
    },
    [UnderwritingOutcome__UW_Health_Reason__c.fieldApiName]: {
        show(obj, cmp) { return new Set((obj.UW_DecisionReason__c || '').split(';')).has('Health')
            && ('nbj2' === cmp.caseDetails.SourceApplication__c || 'Protection Platform' === cmp.caseDetails.SourceApplication__c); },
    },
	 [UnderwritingOutcome__URE_ReasonForGPR__c.fieldApiName]: {
		show(_, cmp) { return 'nbj2' !== cmp.caseDetails.SourceApplication__c && 'Protection Platform' !== cmp.caseDetails.SourceApplication__c; },
	 },
	 [UnderwritingOutcome__UW_Alternative_DP__c.fieldApiName]: {
		show(obj) { return 'Decline' === obj.UW_Decision__c &&
		('ip_4' === obj.Cover__c || 'ip_8' === obj.Cover__c || 'ip_13' === obj.Cover__c); },
	 },
	 [UnderwritingOutcome__UW_Alternative_DP_Text__c.fieldApiName]: {
		show(obj) { return 'Decline' === obj.UW_Decision__c && ('13' === obj.UW_Alternative_DP__c || '26' === obj.UW_Alternative_DP__c); },
	 },
	 
};
const FIELD_DEFAULTS = {
    [UnderwritingOutcome__UW_UpsellAmount__c.fieldApiName]: {
        default(obj) { return obj.URE_UpsellAmount__c; }
    }
};
const FIELD_OVERRIDES = {
    [UnderwritingOutcome__UREExclusions__c.fieldApiName]: {
        overrideType(_, cmp) {
            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return { type: 'mspicklist', values: cmp.exclusionsList.data || [ ] };
                default:
                    return { type: 'standard' };
            }
        },
        outputText(obj, cmp) {
            const text     = obj.UREExclusions__c || '';
            const valueMap = cmp.exclusionsList.data?.reduce((o, v) => {
                o[v.value] = v.label;
                return o;
            }, { });
            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return text && text.split(';').map(s => valueMap[s]).join(';');
                default:
                    return text;
            }
        }
    },
    [UnderwritingOutcome__URERemovals__c.fieldApiName]: {
        overrideType(_, cmp) {
            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return { type: 'mspicklist', values: cmp.removalsList.data || [ ] };
                default:
                    return 'standard';
            }
        },
        outputText(obj, cmp) {
            const text     = obj.URERemovals__c || '';
            const valueMap = cmp.removalsList.data?.reduce((o, v) => {
                o[v.value] = v.label;
                return o;
            }, { });
            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return text && text.split(';').map(s => valueMap[s]).join(';');
                default:
                    return text;
            }
        }
    },
    [UnderwritingOutcome__UWExclusions__c.fieldApiName]: {
        overrideType(_, cmp) {
            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return { type: 'mspicklist', values: cmp.exclusionsList.data || [ ] };
                default:
                    return { type: 'standard' };
            }
        },
        outputText(obj, cmp) {
            const text     = obj.UWExclusions__c || '';
            const valueMap = cmp.exclusionsList.data?.reduce((o, v) => {
                o[v.value] = v.label;
                return o;
            }, { });
            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return text && text.split(';').map(s => valueMap[s]).join(';');
                default:
                    return text;
            }
        }
    },
    [UnderwritingOutcome__UW_PostponeDuration__c.fieldApiName]: {
        overrideType(_, cmp) {
            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return { type: 'picklist', values: picklistOptions(cmp.postponeList.data) };
                default:
                    return { type: 'standard' };
            }
        },
        outputText(obj, cmp) {
            const value = obj.UW_PostponeDuration__c;
            const label = value ? cmp.postponeList.data?.find(p => p.value === value)?.label : '';

            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return label;
                default:
                    return value;
            }
        }
    },
    [UnderwritingOutcome__UWRemovals__c.fieldApiName]: {
        overrideType(_, cmp) {
            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return { type: 'mspicklist', values: cmp.removalsList.data };
                default:
                    return { type: 'standard' };
            }
        },
        outputText(obj, cmp) {
            const text     = obj.UWRemovals__c || '';
            const valueMap = cmp.removalsList.data?.reduce((o, v) => {
                o[v.value] = v.label;
                return o;
            }, { });
            switch(cmp.caseDetails.SourceApplication__c) {
                case 'nbj2':
					 case 'Protection Platform':
                    return text && text.split(';').map(s => (valueMap[s] || s)).join(';');
                default:
                    return text;
            }
        }
    },
};

class RecordData {
    get id()       { return this.data.Id; }
    get liveData() { return this.changedData || this.data; }

    constructor(cmp, recordId, recordData, sections) {
        const fieldData = {
            sobjectType: UnderwritingOutcome__c.objectApiName,
            Id:          recordId,
        };
        for(const [field, values] of Object.entries(recordData.fields)) {
            fieldData[field] = values.value;
        }
        for(const [field, res] of Object.entries(FIELD_DEFAULTS)) {
            // Use of == rather than === to catch both `null` and `undefined`
            if(null == fieldData[field]) {
                fieldData[field] = res.default(fieldData);
            }
        }

        this.cmp            = cmp;
        this.name           = recordData.recordTypeInfo && recordData.recordTypeInfo.name; 
		  //IP should be labelled with cover value not just recordtype
		  if(this.name === 'IP'){
				this.name = fieldData['Cover__c'].replace('ip_','IP');
		  }
        this.data           = fieldData;
        this.changedData    = null;
        this.errors         = null;
        this.sections       = sections.map(s => new SectionData(this, s));
        this.editFormLoaded = false;
    }

    startEdit() {
        this.editFormLoaded = false;
        this.changedData    = { };
        for(const [field, value] of Object.entries(this.data)) {
            this.changedData[field] = value;
        }
    }
    finishEdit() {
        this.editFormLoaded = false;
        this.changedData    = null;
    }
    setField(fieldName, fieldValue) {
        if(this.changedData) {
            this.changedData[fieldName] = fieldValue;
        }
    }
}
class SectionData {
    constructor(record, section) {
        this.record      = record;

        this.id          = section.id;
        this.heading     = section.heading;
        this.showHeading = section.useHeading;
        this.columns     = section.columns;
        this.fields      = [ ];

        for(const row of section.layoutRows) {
            for(let i = 0; i < section.columns; ++i) {
                this.fields.push(new FieldData(this, row.layoutItems[i]));
            }
        }
    }
}
class FieldData {
    get divClass() { return `slds-p-horizontal_small slds-col slds-size_1-of-${this.section.columns}`;}

    get liveRecordData() { return this.section.record.liveData; }
    get liveValue()      {
        if(this.isOverrideMsPicklist) {
            return (this.liveRecordData[this.fieldApiName] || '').split(';');
        }
        return this.liveRecordData[this.fieldApiName] || '';
    }
    get mayHide()        { return this.fieldApiName && (this.fieldApiName in HIDDEN_FIELD_CONDITIONS); }
    get showField() {
        if(this.isField) {
            if(this.mayHide) {
                return HIDDEN_FIELD_CONDITIONS[this.fieldApiName].show(this.liveRecordData, this.section.record.cmp);
            }
            return true;
        }
        return false;
    }

    get override() {
        if(this.isField) {
            if(this.fieldApiName in FIELD_OVERRIDES) {
                return FIELD_OVERRIDES[this.fieldApiName].overrideType(this.liveRecordData, this.section.record.cmp);
            }
        }
        return { type: 'standard' };
    }
    get overrideType()         { return this.override.type; }
    get hasOverride()          { return this.overrideType !== 'standard'; }
    get isOverrideMsPicklist() { return this.overrideType === 'mspicklist'; }
    get isOverridePicklist()   { return this.overrideType === 'picklist'; }
    get useStandardOutput() {
        switch(this.overrideType) {
            case 'mspicklist':
            case 'picklist':
                return false;
            default:
                return true;
        }
    }
    get textOutputValue() {
        if(this.hasOverride) {
            return FIELD_OVERRIDES[this.fieldApiName].outputText(this.liveRecordData, this.section.record.cmp);
        }
        return this.liveValue;
    }

    constructor(section, rowItem) {
        this.section  = section;

        if(rowItem) {
            this.editableUpdate = rowItem.editableForUpdate;
            this.fieldApiName   = rowItem.layoutComponents[0].apiName;
            this.fieldLabel     = rowItem.layoutComponents[0].label;
            this.required       = rowItem.required;
            this.isField        = rowItem.layoutComponents[0].componentType === 'Field';
        } else {
            this.editableUpdate = false;
            this.fieldApiName   = '';
            this.fieldLabel     = '';
            this.required       = false;
            this.isField        = false;
        }
    }
}

export default class CaseUnderwritingEditor extends LightningElement {
    @api recordId;

    @track globalError   = null;
    @track editErrorText = null;
    @track loading       = STARTING_COMPONENT;
    @track mode          = 'view';
    @track recordsById   = { };
    @track uwoRecordIds  = [ ];

    coveredProducts = new Set();
    focusCallback   = null;

    get UnderwritingOutcome__c() { return UnderwritingOutcome__c; }

    get isView()  { return this.mode === 'view'; }
    get records() { return Object.values(this.recordsById); }

    get hasAci() { return this.coveredProducts.has('aci'); }
    get hasCi()  { return this.coveredProducts.has('ci'); }

    get displayDensityVariant() {
        switch(this.displayDensity.data) {
            case 'VIEW_TWO':
                return 'label-inline';
            default:
                return 'standard';
        }
    }
    get outputTextClass() {
        const classes = [
            'slds-col', 'slds-grow', 'slds-form-element'
        ]
        switch(this.displayDensity.data) {
            case 'VIEW_TWO':
                classes.push('slds-form-element_horizontal');
                break;
            default:
                classes.push('slds-form-element_stacked');
                break;
        }
        return classes.join(' ');
    }

    recordUiConverter = new WireConverter();
    @wire(getRecordUi, { recordIds: "$uwoRecordIds", layoutTypes: "Full", modes: "View", optionalFields: [ UnderwritingOutcome__Cover__c ] })
    recordUi(result) {
        this.recordUiConverter.handleResult(result);
    }

    @wire(fetchExclusions, { caseId: "$recordId" })
    exclusionsList;

    @wire(fetchRemovals, { caseId: "$recordId" })
    removalsList;

    @wire(fetchPostpones, { caseId: "$recordId" })
    postponeList;

    @wire(getDisplayDensity)
    displayDensity;

    @wire(MessageContext)
    messageContext;

    async setupLayouts() {
        const recordsById = { };

        if(this.uwoRecordIds.length !== 0) {
            const data = await this.recordUiConverter.fetch();

            for(const recordId of this.uwoRecordIds) {
                const rtId = data.records[recordId].recordTypeId;
                // Build up the page layout for the specified record type
                //
                // (For now we presume that View and Edit are the same, as far as I
                // know the only difference will be the section headers and
                // currently there aren't any headers anyway)
                //
                // There should only be one of each record type, so there won't be
                // any realistic benefit to memoizing the results of each record
                // type's layout.
                recordsById[recordId] = new RecordData(
                    this,
                    recordId,
                    data.records[recordId],
                    data.layouts.UnderwritingOutcome__c[rtId].Full.View.sections,
                );
            }
        }

        this.recordsById = recordsById;
    }

    async connectedCallback() {
        try {
            const initData = await fetchDataForInit({ caseId: this.recordId });

            this.recordUiConverter.reset();
            this.uwoRecordIds    = initData.UnderwritingOutcomeIds;
            this.coveredProducts = new Set(initData.CoveredProducts);
            this.caseDetails     = initData.CaseDetails;
            await this.setupLayouts();
        } catch(err) {
            this.handleError(err);
        }
        this.loading = null;
    }

    handleError(err) {
        console.error(err);

        this.editErrorText = ERROR_SAVING;
        this.globalError   = getErrorMessage(err, ERROR_UNKNOWN);
    }
    returnToViewMode() {
        // Clear the errors for the records so that they don't show up again
        // when reopening edit mode
        for(const record of this.records) {
            record.errors = null;
        }

        this.focusField    = null;
        this.editErrorText = null;
        this.mode          = 'view';

        publish(this.messageContext, CaseUnderwritingEditorState__c, {
            recordId: this.recordId,
            state: this.mode,
        });
    }

    // =========================================================================
    // Event Handlers
    // =========================================================================
    onEdit(e) {
        if(e.target && "true" === e.target.dataset.editable) {
            this.focusFieldName = e.target.dataset.fieldName;
            this.focusRecordId  = e.target.dataset.recordId;
            this.recordsById[this.focusRecordId].startEdit();
            for(const record of this.records) {
                record.startEdit();
            }
            this.mode = 'edit';

            publish(this.messageContext, CaseUnderwritingEditorState__c, {
                recordId: this.recordId,
                state: this.mode,
            });
        }
    }
    onCancelEdit() {
        for(const record of this.records) {
            record.finishEdit();
        }
        this.returnToViewMode();
    }
    onEditLoad(e) {
        if(e.target) {
            const isFirstLoad = !this.recordsById[e.target.recordId].editFormLoaded;
            this.recordsById[e.target.recordId].editFormLoaded = true;

            // If we haven't set the target field yet, see if this one works.
            // The focus field is the field we want to be put into focus after
            // all of the forms have loaded, so that people can find the field
            // they've chosen to modify quickly.
            if(e.target.recordId === this.focusRecordId && !this.focusField) {
                const field     = e.target.querySelector(`lightning-input-field[data-field-name="${this.focusFieldName}"]`);
                this.focusField = field;
            }
            if(isFirstLoad && this.focusField) {
                // This needs to be behind a setTimeout because otherwise it
                // seems to happen before the repaint of the browser, which
                // means that the object isn't yet in the viewport and can't be
                // focused. That's my guess anyway.

                // We only ever need one callback to happen at a time.
                if(this.focusCallback) clearTimeout(this.focusCallback);
                // eslint-disable-next-line @lwc/lwc/no-async-operation
                this.focusCallback = setTimeout(() => {
                    // If we've got the target field, we want to jump to it and
                    // put it into focus. We do this after every form loads. We
                    // could just do it once after all forms have finished
                    // loading, but that didn't seem to work, or at the very
                    // least didn't have the same effect.
                    this.focusField.focus();
                    this.focusField.scrollIntoView({
                        behaviour: 'auto',
                        block:     'center',
                        inline:    'center',
                    });
                    this.focusCallback = null;
                }, 1);
            }
        }
    }
    onEditField(e) {
        if(e.target) {
            const field    = e.target.dataset.fieldName;
            const recordId = e.target.dataset.recordId;

            if(field && recordId) {
                let value = e.target.value;
                if(Array.isArray(value)) value = value.join(';');

                this.recordsById[recordId].setField(field, value);

                // Changing the record might have changed which fields need to
                // be shown, so we need to trigger a rerender.
                this.recordsById = { ...this.recordsById };
            }
        }
    }
    async onSave() {
        // Make sure that the client-side validations are done as soon as
        // possible (e.g. field required on the page layout)
        let allValid = true;
        for(const elt of this.template.querySelectorAll('[data-input-validation]')) {
            allValid = !!(allValid & elt.reportValidity());
        }

        if(allValid) {
            this.loading = SAVING_UNDERWRITING;

            try {
                const records = [ ];
                for(const record of Object.values(this.recordsById).map(v => v.liveData)) {
                    for(const [fieldName, cond] of Object.entries(HIDDEN_FIELD_CONDITIONS)) {
                        // If the field isn't shown, blank the field before saving it
                        if(!cond.show(record, this)) record[fieldName] = null;
                    }
                    records.push(record);
                }
                const errs = await saveRecords({ records });

                // If there aren't any errors then everything's been saved and
                // we can return to view mode.
                if(0 === Object.keys(errs).length) {
                    // Reseting this makes it so that the new values are
                    // reflected in the record-view-form for some reason, I'm
                    // going to guess it's because it refetches the data which
                    // is used by the form as well but I'm not too sure.
                    this.recordUiConverter.reset();
                    await this.setupLayouts();

                    this.returnToViewMode();

                    // Inform the rest of the system that the records are dirty
                    // and need to be refreshed.
                    getRecordNotifyChange(this.uwoRecordIds.map(id => ({ recordId: id })));
                // If there are errors we need to show them. Ideally we'd show
                // errors on the fields themselves but I couldn't think of a
                // good way to do that, so we just show all errors on the top of
                // the section.
                //
                // Currently, there aren't any errors which should occur, so
                // putting effort into displaying the errors in a nicer fashion
                // feels like wasted effort, but maybe in future it will have
                // some value.
                } else {
                    this.editErrorText = ERROR_SAVING;

                    for(const record of this.records) {
                        const errors = errs[record.id] || [ ];

                        record.errors = errors.join("\r\n");
                    }
                }
            } catch(err) {
                this.handleError(err);
            }

            this.loading = null;
        }
    }
}