import { LightningElement,api,wire } from 'lwc';

//lightning imports
import { CloseActionScreenEvent } from 'lightning/actions';
import { createRecord, getRecord  } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import { encodeDefaultFieldValues } from 'lightning/pageReferenceUtils';

//apex imports
import checkForExistingChildCase from '@salesforce/apex/NewProductClaim_LEx.checkForExistingChildCase';
import fetchRecordType from '@salesforce/apex/LExToolkit.fetchRecordType';
import getProductClaimOptions from '@salesforce/apex/NewProductClaim_LEx.getProductClaimOptions';

//Salesforce Imports
import CASE_OBJECT from '@salesforce/schema/Case';
import CASE_FIELD__RECORDTYPEID from '@salesforce/schema/Case.RecordTypeId';
import CASE_FIELD__ACCOUNTID from '@salesforce/schema/Case.AccountId';
import CASE_FIELD__PARENTCASE from '@salesforce/schema/Case.ParentId';
import CASE_FIELD__ORIGIN from '@salesforce/schema/Case.Origin';

//Consts
const CASE_FIELDS = [CASE_FIELD__ACCOUNTID];

export default class NewProductClaim extends NavigationMixin(LightningElement) {
    saveButtonLabel = 'Save';
    productOptions;   //product options for radio button
    selectedCaseRT = null;
    doing = false;
    _recordId     = null;
    checkForExisting;   //set of options that check for existing Cases
    redirectToNewCase;  //set of options that navigate to the new Case page


    //get the RecordId since quick actions don't have this built in
    @api
    get recordId()      { return this._recordId; }
    set recordId(value) {
        this._recordId = value;
    }

    //get the Policy Claim Case
    @wire(getRecord, { recordId: '$recordId', fields: CASE_FIELDS })
    case

    //init
    async connectedCallback() {
        //get radio option custom metadata
        let options = await getProductClaimOptions();

        //build the settings from the custom metadata
        this.productOptions = options.map(opt => {
            return {
                label: opt.Choice_Label__c, 
                value: opt.Choice_Record_Type_Developer_Name__c
            };
        });
        this.checkForExisting = new Set(options.filter(opt => opt.Check_For_Existing__c).map(opt => {return opt.Choice_Record_Type_Developer_Name__c}));
        this.redirectToNewCase = new Set(options.filter(opt => opt.Redirect_To_New_Record__c).map(opt => {return opt.Choice_Record_Type_Developer_Name__c}));
    }

    //disable the confirm button until a RT is selected
    get disabled(){
        return this.doing || !this.selectedCaseRT;
    }

    //handle radio selection event
    handleProductChange(event){
        this.selectedCaseRT = event.detail.value;
    }

    //submit button
    async handleSubmit(event) {
        this.doing = true;

        //if the selected RT has setting that requires to check existing
        if(this.checkForExisting.has(this.selectedCaseRT)){
            //get from apex existing child cases
            let relProductClaims = await checkForExistingChildCase({
                policyClaimId : this.recordId,
                recordType : this.selectedCaseRT
            });
            //if there are any existing then throw toast
            if(relProductClaims && relProductClaims.length){
                let firstCase = relProductClaims[0];
                this.throwToastWithLink(firstCase.Id);
                this.doing = false;
                return;
            }
        }

        //get the RT
        let rt = await fetchRecordType({ 
            pObjectName: CASE_OBJECT.objectApiName, 
            pRecordTypeDeveloperName: this.selectedCaseRT 
        });

        //set the common fields for the new case
        let caseFields = {
            [CASE_FIELD__RECORDTYPEID.fieldApiName]: rt.Id,
            [CASE_FIELD__ACCOUNTID.fieldApiName]: this.case.data.fields.AccountId.value,
            [CASE_FIELD__PARENTCASE.fieldApiName] : this.recordId,
            [CASE_FIELD__ORIGIN.fieldApiName] : 'Salesforce'
        };

        //if true then redirect to new Case
        if(this.redirectToNewCase.has(this.selectedCaseRT)){
            //navigate to the new record
            const defaultValues = encodeDefaultFieldValues(caseFields);
    
            this[NavigationMixin.Navigate]({
                type: 'standard__objectPage',
                attributes: {
                    objectApiName: CASE_OBJECT.objectApiName,
                    actionName: 'new'
                },
                state: {
                    defaultFieldValues: defaultValues,
                    recordTypeId:rt.Id
                }
            });
        }
        //else create case and redirect 
        else{
            //create the new child Product case or claims case
            let record = await createRecord({
                apiName: CASE_OBJECT.objectApiName,
                fields: caseFields
            });

            setTimeout(() => {
            //throw toast
            let msg = 'Successfully created new ' + rt.Name + ' Case';
            this.showToast('Success',msg,'success');

            //navigate to the new record
            this[NavigationMixin.Navigate]({
                type: 'standard__recordPage',
                attributes: {
                    "recordId": record.id,
                    "objectApiName": CASE_OBJECT.objectApiName,
                    "actionName": "view"
                },
            })

        // Close the modal window and display a success toast
        this.dispatchEvent(new CloseActionScreenEvent());
        }, 4000);
    }
    }

    //redirect to existing case
    async throwToastWithLink(recordId){
        
        //build url
        let url = await this[NavigationMixin.GenerateUrl]({
            type: 'standard__recordPage',
            attributes: {
                recordId: recordId,
                actionName: 'view',
            },
        });

        //show toast with url
        let msg = 'Click {0} to view';
        let msgData = [
            {
                url,
                label: 'here',
            },
        ];
        this.showToast('There is already a Product Claim',msg,'info','sticky',msgData);
    }

    //cancel modal
    handleCancel(event) {
        this.dispatchEvent(new CloseActionScreenEvent());
    }

    //show toast
    showToast(_title, message, variant, _mode, _messageData){
        const evt = new ShowToastEvent({
            title: _title,
            message: message,
            variant: variant, //options: error, warning, success, info
            mode: _mode,
            messageData: _messageData
        });
        this.dispatchEvent(evt);
    }

}