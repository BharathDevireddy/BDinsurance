import {LightningElement, api} from 'lwc';

export default class Timeline extends LightningElement {

    @api
    timelineEntries = [];

    onAssessmentSaved() {
        this.dispatchEvent(new CustomEvent('assessmentsaved'));
    }

}