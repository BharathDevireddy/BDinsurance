import {LightningElement, track, api} from 'lwc';

import getAssessmentData from '@salesforce/apex/AssessmentList_LEx.getAssessmentData';

import BODY from './assessmentList.html';
import EMPTY_LIST_TEMPLATE from './emptyList.html';

export default class AssessmentList extends LightningElement {

    @api parentCaseId;
    @track assessmentPeriods = [];
    isLoading = false;

    connectedCallback() {
        this.getAssessmentData();
    }

    @api
    getAssessmentData(filters) {
        this.isLoading = true;
        getAssessmentData({pFilters: filters, pParentCaseId: this.parentCaseId})
            .then(result => {
                this.assessmentPeriods = result;
            })
            .catch(error => {
                console.log(error);
            })
            .finally(() => {
                this.isLoading = false;
            })
    }

    onAssessmentSaved() {
        this.getAssessmentData();
    }

    render() {
        if (!this.assessmentPeriods.length) {
            return EMPTY_LIST_TEMPLATE;
        } else {
            return BODY;
        }
    }

}