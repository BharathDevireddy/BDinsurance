//LWC Imports
import { api, track } from 'lwc';

//Component imports
import ClaimsComponent from 'c/claimsComponent';

//Constants
import { COVER_DETAIL_LAYOUT } from './constants.js';
import BODY from './coverDetail.html';

export default class CoverDetail extends ClaimsComponent {

    /*=========================================================
            Claims Component Vars
    =========================================================*/

    componentLabel = 'Cover Detail';
    componentBody = BODY;

    /*=========================================================
           Vars
    =========================================================*/
    
    @api policyRef;
    @api coverRef;

    @track formData = {};

    layout = COVER_DETAIL_LAYOUT;
    
    /*=========================================================
           Setup
    =========================================================*/
    
    /**
     * Once connected, callout to the claims data service to fetch the details for the provided cover,
     * then create the form data object needed to display it in the UI
     */
    async connectedCallback() {
        try {
            let details = await this.ClaimsDataService.fetchCoverDetails(this.policyRef, this.coverRef);
            this.formData = {
                Status: details.Status,
                Cover: details.Cover,
                SingleOrDual: details.RoleSummary.SingleOrDual,
                OriginalAmount: details.OriginalAmount,
                Amount: details.Amount,
                QuoteDate: details.QuoteDate,
                StartDate: details.CoverStartDate,
                EndDate: details.CoverEndDate,
                Term: details.Term.Label,
                Type: details.Type,
                Exclusion: details.ExclusionsSummary.ExclusionsText,
                PostInceptionChange: details.PostInceptionChangesSummary.PostInceptionChangesText,
                DeedOfAssignment: details.RoleSummary.DeedOfAssignment,
                BeneficiaryType: details.RoleSummary.BeneficiaryType,
                CurrentDeathBenefitAmount: details.CurrentDeathBenefitAmount,
                DeferredPeriod: details.DeferredPeriod
            }
        } catch(ex) {
            this.ErrorHandling.logErrorFromException(ex);
        } finally {
            this.State.show();
        }
    }

}