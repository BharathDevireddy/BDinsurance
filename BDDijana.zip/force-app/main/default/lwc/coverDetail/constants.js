export const COVER_DETAIL_LAYOUT = [
    {
        collapsible: true,
        heading: 'Cover',
        useHeading: true,
        subSections: [
            {
                id: 0,
                columns: 2,
                rows: [
                    {
                        fields: [
                            {
                                label: 'Status',
                                fieldName: 'Status',
                                fieldType: 'Text'
                            },
                            {
                                label: 'Type',
                                fieldName: 'Type',
                                fieldType: 'Text'
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Original Amount',
                                fieldName: 'OriginalAmount',
                                fieldType: 'Number',
                                fieldTypeAttributes: {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                }
                            },
                            {
                                label: 'Amount',
                                fieldName: 'Amount',
                                fieldType: 'Number',
                                fieldTypeAttributes: {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                }
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Quote Date',
                                fieldName: 'QuoteDate',
                                fieldType: 'DateTime',
                                fieldTypeAttributes: {
                                    day: '2-digit',
                                    month: '2-digit',
                                    year: 'numeric'
                                }
                            },
                            {
                                label: 'Start Date',
                                fieldName: 'StartDate',
                                fieldType: 'DateTime',
                                fieldTypeAttributes: {
                                    day: '2-digit',
                                    month: '2-digit',
                                    year: 'numeric'
                                }
                            },
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'End Date',
                                fieldName: 'EndDate',
                                fieldType: 'DateTime',
                                fieldTypeAttributes: {
                                    day: '2-digit',
                                    month: '2-digit',
                                    year: 'numeric'
                                }
                            },
                            {
                                label: 'Term',
                                fieldName: 'Term',
                                fieldType: 'Number'
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Post Inception Change',
                                fieldName: 'PostInceptionChange',
                                fieldType: 'Text'
                            },
                            {
                                label: 'Deed of Assignment',
                                fieldName: 'DeedOfAssignment',
                                fieldType: 'Text'
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Beneficiary Type',
                                fieldName: 'BeneficiaryType',
                                fieldType: 'Text'
                            },
                            {
                                isBlank: true
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        collapsible: true,
        heading: 'Benefit',
        useHeading: true,
        subSections: [
            {
                id: 0,
                columns: 2,
                rows: [
                    {
                        fields: [
                            {
                                label: 'Current Death Benefit Amount',
                                fieldName: 'CurrentDeathBenefitAmount',
                                fieldType: 'Number',
                                fieldTypeAttributes: {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                }
                            },
                            {
                                label: 'Deferred Period',
                                fieldName: 'DeferredPeriod',
                                fieldType: 'Number'
                            }
                        ]
                    }
                ]
            }
        ]
    }
]