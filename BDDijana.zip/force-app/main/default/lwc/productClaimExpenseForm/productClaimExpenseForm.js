import { LightningElement, track, api } from 'lwc';
import { updateExpenseOnProductClaim } from 'c/productClaimDataHandler';
//constants
import { EXPENSE_TYPE, EXPENSE_TYPE_INVESTIGATIVE,EXPENSE_TYPE_MEDICAL,EXPENSE_TYPE_REHABILITATION,EXPENSE_TYPE_OTHER } from './constants';


export default class ProductClaimExpenseForm extends LightningElement {

    @api claimExternalId;
    @api tabReadOnlyData;
    expense = {};
    expenseID;

    @track expense_type_options = EXPENSE_TYPE;
    @track description_options;
    modalVisible = false;

    // if:true values
    @track showNewExpenseForm = false;
    @track disableButton = false;

    //for disabled button on description
    //@track disableDescription = true;

    connectedCallback(){
        console.log('EXPENSE FORM DATA  '+JSON.stringify(this.tabReadOnlyData));
    }

    addNewExpense(event){
        this.showNewExpenseForm = true;
        this.disableButton = true;
    }

    onExpenseTypeChange(event){
        /*console.log('value '+event.detail.value);
        if(event.detail.value === 'Investigative'){
            this.description_options = EXPENSE_TYPE_INVESTIGATIVE;
        }else if(event.detail.value === 'Medical'){
            this.description_options = EXPENSE_TYPE_MEDICAL;
        }else if(event.detail.value === 'Rehabilitation'){
            this.description_options = EXPENSE_TYPE_REHABILITATION;
        }else if(event.detail.value === 'Other'){
            this.description_options = EXPENSE_TYPE_OTHER;
        }*/
        //this.disableDescription = false;
    }

    handleExpenseDataChange(e){

        if(e.target.name == 'expenseDate' )
        {
           this.expense.expenseDate = e.target.value;
        }
        else if(e.target.name== 'productClaimExpenseTypeID' )
        {
            this.expense.productClaimExpenseType = parseInt(e.target.value);
        }
        else if(e.target.name== 'productClaimExpenseDescriptionID' )
        {
            this.expense.description = parseInt(e.target.value);
        }
        else if(e.target.name== 'maximumAmountPermitted' )
        {
            this.expense.maximumAmountPermitted = parseInt(e.target.value);
        }
        else if(e.target.name== 'amount' )
        {
            this.expense.amount = parseInt(e.target.value);
        }
        else if(e.target.name== 'amountReclaimable' )
        {
            this.expense.amountReclaimable = parseInt(e.target.value);
        }
        else if(e.target.name== 'payee' )
        {
            this.expense.payee = e.target.value;
        }
        else if(e.target.name== 'invoiceNumber' )
        {
            this.expense.invoiceNumber = e.target.value;
        }
        else if(e.target.name== 'financeNotificationDate' )
        {
            this.expense.financeNotificationDate = e.target.value;
        }
        else if(e.target.name== 'additionalInformation' )
        {
            this.expense.additionalInformation = e.target.value;
        }
        console.log('expnese *** '+JSON.stringify(this.expense));
    }

    onUpdate(event){
        console.log('update clicked ');
        updateExpenseOnProductClaim(this.expenseID,JSON.stringify(this.expense)).then(result => {
            console.log('pozvao sam update eksterni servis');
        });
        this.closeModal();
    }

    @api
    showModal(data) {
        console.log('show modal '+JSON.stringify(data));
        this.expense = data;
        console.log('show ID  '+JSON.stringify(data.productClaimExpenseID));
        this.expenseID = data.productClaimExpenseID;
        this.modalVisible = true;
    }

    @api
    closeModal() {
        this.modalVisible = false;
    }
}