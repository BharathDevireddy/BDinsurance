import { api, track, wire, LightningElement }              from 'lwc';
import { NavigationMixin }                                 from 'lightning/navigation';
import { getFieldValue, getRecordNotifyChange, getRecord } from 'lightning/uiRecordApi';

import { getErrorMessage } from 'c/utility';

import CONFIRMATION_ADVISER from '@salesforce/label/c.DisableExtranet_Confirmation_Adviser';
import CONFIRMATION_CLIENT  from '@salesforce/label/c.DisableExtranet_Confirmation_Client';
import SUCCESS_ADVISER      from '@salesforce/label/c.DisableExtranet_Success_Adviser';
import SUCCESS_CLIENT       from '@salesforce/label/c.DisableExtranet_Success_Client';
import TITLE_ADVISER        from '@salesforce/label/c.DisableExtranet_Title_Adviser';
import TITLE_CLIENT         from '@salesforce/label/c.DisableExtranet_Title_Client';

import Account_Name          from '@salesforce/schema/Account.Name';
import FirmAdviser_Name      from '@salesforce/schema/Firm_Adviser__c.Name';
import FirmAdviser_FirstName from '@salesforce/schema/Firm_Adviser__c.First_Name__c';
import FirmAdviser_LastName  from '@salesforce/schema/Firm_Adviser__c.Last_Name__c';

import disableAdviserDashboard        from '@salesforce/apex/DisableExtranet_Ctrl.disableAdviserDashboard';
import disableClientMyGuardianAccount from '@salesforce/apex/DisableExtranet_Ctrl.disableClientMyGuardianAccount';

const VALUES_CLIENT = {
    baseTitle:        TITLE_CLIENT,
    confirmationText: CONFIRMATION_CLIENT,
    successText:      SUCCESS_CLIENT,
    nameFields:       Account_Name,
    disable:          async accountId => disableClientMyGuardianAccount({ accountId }),
    recordName:       record => getFieldValue(record, Account_Name),
};
const VALUES_ADVISER = {
    baseTitle:        TITLE_ADVISER,
    confirmationText: CONFIRMATION_ADVISER,
    successText:      SUCCESS_ADVISER,
    nameFields:       [ FirmAdviser_Name, FirmAdviser_FirstName, FirmAdviser_LastName ],
    disable:          async adviserId => disableAdviserDashboard({ adviserId }),
    recordName:       record => {
        const recordName = getFieldValue(record, FirmAdviser_Name);
        const firstName  = getFieldValue(record, FirmAdviser_FirstName);
        const lastName   = getFieldValue(record, FirmAdviser_LastName);

        const nameParts = [ ];
        if(firstName) nameParts.push(firstName);
        if(lastName) nameParts.push(lastName);

        const fullName = nameParts.join(' ');
        return fullName ? `${recordName} (${fullName})` : recordName;
    }
};
const VALUES_EMPTY = {
    baseTitle:        '',
    confirmationText: '',
    successText:      '',
    nameFields:       null,
    disable:          async () => { throw new Error('Invalid type') },
    recordName:       () => '',
};

export default class DisableExtranet extends NavigationMixin(LightningElement) {
    @api
    get recordId() { return this._recordId; }
    set recordId(value) {
        this.record    = null;
        this._recordId = value;
    }
    @api type;

    /**
     * @description Revert the internal state of the component to be like
     * running from fresh
     */
    @api
    clearState() {
        this.error    = null;
        this.loading  = null;
        this.finished = null;
    }

    @track _recordId = null;
    @track error     = null;
    @track loading   = null;
    @track record    = null;
    @track finished  = false;

    @wire(getRecord, { recordId: "$recordId", fields: "$nameFields" })
    getRecordFunc({ data, error }) {
        if(data) {
            this.record = data;
        }
        if(error) {
            console.error(error);
            this.error = getErrorMessage(error);
        }
    }

    get typeValues() {
        switch(this.type) {
            case 'client':
                return VALUES_CLIENT;
            case 'adviser':
                return VALUES_ADVISER;
            default:
                return VALUES_EMPTY;
        }
    }

    get nameFields()       { return this.typeValues.nameFields; }
    get recordName()       { return this.record ? this.typeValues.recordName(this.record) : ''; }
    get baseTitle()        { return this.typeValues.baseTitle; }
    get confirmationText() { return this.typeValues.confirmationText; }
    get successText()      { return this.typeValues.successText; }
    get pageTitle()        { return this.baseTitle + (this.recordName ? ` - ${this.recordName}` : ''); }

    /**
     * @description Fires a request off to the back office to disable this
     * client/adviser's access to the Extranet.
     */
    async confirmRequest() {
        if(this.loading) return;

        this.loading = "Disabling";

        try {
            await this.typeValues.disable(this.recordId);
            getRecordNotifyChange([{ recordId: this.recordId }]);

            this.finished = true;
        } catch(err) {
            console.error(err);
            this.error = getErrorMessage(err);
        } finally {
            this.loading = null;
        }
    }

    /**
     * @description Navigates to the record which this process was started on
     */
    returnToRecord() {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId:   this.recordId,
                actionName: 'view',
            }
        });
    }
}