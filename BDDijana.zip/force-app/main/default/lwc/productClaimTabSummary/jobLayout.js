export const JOB_LAYOUT_DATA = {
    id: 'job-repeating',
    columns: 2,
    style: 'border: 2px #E3E3E3 solid; margin: 10px 0px 10px 15px; width:95%; padding-bottom:5px; padding-top:3px;',
    isDeletable: false,
    rows: [
        {
            fields: [
                {
                    label: 'Job Title',
                    fieldName: 'jobTitle',
                    fieldType: 'Text',
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none;',
                    isEditable: true
                },
                {
                    label: 'Employer or Trading Name',
                    fieldName: 'employerName',
                    fieldType: 'Text',
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none;',
                    isEditable: true
                }
            ]
        },
        {
            fields: [
                {
                    label: 'Earnings Type',
                    fieldName: 'employmentType',
                    fieldType: 'Picklist',
                    isEditable: true,
                    style: 'margin-top: -20px;',
                    formElementStyle: 'border-bottom:none;',
                    options: [
                        {label: 'Employed', value: 'employed'},
                        {label: 'Employed Director', value: 'employedCD'},
                        {label: 'Self-Employed', value: 'selfEmployed'},
                        {label: 'Unemployed', value: 'unemployed'},
                        {label: 'Employed & Self-Employed', value: 'employedAndSelf'}
                    ]
                },
                {
                    label: 'Hours Worked',
                    fieldName: 'hoursWorked',
                    fieldType: 'Number',
                    style: 'margin-top: -20px;',
                    isEditable: true,
                    formElementStyle: 'border-bottom:none;',
                    fieldTypeAttributes: {
                        minimumFractionDigits: 0,
                        maximumFractionDigits: 0
                    }
                }
            ]
        },
        {
            fields: [
                {
                    label: 'Nature of Duties',
                    fieldName: 'natureOfDuties',
                    fieldType: 'TextArea',
                    style: 'margin-top: -20px;',
                    isEditable: true,
                    formElementStyle: 'border-bottom:none;'
                }
            ]
        }
    ]
}