export const LAYOUT_DATA = [
    {
        id: 1,
        collapsible: true,
        heading: 'Important Notes',
        useHeading: true,
        headingStyle: 'margin-left:20px; width:95%;',
        subSections: [
            {
                id: 0,
                columns: 1,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: 'Next Action Date',
                                fieldName: 'New_Claim_Next_Action_Date__c',
                                fieldType: 'Date',
                                style: 'margin-top: -20px; width:50%;',
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; margin-top:10px; margin-left:15px;',
                                fieldTypeAttributes: {
                                    day: '2-digit',
                                    month: '2-digit',
                                    year: 'numeric'
                                }
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Important Notes',
                                fieldName: 'importantNotes',
                                fieldType: 'RichTextArea',
                                style: 'width:98%;',
                                fieldTypeAttributes: {
                                    formats: [
                                        'font',
                                        'size',
                                        'bold',
                                        'italic',
                                        'underline',
                                        'list',
                                        'indent',
                                        'align',
                                        'link',
                                        'clean',
                                        'table',
                                        'header'
                                    ]
                                },
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; margin-left:15px;'
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Reserve',
                                fieldName: 'reserve',
                                fieldType: 'Currency',
                                style: 'margin-top: -20px; width:98%;',
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                fieldTypeAttributes: {
                                    formatter: 'currency',
                                    step: '.01'
                                }
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Risk Score',
                                fieldName: 'riskScore',
                                fieldType: 'Number',
                                style: 'margin-top: -20px; margin-bottom:20px; width:98%;',
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                fieldTypeAttributes: {
                                    minimumFractionDigits: 0,
                                    maximumFractionDigits: 0
                                }
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        id: 2,
        collapsible: true,
        heading: 'Incapacity',
        useHeading: true,
        headingStyle: 'margin-left:20px; width:95%; margin-bottom:20px;',
        subSections: [
            {
                id: 'incapacity-static',
                columns: 1,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: 'Original Date of Incapacity',
                                fieldName: 'originalIncapacityDate',
                                fieldType: 'Date',
                                style: 'margin-top: -20px; width: 50%;',
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; padding-top:10px; margin-left:15px;',
                                fieldTypeAttributes: {
                                    day: '2-digit',
                                    month: '2-digit',
                                    year: 'numeric'
                                }
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: '',
                                internalLabel: 'Incapacity Categories', // used just for resolving the margin problem of the label
                                fieldName: 'incapacityCategories',
                                fieldType: 'DualList',
                                isEditable: true,
                                style: 'margin-top: -10px; margin-left:13px; width:97%;',
                                formElementStyle: 'border-top: none; border-bottom: none; padding-bottom:10px;',
                                fieldTypeAttributes: {
                                    sourceLabel: 'Available',
                                    selectedLabel: 'Selected',
                                    disableReordering: true
                                },
                                options: [
                                    {label: 'Cancer', value: 'cancer'},
                                    {label: 'Cardiac Conditions', value: 'cardiacConditions'},
                                    {label: 'CFS', value: 'cfs'},
                                    {label: 'Chronic Pain', value: 'chronicPain'},
                                    {label: 'Complex Multiple', value: 'complexMultiple'},
                                    {label: 'Disease of Eye and Ear', value: 'diseaseOfEyeAndEar'},
                                    {label: 'Gastrointestinal', value: 'gastrointestinal'},
                                    {label: 'Genitourinary', value: 'genitourinary'},
                                    {label: 'Long Covid', value: 'longCovid'},
                                    {label: 'Musculoskeletal', value: 'musculoskeletal'},
                                    {label: 'Neurological', value: 'neurological'},
                                    {label: 'Respiratory', value: 'respiratory'},
                                    {label: 'Work Related Stress', value: 'workRelatedStress'},
                                    {label: 'Other', value: 'other'}
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                id: 'incapacity-button',
                columns: 1,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: 'New Incapacity',
                                fieldName: 'NewIncapacityButton',
                                fieldType: 'Button',
                                formElementStyle: 'border-bottom:none; border-top: 3px solid #F3F3F3; margin-top: 10px; margin-bottom:20px;',
                                formElementStaticStyle: 'padding-top:10px; padding-bottom:10px; margin-left:15px; width:95%;'
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        id: 3,
        collapsible: true,
        heading: 'Job',
        useHeading: true,
        headingStyle: 'margin-left:20px; width:95%; margin-top:-20px;',
        subSections: [
            {
                id: 'job-button',
                columns: 1,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: 'New Earnings',
                                fieldName: 'NewIEarningsButton',
                                fieldType: 'Button',
                                formElementStyle: 'border-bottom:none; border-top: 3px solid #F3F3F3; margin-top: 10px;',
                                formElementStaticStyle: 'padding-top:10px; padding-bottom:10px; margin-left:15px; width:95%;'
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        id: 4,
        collapsible: true,
        heading: 'Websites',
        useHeading: true,
        headingStyle: 'margin-left:20px; width:95%;',
        subSections: [
            {
                id: 0,
                columns: 1,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: '',
                                fieldName: 'websites',
                                fieldType: 'RichTextArea',
                                style: 'margin-top: -15px; width:99%;',
                                fieldTypeAttributes: {
                                    formats: [
                                        'font',
                                        'size',
                                        'bold',
                                        'italic',
                                        'underline',
                                        'list',
                                        'indent',
                                        'align',
                                        'link',
                                        'clean',
                                        'table',
                                        'header'
                                    ]
                                },
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; margin-left:13px;'
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        id: 5,
        collapsible: true,
        heading: 'Reinsurance',
        useHeading: true,
        headingStyle: 'margin-left:20px; width:95%;',
        subSections: [
            {
                id: 0,
                columns: 2,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: 'Reinsurer',
                                fieldName: 'reinsurerName',
                                fieldType: 'Text',
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none; margin-left:15px;',
                                isEditable: false
                            },
                            {
                                label: 'Reinsurance %',
                                fieldName: 'reinsurerPercentageRate',
                                fieldType: 'Percentage',
                                style: 'margin-top: -20px;',
                                formElementStyle: 'border-bottom:none;',
                                isEditable: false,
                                fieldTypeAttributes: {
                                    formatter: 'percent',
                                    step: '0.01'
                                }
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        id: 6,
        collapsible: true,
        heading: 'Summary Notes',
        useHeading: true,
        headingStyle: 'margin-left:20px; width:95%;',
        subSections: [
            {
                id: 0,
                columns: 1,
                isDeletable: false,
                rows: [
                    {
                        fields: [
                            {
                                label: '',
                                fieldName: 'summaryNotes',
                                fieldType: 'RichTextArea',
                                style: 'margin-top: -15px; width:99%;',
                                fieldTypeAttributes: {
                                    formats: [
                                        'font',
                                        'size',
                                        'bold',
                                        'italic',
                                        'underline',
                                        'list',
                                        'indent',
                                        'align',
                                        'link',
                                        'clean',
                                        'table',
                                        'header'
                                    ]
                                },
                                isEditable: true,
                                formElementStyle: 'border-bottom:none; margin-left:13px;',
                            }
                        ]
                    }
                ]
            }
        ]
    }
]