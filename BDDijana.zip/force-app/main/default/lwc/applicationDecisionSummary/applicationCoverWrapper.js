import ApplicationCover__c from '@salesforce/schema/ApplicationCover__c';

import CoverPremium__c          from '@salesforce/schema/ApplicationCover__c.CoverPremium__c';
import Type__c                  from '@salesforce/schema/ApplicationCover__c.Type__c';
import CoverAmount__c           from '@salesforce/schema/ApplicationCover__c.CoverAmount__c';
import CoverMonthlyBenefit__c   from '@salesforce/schema/ApplicationCover__c.CoverMonthlyBenefit__c';
import CoverTerm__c             from '@salesforce/schema/ApplicationCover__c.CoverTerm__c';
// import CoverUntilAge__c         from '@salesforce/schema/ApplicationCover__c.CoverUntilAge__c';
import Deferred_Period__c       from '@salesforce/schema/ApplicationCover__c.Deferred_Period__c';
import Status__c                from '@salesforce/schema/ApplicationCover__c.Status__c';
import UWAmount__c              from '@salesforce/schema/ApplicationCover__c.UWAmount__c';
import UWTerm__c                from '@salesforce/schema/ApplicationCover__c.UWTerm__c';

/**
 * @description A wrapper around the `ApplicationCover__c` Object
 *
 * (Potentially) Contains all fields from the `ApplicationCover__c` object as
 * well as a few others
 *
 * @property {string} typeLabel The Label for the value of the `Type__c`
 * picklist value on `ApplicationCover__c`
 * @property {string} recordLink The URL to the `ApplicationCover__c` record
 *
 * @property {{ [fieldApiName: string]: { [picklistValue]: picklistLabel } }} ApplicationCover.picklistLabels
 * The picklist labels required. Set a particular field using the
 * `ApplicationCover.setPicklistLabels` static function.
 * @property {string} ApplicationCover.objectApiName The API name for the
 * `ApplicationCover__c` object.
 */
export class ApplicationCover {
    static picklistLabels = { };
    static objectApiName  = ApplicationCover__c.objectApiName;

    constructor(coverData) {
        Object.assign(this, coverData);
    }

    get recordLink() { return `/lightning/r/${ApplicationCover.objectApiName}/${this.Id}/view`; }

    get typeLabel() {
        const fieldApiName = Type__c.fieldApiName;
        const labels       = ApplicationCover.picklistLabels[fieldApiName];

        const coverType = this[fieldApiName];
        return labels && labels[coverType];
    }

	 get DPLabel() {
			const fieldApiName = Deferred_Period__c.fieldApiName;
			const labels       = ApplicationCover.picklistLabels[fieldApiName];

			const coverDP = this[fieldApiName];
			return labels && labels[coverDP];
	}
    get productName() { return this.Product__r && this.Product__r.Name; }

    /**
     * @description Set the picklist values for `fieldApiName` to the values
     * stored in the `picklistValues`
     * @param {string} fieldApiName The API name of the field which the values
     * in `picklistValues` apply to
     * @param {{ value: string, label: string }[]} picklistValues
     */
    static setPicklistLabels(fieldApiName, picklistValues) {
        const picklistLabels = { };
        for(const entry of picklistValues) {
            picklistLabels[entry.value] = entry.label;
        }
        ApplicationCover.picklistLabels[fieldApiName] = picklistLabels;
    }

    /**
     * @description Build the columns for the table
     * @param {ObjectInfo} objectInfo The `ObjectInfo` (e.g. from
     * `getObjectInfo`) for the `ApplicationCover__c` object.
     * @return {ColumnInfo[]} The Column infos for the Covers part of the
     * decision summary table
     */
    static buildColumns(objectInfo) {
        return [
            {
                label: objectInfo.label,
                fieldName: 'recordLink',
                type: 'url',
                typeAttributes: {
                    label: {
                        fieldName: 'productName'
                    },
                    tooltip: {
                        fieldName: 'productName'
                    }
                },
            },
            {
                label: objectInfo.fields[Status__c.fieldApiName].label,
                fieldName: Status__c.fieldApiName,
                type: 'text'
            },
            {
                label: objectInfo.fields[CoverPremium__c.fieldApiName].label,
                fieldName: CoverPremium__c.fieldApiName,
                type: 'currency'
            },
            {
                label: objectInfo.fields[Type__c.fieldApiName].label,
                fieldName: 'typeLabel',
                type: 'text'
            },
            {
                label: objectInfo.fields[CoverAmount__c.fieldApiName].label,
                fieldName: CoverAmount__c.fieldApiName,
                type: 'currency'
            },
            {
                label: objectInfo.fields[CoverMonthlyBenefit__c.fieldApiName].label,
                fieldName: CoverMonthlyBenefit__c.fieldApiName,
                type: 'currency'
            },
            {
                label: objectInfo.fields[CoverTerm__c.fieldApiName].label,
                fieldName: CoverTerm__c.fieldApiName,
                type: 'text'
            },
            // {
            //     label: objectInfo.fields[CoverUntilAge__c.fieldApiName].label,
            //     fieldName: CoverUntilAge__c.fieldApiName,
            //     type: 'number'
            // },
				{
					label: objectInfo.fields[Deferred_Period__c.fieldApiName].label,
					fieldName: 'DPLabel',
					type: 'text'
			   },
            {
                label: objectInfo.fields[UWAmount__c.fieldApiName].label,
                fieldName: UWAmount__c.fieldApiName,
                type: 'currency'
            },
            {
                label: objectInfo.fields[UWTerm__c.fieldApiName].label,
                fieldName: UWTerm__c.fieldApiName,
                type: 'number'
            },
        ]
    }
}