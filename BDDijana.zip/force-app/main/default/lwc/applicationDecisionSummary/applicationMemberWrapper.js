import { getRecordNotifyChange } from 'lightning/uiRecordApi';

import ApplicationMember__c from '@salesforce/schema/ApplicationMember__c';

import fetchCovers               from '@salesforce/apex/ApplicationDecisionSummary_Ctrl.fetchCovers';
import fetchUnderwritingOutcomes from '@salesforce/apex/ApplicationDecisionSummary_Ctrl.fetchUnderwritingOutcomes';
import fetchValidateStatus       from '@salesforce/apex/ApplicationDecisionSummary_Ctrl.fetchValidateStatus';
import makeDecision              from '@salesforce/apex/ApplicationDecisionSummary_Ctrl.makeDecision';

import TITLE_CONFIRM   from '@salesforce/label/c.AppDecisionSummary_Title_Confirm';
import TITLE_ERROR     from '@salesforce/label/c.AppDecisionSummary_Title_Error';
import TITLE_VALIDATES from '@salesforce/label/c.AppDecisionSummary_Title_Validates';

import { ApplicationCover }    from './applicationCoverWrapper';
import { UnderwritingOutcome } from './underwritingOutcomeWrapper';


import { getErrorMessage } from 'c/utility';

/**
 * @description A wrapper around the `UnderwritingOutcome__c` Object
 *
 * Mostly just used as a container for wrappers around the
 * `UnderwritingOutcome__c` and `ApplicationCover__c` objects.
 *
 * @property {ApplicationDecisionSummary} cmp The underlying component, used to
 * re-render the tables when we have received the ata.
 * @property {ApplicationMember__c} data The raw fields from the
 * `ApplicationMember__c` we are wrapping.
 * @property {Promise<void>} coversPromise Used to store the fact that we have
 * already queried the server for covers.
 * @property {Promise<void>} uwOutcomesPromise Used to store the fact that we
 * have already queried the server for underwriting outcomes.
 * @property {ApplicationCover[]} cachedCovers The cached `ApplicationCover`
 * wrappers which are associated with this `ApplicationMember`
 * @property {ApplicationCover[]} cachedUwOutcomes The cached
 * `UnderwritingOutcome` wrappers which are associated with this
 * `ApplicationMember`
 * @property {ApplicationCover[]} covers Will either return the cached
 * `ApplicationCover` wrappers or will fire off a request to fetch them
 * @property {ApplicationCover[]} uwOutcomes Will either return the cached
 * `UnderwritingOutcome` wrappers or will fire off a request to fetch them
 * @property {boolean} isLoading Whether or not to show a loading spinner
 * @property {string} applicantName The name of the Person who has applied.
 */
export class ApplicationMember {
    static objectApiName = ApplicationMember__c.objectApiName;

    cmp;
    data;

    covers     = [ ];
    uwOutcomes = [ ];

    decisionModal = {
        id:               -1,
        show:             false,
        loading:          null,
        validationErrors: { },
        applying:         false,
    };
    nextModalId = 0;

    constructor(cmp, memberData) {
        this.cmp  = cmp;
        this.data = memberData;
    }
    async init() {

        const coversPromise = fetchCovers({ memberId: this.data.Id });
        const uwoPromise    = fetchUnderwritingOutcomes({ memberId: this.data.Id });
       
		  const [covers, uwos] = await Promise.all([coversPromise, uwoPromise]);
		  
		  this.covers     = covers.map(data => new ApplicationCover(data));
		  this.uwOutcomes = uwos.map(data => new UnderwritingOutcome(data));
    }

    static async create(cmp, memberData) {
      const member = new ApplicationMember(cmp, memberData);
		await member.init();
			
        return member;
    }

    get id()            { return this.data.Id; }
    get applicantName() { return this.data.Account__r && this.data.Account__r.Name || this.data.Name; }
    get caseId()        { return this.data.Cases__r && this.data.Cases__r[0] && this.data.Cases__r[0].Id; }

    get showApplyDecision() {
        return this.caseId && this.caseId === this.cmp.recordId &&
            this.data.Cases__r[0].CanMakeDecision__c &&
            this.cmp.editorMode === 'view';
    }
    get showGoToCase()           { return this.caseId && this.caseId !== this.cmp.recordId; }
    get hasAnyErrors()           { return !!this.decisionModal.error || this.hasValidationErrors; }
    get hasValidationErrors()    { return 0 !== Object.keys(this.decisionModal.validationErrors).length; }
    get disableConfirmDecision() { return this.hasAnyErrors; }

    get validationErrorText() {
        return Object.entries(this.decisionModal.validationErrors)
            .map(([key, values]) => key + ':\n' + values.join('\n'))
            .join('\n\n');
    }
    get modalTitle() {
        if(this.decisionModal.error) {
            return TITLE_ERROR;
        } else if(this.hasValidationErrors) {
            return TITLE_VALIDATES;
        } else {
            return TITLE_CONFIRM;
        }
    }

    async applyDecision() {
        const modalId = this.nextModalId++;
        this.decisionModal = {
            id:                modalId,
            show:              true,
            loading:           'Checking validates',
            validationErrors:  { },
            appying:           false,
        };
        const validationErrors = await fetchValidateStatus({ caseId: this.caseId });

        if(this.decisionModal.id === modalId) {
            this.decisionModal.validationErrors = validationErrors;
            this.decisionModal.loading          = null;
        }
    }
    async confirmApplyDecision() {
        if(!this.decisionModal.applying) {
            this.decisionModal.loading  = 'Applying decision';
            this.decisionModal.applying = true;
            try {
                await makeDecision({ caseId: this.caseId });
                this.decisionModal.show = false;
                // Tell the system that the case is dirty and needs to be refreshed
                // so that the Decision Made change is applied to the record we are
                // currently looking it
                getRecordNotifyChange([{ recordId: this.caseId }]);
                return true;
            } catch(err) {
                console.error(err);
                this.decisionModal.error    = getErrorMessage(err);
                this.decisionModal.loading  = null;
                this.decisionModal.applying = false;
                return false;
            }
        }
    }
    cancelDecision() {
        if(!this.decisionModal.applying) {
            this.decisionModal.show = false;
        }
    }
}