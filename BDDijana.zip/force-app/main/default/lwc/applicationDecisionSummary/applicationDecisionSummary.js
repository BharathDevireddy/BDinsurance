import { api, LightningElement, track, wire }     from 'lwc';
import { getObjectInfos, getPicklistValues }      from 'lightning/uiObjectInfoApi';
import { NavigationMixin }                        from 'lightning/navigation';
import { subscribe, unsubscribe, MessageContext } from 'lightning/messageService';

import CaseUnderwritingEditorState__c from '@salesforce/messageChannel/CaseUnderwritingEditorState__c';

import Case           from '@salesforce/schema/Case';
import Application__c from '@salesforce/schema/Application__c';

//picklist fields to handle labels
import ApplicationCover_Type__c            from '@salesforce/schema/ApplicationCover__c.Type__c';
import ApplicationCover_Deferred_Period__c from '@salesforce/schema/ApplicationCover__c.Deferred_Period__c';
import UnderwritingOutcome_Cover__c        from '@salesforce/schema/UnderwritingOutcome__c.Cover__c';

import UnderwritingOutcome_UREExclusions__c 	from '@salesforce/schema/UnderwritingOutcome__c.UREExclusions__c';
import UnderwritingOutcome_URERemovals__c 	from '@salesforce/schema/UnderwritingOutcome__c.URERemovals__c';
import UnderwritingOutcome_UWExclusions__c 	from '@salesforce/schema/UnderwritingOutcome__c.UWExclusions__c';
import UnderwritingOutcome_UWRemovals__c 		from '@salesforce/schema/UnderwritingOutcome__c.UWRemovals__c';


import OPEN_CASE        from '@salesforce/label/c.AppDecisionSummary_OpenCase';
import MAKE_DECISION    from '@salesforce/label/c.AppDecisionSummary_MakeDecision';
import CONFIRM_DECISION from '@salesforce/label/c.AppDecisionSummary_ConfirmMakeDecision';

import { GetObjectInfosConverter, WireConverter, getErrorMessage, getIconNameFromUrl } from 'c/utility';

import { ApplicationCover }    from './applicationCoverWrapper';
import { ApplicationMember }   from './applicationMemberWrapper';
import { UnderwritingOutcome } from './underwritingOutcomeWrapper';

import fetchApplicationMembers     from '@salesforce/apex/ApplicationDecisionSummary_Ctrl.fetchApplicationMembers';
import fetchCaseApplicationMembers from '@salesforce/apex/ApplicationDecisionSummary_Ctrl.fetchCaseApplicationMembers';


const OBJECT_PICKLISTS = [
    {
        objType:      ApplicationCover,
        fieldApiName: ApplicationCover_Type__c.fieldApiName,
    },
	 {
			objType:      ApplicationCover,
			fieldApiName: ApplicationCover_Deferred_Period__c.fieldApiName,
  	 },
    {
        objType:      UnderwritingOutcome,
        fieldApiName: UnderwritingOutcome_Cover__c.fieldApiName,
    },
	 {
		objType:      UnderwritingOutcome,
		fieldApiName: UnderwritingOutcome_UREExclusions__c.fieldApiName,
	 },
	 {
		objType:      UnderwritingOutcome,
		fieldApiName: UnderwritingOutcome_URERemovals__c.fieldApiName,
	 },
	 {
		objType:      UnderwritingOutcome,
		fieldApiName: UnderwritingOutcome_UWExclusions__c.fieldApiName,
	 },
	 {
		objType:      UnderwritingOutcome,
		fieldApiName: UnderwritingOutcome_UWRemovals__c.fieldApiName,
  	 },
];

/**
 * @return {{ [objectApiName: string]: { [fieldApiName: string]: WireConverter } }}
 * The `WireConverter` objects for any required picklist labels as defined in
 * `OBJECT_PICKLISTS`
 */
function picklistWireConverters() {
    const output = { };
    for(const reqPicklist of OBJECT_PICKLISTS) {
        let obj = output[reqPicklist.objType.objectApiName];
        if(!obj) {
            obj = { };
            output[reqPicklist.objType.objectApiName] = obj;
        }
        obj[reqPicklist.fieldApiName] = new WireConverter();
    }
    return output;
}

/**
 * @description A class containing the information from the `ObjectInfo` for a
 * particular SObjectType that we care about for building our tables
 *
 * @param {string} icon The icon for the object to be used in, e.g.
 * `lightning-icon`
 * @param {string} defaultRtId The default RecordType id for this sObject and
 * User
 * @param {ColumnInfo[]} columns The list of columns to be displayed in the
 * table for this object type
 * @param {string} label The Label for this SObject
 * @param {string} labelPlutal the Plural Label for this SObject
 */
class ObjectDetails {
    static ALL_OBJECT_TYPES = [
        ApplicationCover,
        UnderwritingOutcome,
    ];
    static get OBJECT_API_NAMES() {
        return ObjectDetails.ALL_OBJECT_TYPES.map(wrapperClass => wrapperClass.objectApiName);
    }

    constructor(objClass, objectInfo) {
        this.icon           = getIconNameFromUrl(objectInfo.themeInfo.iconUrl);
        this.defaultRtId    = objectInfo.defaultRecordTypeId;
        this.columns        = objClass.buildColumns(objectInfo);
        this.label          = objectInfo.label;
        this.labelPlural    = objectInfo.labelPlural;
    }

    /**
     * @description Build a list of `ObjectDetails` classes from the global
     * `ALL_OBJECT_TYPES` and a list of objectInfos from a
     * {@link GetObjectInfosConverter}.
     *
     * @param {{ [objectApiName: string]: ObjectInfo}} objectInfos a map of
     * `ObjectInfo` objects as received from a {@link GetObjectInfosConverter}
     *
     * @return {{ [objectApiName: string]: ObjectDetails }} The `ObjectDetails`
     * objects built from the corresponding `objectInfos`
     */
    static buildAll(objectInfos) {
        const output = { };
        for(const objType of ObjectDetails.ALL_OBJECT_TYPES) {
            const info = objectInfos[objType.objectApiName];
            output[objType.objectApiName] = info && new ObjectDetails(objType, info);
        }
        return output;
    }
}

/**
 * @description The controller for the component
 *
 * @property {string} recordId The recordId that the component is currently
 * displayed on
 * Should be either an `ApplicationMember__c` or a `Case` Id
 * @property {string} objectApiName The api name of the sObjectType which
 * `recordId` refers to
 * @property {ApplicationMember[]} appMembers A list of ApplicationMember
 * wrapper objects, effectively representing the data for each of the tabs on
 * the component
 * @property {string[]} errors A list of errors to show on the page, in the
 * event that something goes wrong
 * @property {{ recordId: string, objectApiName: string }[]) refreshIds A list
 * of records where, if the record changes, we will want to update the component
 * with the updated data.
 * @property {boolean} refreshing Is the component refreshing its data? This is
 * used to determine whether or not to show the loading spinner.
 *
 * @property {{ [objectApiName: string]: ObjectDetails }} objectDetails The
 * details about the objects which are required for building their respective
 * tables
 * @property {{ [objectApiName: string]: { [fieldApiName: string]: WireConverter } }} picklistValueHandlers
 * The `WireConverter` objects for any required picklist labels we are going to
 * need to show properly within the table
 * @property {GetObjectInfosConverter} objectInfosAwaiter The `WireConverter`
 * for fetching from `getObjectInfos`
 */
export default class AppDecisionSummary extends NavigationMixin(LightningElement) {
    @api recordId;
    @api objectApiName;

    @track appMembers = [ ];
    @track editorMode = 'view';
    @track errors     = [ ];
    @track refreshing = false;

    objectDetails         = ObjectDetails.buildAll({ });
    picklistValueHandlers = picklistWireConverters();
    objectInfosAwaiter    = new GetObjectInfosConverter();
    editorSubscription    = null;

    @wire(getObjectInfos, { objectApiNames: ObjectDetails.OBJECT_API_NAMES })
    handleObjectInfos(result) {
        this.objectInfosAwaiter.handleResult(result);
    }
	 //picklist relabels
	 //UWOCs
    @wire(getPicklistValues, { recordTypeId: '$objectDetails.UnderwritingOutcome__c.defaultRtId', fieldApiName: UnderwritingOutcome_Cover__c })
    handleUwOutcomeCoverPicklistValues(result) {
        this.picklistValueHandlers.UnderwritingOutcome__c.Cover__c.handleResult(result);
    }
	 @wire(getPicklistValues, { recordTypeId: '$objectDetails.UnderwritingOutcome__c.defaultRtId', fieldApiName: UnderwritingOutcome_UREExclusions__c })
	 handleUWOutcomeUREExclusionsPicklistValues(result) {
		  this.picklistValueHandlers.UnderwritingOutcome__c.UREExclusions__c.handleResult(result);
	 }
	 @wire(getPicklistValues, { recordTypeId: '$objectDetails.UnderwritingOutcome__c.defaultRtId', fieldApiName: UnderwritingOutcome_URERemovals__c })
    handleUWOutcomeURERemovalsPicklistValues(result) {
        this.picklistValueHandlers.UnderwritingOutcome__c.URERemovals__c.handleResult(result);
    }
	 @wire(getPicklistValues, { recordTypeId: '$objectDetails.UnderwritingOutcome__c.defaultRtId', fieldApiName: UnderwritingOutcome_UWExclusions__c })
	 handleUwOutcomeUWExclusionsPicklistValues(result) {
		  this.picklistValueHandlers.UnderwritingOutcome__c.UWExclusions__c.handleResult(result);
	 }
	 @wire(getPicklistValues, { recordTypeId: '$objectDetails.UnderwritingOutcome__c.defaultRtId', fieldApiName: UnderwritingOutcome_UWRemovals__c })
    handleUwOutcomeUWRemovalsPicklistValues(result) {
        this.picklistValueHandlers.UnderwritingOutcome__c.UWRemovals__c.handleResult(result);
    }
	 //App covers
    @wire(getPicklistValues, { recordTypeId: '$objectDetails.ApplicationCover__c.defaultRtId', fieldApiName: ApplicationCover_Type__c })
    handleApplicationTypePicklistValues(result) {
        this.picklistValueHandlers.ApplicationCover__c.Type__c.handleResult(result);
    }
	 @wire(getPicklistValues, { recordTypeId: '$objectDetails.ApplicationCover__c.defaultRtId', fieldApiName: ApplicationCover_Deferred_Period__c })
    handleDeferredPeriodPicklistValues(result) {
        this.picklistValueHandlers.ApplicationCover__c.Deferred_Period__c.handleResult(result);
    }
    @wire(MessageContext)
    messageContext;

    get openCaseText()        { return OPEN_CASE; }
    get makeDecisionText()    { return MAKE_DECISION; }
    get confirmDecisionText() { return CONFIRM_DECISION; }

    get hasErrors()  { return this.errors.length > 0; }
    get errorsText() { return this.errors.join('\n\n'); }
    get showCovers() { return this.objectApiName === Case.objectApiName; }

    get refreshIds() {
        // TODO is this a little opaque?
        return [
            {
                recordId:      this.recordId,
                objectApiName: this.objectApiName,
            },
            ...this.appMembers.map(member => [
                {
                    recordId:      member.data.Id,
                    objectApiName: ApplicationMember.objectApiName,
                },
                ...member.covers.map(record => ({
                    recordId:      record.Id,
                    objectApiName: ApplicationCover.objectApiName,
                })),
                ...member.uwOutcomes.map(record => ({
                    recordId:      record.Id,
                    objectApiName: UnderwritingOutcome.objectApiName,
                })),
                ...(member.caseId ? [ {
                    recordId:      member.caseId,
                    objectApiName: Case.objectApiName
                } ] : [ ]),
            ]).flat(1)
        ];
    }


   async connectedCallback() {
		this.editorSubscription = subscribe(this.messageContext, CaseUnderwritingEditorState__c, message => {
			if(this.recordId === message.recordId) {
					this.editorMode = message.state;
			}
		});
		try{
			await this.refreshData();
		} catch(err) {
			console.log(err);
			this.addError(err);
		}
   }
    async disconnectedCallback() {
        unsubscribe(this.editorSubscritpion);
    }

    async refreshData() {
        try {
				console.log("refresh data");
            if(this.refreshing) return;
            this.refreshing = true;

            // Start fetching the data, we'll wait until we've finished fetching the
            // object info before finally setting it on the component and triggering
            // a rerender
            let apexFetchMembersPromise;
            if(Application__c.objectApiName === this.objectApiName) {
                apexFetchMembersPromise = fetchApplicationMembers({ applicationId: this.recordId })
            } else if(Case.objectApiName === this.objectApiName) {
                apexFetchMembersPromise = fetchCaseApplicationMembers({ caseId: this.recordId })
            }
            const membersPromise = apexFetchMembersPromise;
				// .then(members => Promise.all(members.map(async data => ApplicationMember.create(this, data)))).catch(err=> console.log(err));
				// the above promise chain no longer works, throws an uncaught (despite the catches) promise error...
				//... seems to be due to new release which broke something at the SF end, reworked as explicit awaiting loop to populate
                

            // Fetch the object details, this is used for field/object labels, the
            // icons, etc
            const objectInfos  = await this.objectInfosAwaiter.fetch();
            this.objectDetails = ObjectDetails.buildAll(objectInfos);

            // Fetch the picklist labels for the fields we care about so that we
            // show the labels rather than the API names
            await Promise.all(OBJECT_PICKLISTS.map(async reqPicklist => {
                const objectApiName = reqPicklist.objType.objectApiName;
                const fieldApiName  = reqPicklist.fieldApiName;

                reqPicklist.objType.setPicklistLabels(
                    fieldApiName,
                    (await this.picklistValueHandlers[objectApiName][fieldApiName].fetch()).values
                )
            }));
				
				const membersPromiseResultdata = await membersPromise;
				//clear list as multiple async calls on Application page initial load can cause dupe entries to be added
				this.appMembers = [];
				for(let i = 0; i < membersPromiseResultdata.length; i++){
					this.appMembers.push(await ApplicationMember.create(this, membersPromiseResultdata[i]));
				}

        } catch(err) {
			console.log(err);
         this.addError(err);
        }
        this.refreshing = false;
    }

    addError(err) {
        console.error(err);
        this.errors = [...this.errors, getErrorMessage(err)];
    }

    navigateToSObject(recordId) {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: recordId,
                actionName: 'view'
            }
        });
    }

    goToCase(e) {
        const caseId = e.target.dataset.caseId;
        this.navigateToSObject(caseId);
    }
    async applyDecision(e) {
        const memberId = e.target.dataset.id;
        let promise = null;
        this.appMembers = this.appMembers.map(m => {
            if(m.id === memberId) promise = m.applyDecision();
            return m;
        });
        if(promise) {
            // Trigger a manual rerender when the promise successfully resolves
            await promise;
            this.appMembers = [...this.appMembers];
        }
    }
    async confirmApplyDecision(e) {
        const memberId = e.target.dataset.id;
        let promise = null;
        this.appMembers = this.appMembers.map(m => {
            if(m.id === memberId) promise = m.confirmApplyDecision();
            return m;
        });
        if(promise) {
            // If it failed, trigger a manual rerender, it should re-render
            // anyway if it's successful because we should be tracking that the
            // Case has been updated
            if(!(await promise)) this.appMembers = [...this.appMembers];
        }
    }
    cancelDecision(e) {
        const memberId = e.target.dataset.id;
        this.appMembers = this.appMembers.map(m => {
            if(m.id === memberId) m.cancelDecision();
            return m;
        });
    }
}