import { api, LightningElement } from 'lwc';

export default class ModalPanel extends LightningElement {
    @api headless = false;
    @api footless = false;
}