({
    cancelRequest: function(component, event, helper){
        window.location.href = '/' + component.get("v.recordId");
    },
    handleBlur: function (component, event) {
        var validity = component.find("emailfield").get("v.validity");
        var val = component.find("emailfield").get("v.value");

        if(!$A.util.isEmpty(val)){
            console.log(validity.valid+'validity>>'); //returns true
            if(validity.valid){
                component.set("v.isButtonActive", true);
                console.log('button >> '+component.get("v.isButtonActive"));
            }
            else{
               component.set("v.isButtonActive", false);
        	}
        }
        else{
            component.set("v.isButtonActive", false);
        }
    },
    doInit : function(component, event, helper) {
        console.log('in js now>>');
        var action = component.get("c.getEmailaddress");
        console.log('in js1 now>>');
        action.setParams({
            "recordId": component.get("v.recordId"),
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state>>>'+state);
            if (state === "SUCCESS") {
                console.log('in success now>>' , response.getReturnValue());
                component.set("v.oldEmailAddr", response.getReturnValue());
                console.log('Hello1'+component.get("v.oldEmailAddr"));
            }
         });
         $A.enqueueAction(action);
    },
    handleSubmission : function(component, event, helper) {
        console.log('button1  > ' , component.get("v.isUserIdButtonClicked"));
        component.set("v.isUserIdButtonClicked", false);
        console.log('button 2 > ' ,component.get("v.isUserIdButtonClicked") );

        var action = component.get("c.sendDataToProcess");
        action.setParams({
            "Idrec": component.get("v.recordId"),
            "newEmailAddr": component.get("v.newEmailAddr")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('state >> ', state);
            if (state === "ERROR") {
                var errors = action.getError();
                console.log('errors >> ', errors);
                console.log('errors 1>> ', errors[0].message.includes("Custom"));
                if (errors) {
                    //alert and window.location to be used in case of VF.
                    var errorMsg = $A.get("$Label.c.Error_message ");
                    alert(errorMsg);
                    window.location.href = '/' + component.get("v.recordId");
                }
            }
            if (state === "SUCCESS") {
                var resp = response.getReturnValue();
                console.log('resp > ' , resp);
                if(resp.result == 'Failure'){
                    var errorMessage = resp.message;
                    console.log('errorMessage > ', errorMessage);
                    component.set('v.isError',true);
                    component.set('v.message',errorMessage);
                    component.set('v.isSuccess',false);
                }else{
                    component.set('v.isError',false);
                    component.set('v.isSuccess',true);
                }
            }
        });
        $A.enqueueAction(action);
    }
})