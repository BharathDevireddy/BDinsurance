({
    cancelRequest: function(component, event, helper){
        component.set("v.isModalOpen", false);
        window.location.href = '/' + component.get("v.recordId");
    },
    handleSubmission : function(component, event, helper) {
        var action = component.get("c.sendDataToProcess");
        console.log('test >> '+component.get("v.sobjecttype"));
        action.setParams({
            "Idrec": component.get("v.recordId"),
            "SobjectName": component.get("v.sobjecttype")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('state >> ', state);
            if (state === "ERROR") {
                var errors = action.getError();
                console.log('errors >> ', errors);
                console.log('errors 1>> ', errors[0].message.includes("Custom"));
                if (errors) {
                    if (errors[0] && errors[0].message.includes("Custom")) {
                        alert(errors[0].message);
                    }
                    if(errors[0] && !errors[0].message.includes("Custom")){
                        //alert and window.location to be used in case of VF.
                        var errorMsg = $A.get("$Label.c.Error_message ");
                        alert(errorMsg);
                    }
                    window.location.href = '/' + component.get("v.recordId");
                }
            }
            if (state === "SUCCESS") {
                component.set("v.isModalOpen", true);
            }
        });
        $A.enqueueAction(action);
    }
})