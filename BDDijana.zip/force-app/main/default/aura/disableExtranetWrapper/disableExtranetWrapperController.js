({
    onInit: function(component) {
        var pageRef = component.get('v.pageReference');

        component.set('v.recordId', pageRef.state.c__recordId);
        component.set('v.type', pageRef.state.c__type);

        var inner = component.find("inner");

        // Clear any existing state on the component if it already has some
        // internal state stored.
        //
        // Salesforce will try to reuse the component where possible, which
        // means if someone is half-way through and decides to navigate to a
        // different record, and start on that one instead, some of that state
        // may be retained for the new record even though it's a completely
        // different record.
        inner.clearState();
    }
})