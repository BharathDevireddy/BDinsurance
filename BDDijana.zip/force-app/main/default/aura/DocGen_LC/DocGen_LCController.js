({
    openModel: function(component, event, helper) {
        console.log('test >< ' , component.get("v.selDocList"));
        console.log('<><>'+component.get("v.date"));
        var selectedDocs = component.get("v.selDocList");
        var manuallyAmendedDocs = component.get("v.manuallyAmendedDocs");
        //Clear the modal
        component.set('v.isModalOpen', false);
        //Check to see if we need to display any alerts
        if(component.get("v.date") == null && selectedDocs.includes('Post-sales Documents~Cover increase letter')){
            alert('Please Enter the Date : Cover Anniversary Date');
        } else if(selectedDocs.includes("Post-sales Documents~Cover summary") && manuallyAmendedDocs.includes("Cover Summary")) {
            alert('You cannot request the cover summary to be regenerated because it has been manually amended. Please raise an IT ticket.');
        } else if(selectedDocs.includes("Post-sales Documents~Direct debit confirmation") && manuallyAmendedDocs.includes("Direct Debit Confirmation")) {
            alert('You cannot request the direct debit confirmation to be regenerated because it has been manually amended. Please raise an IT ticket.');
        } else {
            //No more validation! Open the modal
            component.set("v.isModalOpen", true);
        }

        //Open the modal if it's set to true
        if(component.get("v.isModalOpen")){

            console.log('selectedDocs>>'+selectedDocs);
            var tempPreFinal = new Array();
            var tempPostFinal = new Array();
            var tempPreList = selectedDocs.filter(function(num) {
                return num.includes("Pre") ;
            });
            console.log('tempPreList>>'+tempPreList);
            for(var s in tempPreList)
            {
                tempPreFinal.push(tempPreList[s].replace("Pre-sales Documents~",""));
            }
            component.set('v.selPreList',tempPreFinal);

            var tempPostList = selectedDocs.filter(function(num1) {
                return num1.includes("Post");
            });
            console.log('tempPostList>>'+tempPostList);
            let tempdate = new Date(component.get("v.date"));
            let formatted_date = tempdate.getDate() + "-" + (tempdate.getMonth() + 1) + "-" + tempdate.getFullYear();
            console.log('date >> format',formatted_date);
            var tempdate1 = " " + "(anniversary "+formatted_date + ")" ;
            console.log('tempdate1>>'+tempdate1);
            for(var s1 in tempPostList)
            {
                console.log('tempPostList1>>'+tempPostList[s1]);
                if(tempPostList[s1] == 'Post-sales Documents~Cover increase letter'){
                    var temp = tempPostList[s1].replace("Post-sales Documents~","");
                    var s5 = temp.concat(tempdate1);
                    console.log('temp>>'+s5);
                    tempPostFinal.push(s5);
                }
                else{
                    tempPostFinal.push(tempPostList[s1].replace("Post-sales Documents~",""));
                }
            }
            component.set('v.selPostList',tempPostFinal);
            component.set("v.isModalOpen", true);
        }

    },

    closeModel: function(component, event, helper){
        // Set isModalOpen attribute to false
        component.set("v.isModalOpen", false);
    },
    nullify : function(comp, ev, hel)
    {
        var dp = comp.find('AnniversaryDate');
        dp.set('v.value', '');
    },
    cancelRequest: function(component, event, helper){
        window.location.href = '/' + component.get("v.recordId");
    },

    dateChange: function(component, event, helper){
        var dateField = component.find("AnniversaryDate");
        console.log('dateField::::::::'+dateField);
        var date = dateField.get("v.value");
        console.log('date::::::::'+date);
        component.set("v.date", date);
        console.log('date::::::::'+date);
    },
    getDocumentGeneratorMapValues : function(component, event, helper) {
        var action = component.get("c.getDocumentDetails");
        action.setParams({
            "accId": component.get("v.recordId"),

        });
        action.setCallback(this, function(response){
            let res = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                var custs = [];
                var conts = response.getReturnValue();
                for ( var key in conts ) {
                    custs.push({value:conts[key], key:key});
                }
            }
            component.set("v.wrapperRecordMap", custs);
            console.log('here'+component.get("v.wrapperRecordMap"));
        });
        $A.enqueueAction(action);
    },
    getManuallyAmendedDocs : function(component, event, helper) {
        if(component.get("v.recordId")) {
            var action = component.get("c.fetchManuallyAmendedDocs");
            action.setParams({
                "accId": component.get("v.recordId")
            });
            console.log('##Item : Getting Docs : ' + component.get("v.recordId"));
            action.setCallback(this, function(response){
                let res = response.getReturnValue();
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.manuallyAmendedDocs", res);
                }
            });
            $A.enqueueAction(action);
        }
    },
    handleSubmission : function(component, event, helper) {
        var action = component.get("c.getSelDocsToProcess");
        console.log('selDocListfinal >> ', component.get("v.selDocList"));
        action.setParams({
            "selDocList": component.get("v.selDocList"),
            "AccId": component.get("v.recordId"),
            "coverLetterDate": component.get("v.date")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            console.log('state >> ', state);
            if (state === "ERROR") {
                //alert and window.location to be used in case of VF.
                alert('We were unable to generate the request.Please raise an IT ticket!');
                window.location.href = '/' + component.get("v.recordId");
            }
            if (state === "SUCCESS") {
                component.set("v.isModalOpen", false);
                window.location.href = '/' + component.get("v.recordId");
            }
        });
        $A.enqueueAction(action);

    },
    handleQuesClick : function(component, event, helper) {
        var indexVal = event.getSource().get("v.name");
        let selAns = event.getSource().get("v.name")+'~'+event.getSource().get("v.label");
        let selValue = event.getSource().get("v.checked");
        console.log('selAns>>>>>'+selAns+'~~~~'+selValue);
        var tempList = new Array();
        var tempList = component.get("v.selDocList");
        console.log('tempList>>',tempList);
        if(selValue){
            tempList.push(selAns);
            console.log('tempList push>>',tempList);
        }
        else{
            var index = tempList.indexOf(selAns);
            if (index > -1) {
                tempList.splice(index, 1);
            }
            console.log(' pop>>',selAns);
        }
        if(tempList.length > 0){
            component.set('v.isButtonActive',true);
        }
        else{
            component.set('v.isButtonActive',false);
        }
        console.log('seldoc1>>',component.get("v.selDocList"));
        component.set('v.selDocList',tempList);
        console.log('seldoc2>>',component.get("v.selDocList"));
   }
})