({
    handleChanged : function(component) {
        component.set("v.hasUnsavedChanges", true);
        var unsaved = component.find("unsaved");
        unsaved.setUnsavedChanges(true);
    },

    handleSave : function(component) {
        component.find("lwcPanel").handleSave();
    },

    handleDirtyFlagCleared : function(component) {
        var unsaved = component.find("unsaved");
        unsaved.setUnsavedChanges(false);
        component.set("v.hasUnsavedChanges", false);
    }
})