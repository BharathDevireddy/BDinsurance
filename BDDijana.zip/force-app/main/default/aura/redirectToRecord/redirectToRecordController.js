({
    invoke: function(component) {
        const id = component.get('v.recordId');
        const redirect = $A.get('e.force:navigateToSObject');
        redirect.setParam('recordId', id);
        redirect.fire();
    }
})