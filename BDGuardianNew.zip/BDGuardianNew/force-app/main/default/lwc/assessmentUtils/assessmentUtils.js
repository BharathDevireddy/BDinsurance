const CATEGORY_OPTIONS = [
    {label: 'Medical', value: 'Medical'},
    {label: 'Financial', value: 'Financial'},
    {label: 'Occupational', value: 'Occupational'},
    {label: 'Admin', value: 'Admin'},
    {label: 'Complaint/Appeal', value: 'Complaint_Appeal'},
    {label: 'General', value: 'General'},
    {label: 'Reinsurer', value: 'Reinsurer'},
    {label: 'BPS Score',value: 'BPS_Score'}
];

/* CLAIM-668 Dijana Bursac */
const BPS_SCORE_OPTIONS = [
    {label: 'Low', value: 'Low'},
    {label: 'Medium', value: 'Medium'},
    {label: 'High', value: 'High'}
]

export {CATEGORY_OPTIONS,BPS_SCORE_OPTIONS}