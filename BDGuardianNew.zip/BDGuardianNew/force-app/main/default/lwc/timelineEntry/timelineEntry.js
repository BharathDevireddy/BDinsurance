import {LightningElement, api} from 'lwc';
import Themes from "./themes";

export default class TimelineEntry extends LightningElement {

    ifBpsScoreEntryLevel ;
    @api content = {
        Category: 'Medical'
    };
    showEditModal = false;
    _isOpen = false;

    get category() {
        /* CLAIM-668 Dijana Bursac */
        if(this.content.Category === 'BPS_Score')
        {
            this.ifBpsScoreEntryLevel=true;
        }else{
            this.ifBpsScoreEntryLevel=false;
        }
        return this.content.Category;
    }

    get entryFinalClass() {
        return Themes.CLASS_ENTRY + ' ' + this.themeClass + ' ' + this.openStateClass;
    }

    get themeClass() {
        return Themes.CATEGORY_THEME_DEFINITIONS[this.category].themeClass;
    }

    get openStateClass() {
        return (this._isOpen ? ' ' + Themes.CLASS_EXPANDED : '');
    }

    get iconName() {
        return Themes.CATEGORY_THEME_DEFINITIONS[this.category].iconName;
    }

    onToggleShowContent() {
        this._isOpen = !this._isOpen;
    }

    onEditAssessment() {
        this.template.querySelector("[data-id='assessmentEditModal']").showModal();
    }

    onAssessmentSaved() {
        this.dispatchEvent(new CustomEvent('assessmentsaved'))
    }

}