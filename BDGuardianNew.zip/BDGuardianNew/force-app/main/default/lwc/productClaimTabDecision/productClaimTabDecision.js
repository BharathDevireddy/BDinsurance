//LWC Imports
import { api, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import ClaimsComponent from 'c/claimsComponent';
import { getInitialPayLoad, getProductData, getProductReadOnlyData, setProductData, getMisRepTypes, getMisRepCatTypes, getMisRepRetro, getCalculationTypes, getDecisionTypes, getDecisionSubTypes } from 'c/productClaimDataHandler';

//Message channel info
import ProductClaimDirty__c from '@salesforce/messageChannel/ProductClaimDirty__c';
import ProductClaimRefreshData__c from '@salesforce/messageChannel/ProductClaimRefreshData__c';
import { publish, MessageContext, subscribe, APPLICATION_SCOPE, unsubscribe} from 'lightning/messageService';

//Constants
import { LAYOUT_DATA } from './constantLayout.js';
import { BANK_LAYOUT_DATA } from './bankLayout.js';
import { BANK_LAYOUT_DATA_EDIT } from './bankLayoutEdit.js';
import BODY from './productClaimTabDecision.html';

//Salesforce Imports
import CASE_FIELD_POLICY_NUMBER from '@salesforce/schema/Case.Policy_Number__c';

import fetchBankDetails from '@salesforce/apex/ClaimsDataHandler_LEx.fetchBankDetails';
import submitForApproval from '@salesforce/apex/ClaimsDataHandler_LEx.submitForApproval';

export default class ProductClaimTabDecision extends ClaimsComponent {

    /*=========================================================
            Claims Component Vars
    =========================================================*/

    componentLabel = 'Decision';
    componentBody = BODY;

    /*=========================================================
           Vars
    =========================================================*/
    @api claimExternalId;
    @api recordId;

    @wire(MessageContext)
    messageContext;
    subscription = null;

    @track formData = {};
    @track tabData = {};
    @track decisionData = {};
    @track tabReadOnlyData = {};
    @track decisionSummaryData = []; 
    @track layoutData = {};
    @track calcTypes = {};
    @track decTypes = {};
    @track decSubTypes = {};
    @track misRepTypes = {};
    @track misRepCatTypes = {};
    @track misRepRetro = {};
    numberOfNewBanks = 0;
    bankData;
    
    /*=========================================================
           Setup
    =========================================================*/
    
    //get the Policy Claim Case
    @wire(getRecord, { recordId: '$recordId', fields: [CASE_FIELD_POLICY_NUMBER] })
    case

    get policyNumber() {
        return getFieldValue(this.case.data, CASE_FIELD_POLICY_NUMBER);
    }

    // renderedCallback() {
    //     fetchBankDetails({policyNumber : this.policyNumber})
    //         .then(result => {
    //             console.log(result);
    //         })
    //         .catch(error => {
    //             this.error = error;
    //         });
    // //     console.log(this.policyNumber);
    // //     // let bankResponse = this.ClaimsDataService.fetchBankDetail(this.policyNumber);
    // //     let bankResponse = await this.ClaimsDataService.fetchBankDetail(this.policyNumber);
    // //     console.log(JSON.stringify(bankResponse));
    // }

    connectedCallback() {
        getMisRepTypes().then(misRepTypes => {
            this.misRepTypes = misRepTypes;
            getMisRepCatTypes().then(misRepCatTypes => {
                this.misRepCatTypes = misRepCatTypes;
                getMisRepRetro().then(misRepRetro => {
                    this.misRepRetro = misRepRetro;
                    getCalculationTypes().then(calcTypes => {
                        this.calcTypes = calcTypes;
                        getDecisionTypes().then(decisionTypes => {
                            this.decTypes = decisionTypes;
                            getInitialPayLoad(this.claimExternalId).then(result => {
                                this.tabData = JSON.parse(result.productDataUpdate);  
                                this.tabReadOnlyData = JSON.parse(result.productDataReadOnly);
                                console.log('policy number');
                                fetchBankDetails({policyNumber : this.policyNumber})
                                    .then(result => {
                                        this.bankData = result;
                                        this.loadTheContent(true);
                                    })
                                    .catch(error => {
                                        this.error = error;
                                    });
                                if(this.tabData.productClaimDecision.decisionDraft.decisionTypeID != null) {
                                    getDecisionSubTypes(this.tabData.productClaimDecision.decisionDraft.decisionTypeID.toString()).then(decisionSubTypes => {
                                        this.decSubTypes = decisionSubTypes;
                                        this.State.show();
                                        this.subscribeToMessageChannel(); // subscribing to the "save/ancel" event message channel
                                        this.loadTheContent(false); // this is for loading the decision data in the fields, initial load
                                    });
                                }
                                else {
                                    this.State.show();
                                    this.subscribeToMessageChannel(); // subscribing to the "save/ancel" event message channel
                                    this.loadTheContent(false); // this is for loading the decision data in the fields, initial load
                                }
                            });
                        });
                    });
                });
            });
        });
    }
    
    // when a field is updated we're updating the pointer & opening the global "save - cancel" popup
    handleDecisionDataChange(e) {
        if(e.detail[1] == 'misrepresentationTypeID') {
            this.decisionData.misrepresentationTypeID = this.formData.misrepresentationTypeID = this.tabData.productClaimDecision.decisionDraft.misrepresentationTypeID = parseInt(e.detail[0]);
        }
        else  if(e.detail[1] == 'misrepresentationCategoryID') {
            this.decisionData.misrepresentationCategoryID = this.formData.misrepresentationCategoryID = this.tabData.productClaimDecision.decisionDraft.misrepresentationCategoryID = parseInt(e.detail[0]);
        }
        else  if(e.detail[1] == 'retroUWID') {
            this.decisionData.retroUWID = this.formData.retroUWID = this.tabData.productClaimDecision.decisionDraft.retroUWID = parseInt(e.detail[0]);
        }
        else if(e.detail[1] == 'misrepresentationRelatedToClaim') {
            if(e.detail[0] == 'yes') {this.decisionData.misrepresentationRelatedToClaim = this.tabData.productClaimDecision.decisionDraft.misrepresentationRelatedToClaim = true;}
            else if(e.detail[0] == 'no') {this.decisionData.misrepresentationRelatedToClaim = this.tabData.productClaimDecision.decisionDraft.misrepresentationRelatedToClaim = false;}
        }
        else if(e.detail[1] == 'productClaimDecisionCalculationTypeID') {
            this.decisionData.productClaimDecisionCalculationTypeID = this.formData.productClaimDecisionCalculationTypeID = this.tabData.productClaimDecision.decisionDraft.productClaimDecisionCalculationTypeID = parseInt(e.detail[0]);
        }
        else if(e.detail[1] == 'decisionTypeID') {
            this.decisionData.decisionTypeID = this.formData.decisionTypeID = this.tabData.productClaimDecision.decisionDraft.decisionTypeID = parseInt(e.detail[0]);
            getDecisionSubTypes(this.decisionData.decisionTypeID.toString()).then(decisionSubTypes => {
                this.decSubTypes = decisionSubTypes;
                for(let i=0; i<this.decSubTypes.decisionSubTypes.length; i++) {
                    let obj = {label:this.decSubTypes.decisionSubTypes[i].subType, value:this.decSubTypes.decisionSubTypes[i].productClaimDecisionSubTypeID};
                    this.layoutData[1].subSections[0].rows[1].fields[1].options.push(obj);
                }
                //     this.State.show();
                // this.subscribeToMessageChannel(); // subscribing to the "save/ancel" event message channel
                this.loadTheContent(true); // this is for loading the decision data in the fields, initial load
            });
        }
        else if(e.detail[1] == 'decisionSubTypeID') {
            this.decisionData.decisionSubTypeID = this.formData.decisionSubTypeID = this.tabData.productClaimDecision.decisionDraft.decisionSubTypeID = parseInt(e.detail[0]);
        }
        else if(e.detail[1] == 'payeeName') {
            this.decisionData.payeeName = this.tabData.productClaimDecision.decisionDraft.payeeName = e.detail[0];
        }
        else if(e.detail[1] == 'payeeReference') {
            this.decisionData.payeeReference = this.tabData.productClaimDecision.decisionDraft.payeeReference = e.detail[0];
        }
        else if(e.detail[1] == 'pepSanctionCheckDate') {
            this.decisionData.pepSanctionCheckDate = this.tabData.productClaimDecision.decisionDraft.pepSanctionCheckDate = e.detail[0];
        }
        else if(e.detail[1] == 'payToPremiumAccount') {
            if(e.detail[0] == 'yes') {this.decisionData.payToPremiumAccount = this.tabData.productClaimDecision.decisionDraft.payToPremiumAccount = true;}
            else if(e.detail[0] == 'no') {
                this.decisionData.payToPremiumAccount = this.tabData.productClaimDecision.decisionDraft.payToPremiumAccount = false;
                
            }
            this.loadTheContent(true); // just to update the "bank section"
        }
        else if(e.detail[1] == 'reinsurerDecisionDate') {
            this.decisionData.reinsurerDecisionDate = this.tabData.productClaimDecision.decisionDraft.reinsurerDecisionDate = e.detail[0];
        }
        else if(e.detail[1] == 'reinsurerComments') {
            this.decisionData.reinsurerComments = this.tabData.productClaimDecision.decisionDraft.reinsurerComments = e.detail[0];
        }
        else if(e.detail[1] == 'isReinsurerApproved') {
            if(e.detail[0] == 'approved') {this.decisionData.isReinsurerApproved = this.tabData.productClaimDecision.decisionDraft.isReinsurerApproved = true;}
            else if(e.detail[0] == 'decline') {this.decisionData.isReinsurerApproved = this.tabData.productClaimDecision.decisionDraft.isReinsurerApproved = false;}
        }
        else if(e.detail[1] == 'effectiveDate'
                || e.detail[1] == 'bankName'
                || e.detail[1] == 'accountName'
                || e.detail[1] == 'accountNumber'
                || e.detail[1] == 'sortCode'
                // || e.detail[1] == 'payeeReference'
                || e.detail[1] == 'bankDetailsValidated') {                  
                if(e.detail[1] == 'bankDetailsValidated')  {
                    if(e.detail[0] == 'yes') {this.decisionData.bankDetail.bankDetailsValidated = this.tabData.productClaimDecision.decisionDraft.bankDetail.bankDetailsValidated = true;}
                    else if(e.detail[0] == 'no') {this.decisionData.bankDetail.bankDetailsValidated = this.tabData.productClaimDecision.decisionDraft.bankDetail.bankDetailsValidated = false;}
                } 
                else 
                    this.decisionData.bankDetail[e.detail[1]] = this.tabData.productClaimDecision.decisionDraft.bankDetail[e.detail[1]] = e.detail[0];
        }
        this.tabData.decision = this.decisionData;
        setProductData(this.tabData);
        publish(this.messageContext, ProductClaimDirty__c, {
            componentName: 'Decision Tab'
        });
        // this.loadTheContent(true);
    }

    //when a button is clicked on the decision tab
    handleDecisionButtonClick(e) {
        if (e.detail[0] === 'Submit For Approval') {
            submitForApproval({pRecordId : this.recordId})
                .then(result => {
                    if (result === 'success') {
                        const event = new ShowToastEvent({
                            title: 'Success!',
                            message: 'Record submitted for approval!',
                            variant: 'success'
                        });
                        this.dispatchEvent(event);
                    }
                })
                .catch(error => {
                    if (error.body.message.includes('NO_APPLICABLE_PROCESS')) {
                        const event = new ShowToastEvent({
                            title: 'Error!',
                            message: 'No applicable approval process was found.',
                            variant: 'error'
                        });
                        this.dispatchEvent(event);
                    }
                    this.error = error;
                });
        }
        // will be written when we work for journeys B-C-D
    }

    //when we get the "save/cancel" message, we're refreshing the data
    handleRefreshMessage(message) {
        if(message.msg == 'Saved!');
        else if(message.msg == 'Cancelled!');

        getProductData(this.claimExternalId).then(result => {
            this.tabData = result; 
            this.State.show();
            this.loadTheContent(true); // we do the refresh
        });
    }
    
    /*****************
     * HELPER METHODS
     *****************/

    // for listening the "refresh" event, which is dispatched when a save/cancel action happens.
     subscribeToMessageChannel() {
        if (!this.subscription) {
            this.subscription = subscribe(
                this.messageContext,
                ProductClaimRefreshData__c,
                (message) => this.handleRefreshMessage(message),
                { scope: APPLICATION_SCOPE }
            );
        }
    }

    /**
     * for creating empty (or with values) bank section(s)
     * @param {Boolean} bank The existing payment detail coming from the service
     * @param {Boolean} isNew If we're going to use this method in order to create an empty occupation section
     */
     createBankSections(bank, isNew) {
        let layout = null;
        if(!isNew) {
            console.log(this.formData.payToPremiumAccount);
            if (this.formData.payToPremiumAccount == 'yes') {
                console.log('yes');
                layout = JSON.parse(JSON.stringify(BANK_LAYOUT_DATA));
                bank = this.bankData;
               // bank['bankDetailsValidated'] = true;
               this.formData.bankDetailsValidated = 'yes'
            }
            else if (this.formData.payToPremiumAccount == 'no') {
                console.log('no');
                layout = JSON.parse(JSON.stringify(BANK_LAYOUT_DATA_EDIT));                
            }
            layout.id = this.numberOfNewBanks;
            this.layoutData[0].subSections.splice(1, 0, layout);
            //(this.formData.payToPremiumAccount);
            // if(this.formData.payToPremiumAccount == 'no' && bank != null){
            //     this.formData.effectiveDate = '';
            //     this.formData.bankName = '';
            //     this.formData.accountName = '';
            //     this.formData.accountNumber = '';
            //     this.formData.sortCode = '';
            //     this.formData.payeeReference = '';
            // }
            // else if(this.formData.payToPremiumAccount == 'yes'){
                //layout.isDeletable = true;
                this.formData.effectiveDate = bank?.effectiveDate;
                this.formData.bankName = bank?.bankName;
                this.formData.accountName = bank?.accountName;
                this.formData.accountNumber = bank?.accountNumber;
                this.formData.sortCode = bank?.sortCode;
                // this.formData.payeeReference = bank?.payeeReference;
            // }
            if(bank?.bankDetailsValidated == true) this.formData.bankDetailsValidated = 'yes'
            else if(bank?.bankDetailsValidated == false) this.formData.bankDetailsValidated = 'no'
        }
        else {
            // will be implemented when we're working on the "New Payment Details" button
        }
    }

    /**
     * for assigning the captured calc types, decision types & decision subtypes to the layout
     */
    assignLists() {
        
        for(let i=0; i<this.misRepTypes?.misRepTypes.length; i++) {
            let obj = {label:this.misRepTypes.misRepTypes[i].misrepresentationTypeName, value:this.misRepTypes.misRepTypes[i].misrepresentationTypeID};
            this.layoutData[2].subSections[0].rows[0].fields[0].options.push(obj);
        }
        for(let i=0; i<this.misRepCatTypes?.misRepCatTypes.length; i++) {
            let obj = {label:this.misRepCatTypes.misRepCatTypes[i].misrepresentationCategoryName, value:this.misRepCatTypes.misRepCatTypes[i].misrepresentationCategoryID};
            this.layoutData[2].subSections[0].rows[1].fields[0].options.push(obj);
        }
        for(let i=0; i<this.misRepRetro?.misRepRetros.length; i++) {
            let obj = {label:this.misRepRetro.misRepRetros[i].retroUW_Name, value:this.misRepRetro.misRepRetros[i].retroUW_ID};
            this.layoutData[2].subSections[0].rows[1].fields[1].options.push(obj);
        }
        for(let i=0; i<this.calcTypes?.calculationTypes.length; i++) {
            let obj = {label:this.calcTypes.calculationTypes[i].productClaimDecisionCalculationTypeName, value:this.calcTypes.calculationTypes[i].productClaimDecisionCalculationTypeID};
            this.layoutData[1].subSections[0].rows[0].fields[1].options.push(obj);
        }
        for(let i=0; i<this.decTypes?.decisionTypes.length; i++) {
            let obj = {label:this.decTypes.decisionTypes[i].type, value:this.decTypes.decisionTypes[i].productClaimDecisionTypeID};
            this.layoutData[1].subSections[0].rows[1].fields[0].options.push(obj);
        }
        if(this.decSubTypes != {} && this.decSubTypes.decisionSubTypes != null && this.decSubTypes.decisionSubTypes.length > 0){
            for(let i=0; i<this.decSubTypes.decisionSubTypes.length; i++) {
                let obj = {label:this.decSubTypes.decisionSubTypes[i].subType, value:this.decSubTypes.decisionSubTypes[i].productClaimDecisionSubTypeID};
                this.layoutData[1].subSections[0].rows[1].fields[1].options.push(obj);
            }
        }
    }

     /**
     * filling the Decision Summary table with the "published" Decisions
     */
      fillSummaryTable() {
        if(this.tabData.productClaimDecision.decisionPublished != null) {
            // will be done when we start getting published decision data
        }
        else
            this.decisionSummaryData = [];
        this.layoutData[4].subSections[0].rows[0].fields[0].tableData = this.decisionSummaryData;
      }

    /**
     * @param {Boolean} isRefreshed True when refreshed, false on initial loading
     * @description this is for refreshing the data & the layout of the component's content
     */
    loadTheContent(isRefreshed) {
        this.layoutData = JSON.parse(JSON.stringify(LAYOUT_DATA));
        this.assignLists();
        this.fillSummaryTable();
        this.formData = {};
        
        this.formData.misrepresentationTypeID = (this.tabData.productClaimDecision.decisionDraft.misrepresentationTypeID != null ? this.tabData.productClaimDecision.decisionDraft.misrepresentationTypeID : 1);
        this.decisionData.misrepresentationTypeID = this.tabData.productClaimDecision.decisionDraft.misrepresentationTypeID;

        this.formData.misrepresentationRelatedToClaim = (this.tabData.productClaimDecision.decisionDraft.misrepresentationRelatedToClaim != null ? (this.tabData.productClaimDecision.decisionDraft.misrepresentationRelatedToClaim == true ? 'yes' : 'no') : 'unselected');
        this.decisionData.misrepresentationRelatedToClaim = this.tabData.productClaimDecision.decisionDraft.misrepresentationRelatedToClaim;

        this.formData.misrepresentationCategoryID = (this.tabData.productClaimDecision.decisionDraft.misrepresentationCategoryID != null ? this.tabData.productClaimDecision.decisionDraft.misrepresentationCategoryID : 'unselected');
        this.decisionData.misrepresentationCategoryID = this.tabData.productClaimDecision.decisionDraft.misrepresentationCategoryID;

        this.formData.retroUWID = (this.tabData.productClaimDecision.decisionDraft.retroUWID != null ? this.tabData.productClaimDecision.decisionDraft.retroUWID : 'unselected');
        this.decisionData.retroUWID = this.tabData.productClaimDecision.decisionDraft.retroUWID;

        this.formData.financialAssessmentID = (this.tabData.productClaimDecision.decisionDraft.financialAssessmentID != null ? this.tabData.productClaimDecision.decisionDraft.financialAssessmentID : '0').toString();
        this.decisionData.productClaimDecisionCalculationTypeID = this.formData.productClaimDecisionCalculationTypeID = (this.tabData.productClaimDecision.decisionDraft.productClaimDecisionCalculationTypeID != null ? this.tabData.productClaimDecision.decisionDraft.productClaimDecisionCalculationTypeID : 1);
        
        this.formData.decisionTypeID = (this.tabData.productClaimDecision.decisionDraft.decisionTypeID != null ? this.tabData.productClaimDecision.decisionDraft.decisionTypeID : 'unselected');
        this.decisionData.decisionTypeID = this.tabData.productClaimDecision.decisionDraft.decisionTypeID;

        this.formData.decisionSubTypeID = (this.tabData.productClaimDecision.decisionDraft.decisionSubTypeID != null ? this.tabData.productClaimDecision.decisionDraft.decisionSubTypeID : 'unselected');
        this.decisionData.decisionSubTypeID = this.tabData.productClaimDecision.decisionDraft.decisionSubTypeID;

        this.decisionData.payeeName = this.formData.payeeName = this.tabData.productClaimDecision.decisionDraft.payeeName;
        this.decisionData.payeeReference = this.formData.payeeReference = this.tabData.productClaimDecision.decisionDraft.payeeReference;
        this.decisionData.pepSanctionCheckDate = this.formData.pepSanctionCheckDate = this.tabData.productClaimDecision.decisionDraft.pepSanctionCheckDate;
        this.decisionData.reinsurerDecisionDate = this.formData.reinsurerDecisionDate = this.tabData.productClaimDecision.decisionDraft.reinsurerDecisionDate;
        this.decisionData.reinsurerComments = this.formData.reinsurerComments = this.tabData.productClaimDecision.decisionDraft.reinsurerComments;
        
        this.formData.isReinsurerApproved = (this.tabData.productClaimDecision.decisionDraft.isReinsurerApproved != null ? (this.tabData.productClaimDecision.decisionDraft.isReinsurerApproved == true ? 'approved' : 'decline') : 'unselected');
        this.decisionData.isReinsurerApproved = this.tabData.productClaimDecision.decisionDraft.isReinsurerApproved;
        this.formData.payToPremiumAccount = (this.tabData.productClaimDecision.decisionDraft.payToPremiumAccount == null || this.tabData.productClaimDecision.decisionDraft.payToPremiumAccount == true ? 'yes' : 'no');
        this.decisionData.payToPremiumAccount = this.tabData.productClaimDecision.decisionDraft.payToPremiumAccount

        this.decisionData.bankDetail = this.tabData.productClaimDecision.decisionDraft.bankDetail;
        // this.createBankSections(this.tabData.productClaimDecision.decisionDraft.bankDetail,false);
        this.createBankSections(this.tabData.productClaimDecision.decisionDraft.bankDetail,false);
      
        if(isRefreshed) {
            setTimeout(() => {
                this.template.querySelector('c-form').rebuildLayout();
                this.template.querySelector('c-form').syncFields();                    
            }, 100);
        }
    }
}