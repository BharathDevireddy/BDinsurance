//Salesforce Imports
import { api, track, wire} from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';

//Object Imports
//Sometimes sfdx pull/retrieve will change `__mdt` to `__c`, and since `Cover Table Configuration`
//is a custom metadata, it should always be `Cover_Table_Configuration__mdt` rather than `Cover_Table_Configuration__c`
//Just flip them back, should fix any compilation issues
import Cover_Table_Configuration__ColumnLabel from '@salesforce/schema/Cover_Table_Configuration__c.Column_Label__c';
import Cover_Table_Configuration__ColumnPropertyPayload from '@salesforce/schema/Cover_Table_Configuration__c.Column_Payload_Property__c';
import Cover_Table_Configuration__ColumnTag from '@salesforce/schema/Cover_Table_Configuration__c.Column_Tag__c';
import Cover_Table_Configuration__FieldType from '@salesforce/schema/Cover_Table_Configuration__c.Field_Type__c';
import Cover_Table_Configuration__FieldTypeConfig from '@salesforce/schema/Cover_Table_Configuration__c.Field_Type_Config__c';
import Cover_Table_Configuration__TotalColumn from '@salesforce/schema/Cover_Table_Configuration__c.Total_Column__c';

//LWC Imports
import { callApex, clearCache } from 'c/utility';
import ClaimsComponent from 'c/claimsComponent';

//Apex Imports
import fetchCoverTableMetadata from '@salesforce/apex/CoverTable_LEx.fetchCoverTableMetadata';
import fetchRecordPolicyReference from '@salesforce/apex/CoverTable_LEx.fetchRecordPolicyReference';

//Internal Imports
import BODY from './coverTable.html';

//Field definition imports
import PRODUCT_GROUP_FIELD from '@salesforce/schema/Case.Product_Group__c';

//Constants
const IDENTIFIER_COVER_TABLE_METADATA = 'CoverTable_LExfetchCovertableMetadata';
const IDENTIFIER_RECORD_POLICY_REFERENCE = 'CoverTable_LExfetchRecordPolicyReference';
const CASE_FIELDS = [PRODUCT_GROUP_FIELD];

export default class CoverTable extends ClaimsComponent {

    /*=========================================================
            External Vars
    =========================================================*/

    @api recordId;
    @api displayActiveCovers = false;
    @api shownTags = [];
    @api title = 'Covers';
    @api filterByProductGroup = false;
    @api policyNumberExists;

    /*=========================================================
            Parent Component Vars
    =========================================================*/

    componentLabel = 'Cover Summary Table';
    componentBody = BODY;

    /*=========================================================
            Vars
    =========================================================*/

    @track columns = [];
    @track data = [];
    totalRow;

    recordPolicyNumber;
    columnsToTotal = [];

    /*=========================================================
            Getters
    =========================================================*/

    get cardTitle() { return this.title + (this.data ? ` (${this.data.length})` : '') }
    get tableData() { return this.totalRow ? [...this.data, this.totalRow] : this.data; }
    get showTable() { return this.displayActiveCovers || this.data.length > 0; }
    get productGroup() { return getFieldValue(this.case.data, PRODUCT_GROUP_FIELD); }

    @wire(getRecord, { recordId: '$recordId', fields: CASE_FIELDS }) case;

    /*=========================================================
            Events
    =========================================================*/

    @api onAccountChange() { this.handleAccountChange(); }

    /*=========================================================
            Setup
    =========================================================*/

    /**
     * Entry point of the component. Build the table's columns and the Policy Number from
     * the current record. Once that's done, build the dataset by calling out from Salesforce
     */
    async connectedCallback() {
        console.log('connected');
        try {
            await Promise.all([
                this.buildColumns(), 
                this.fetchPolicyNumber().then(pVal => this.recordPolicyNumber = pVal)
            ])
            await this.buildData(); //Awaiting for error catching
        } catch(ex) {
            this.ErrorHandling.logErrorFromException(ex);
        } finally {
            this.State.show();
        }
        if(this.recordPolicyNumber){
           this.policyNumberExists = true;
        }else{
            this.policyNumberExists = false;
        }
        const policynumberevent = new CustomEvent('getpolicynumberexists',{
            detail: this.policyNumberExists
        })
        console.log('CUSTOM EVENT DETAIL '+policynumberevent.detail);
        this.dispatchEvent(policynumberevent);
    }

    /**
     * Fetches the policy number through an apex method using the recordId.
     * This will cache the result using `utility.callApex`
     */
    async fetchPolicyNumber() {
        return await callApex(
            fetchRecordPolicyReference,
            {
                pRecordId: this.recordId
            },
            IDENTIFIER_RECORD_POLICY_REFERENCE + this.recordId
        );
        
    }
    
    /**
     * Builds the columns based on custom metadata. This metadata is grabbed within Apex and 
     * used here to build out columns based on component filters. As well as identify any total columns
     */
    async buildColumns() {
        //Fetch the metadata
        let columnMetadata = await callApex(
            fetchCoverTableMetadata,
            undefined,
            IDENTIFIER_COVER_TABLE_METADATA
        );
        //Reduce metadata by tag
        columnMetadata = columnMetadata.filter(
            metadata => {
                let tags = this.getFieldValue(metadata, Cover_Table_Configuration__ColumnTag);
                return tags && tags.split(',').filter(tag => this.shownTags.includes(tag)).length > 0;
            }
        );
        //Build the columns
        this.columns = [];
        for(let metadata of columnMetadata) {
            let columnData = {
                label: this.getFieldValue(metadata, Cover_Table_Configuration__ColumnLabel),
                fieldName: this.getFieldValue(metadata, Cover_Table_Configuration__ColumnPropertyPayload),
                type: this.getFieldValue(metadata, Cover_Table_Configuration__FieldType),
            };
            let typeAttributes = this.getFieldValue(metadata, Cover_Table_Configuration__FieldTypeConfig);
            if(typeAttributes) {
                columnData.typeAttributes = JSON.parse(typeAttributes);
            }
            if(this.getFieldValue(metadata, Cover_Table_Configuration__TotalColumn) === true) {
                this.columnsToTotal.push(columnData.fieldName);
            }
            this.columns.push(columnData);
        }
    }

    /**
     * This method will build the data that is displayed on the table using the columns defined in.
     * This will also create the total row at the bottom of the table if it is required
     */
    async buildData() {
        let coverResponse = await this.ClaimsDataService.fetchCoverInformation(this.recordPolicyNumber);
        let covers = this.displayActiveCovers ? coverResponse.Active : coverResponse.Inactive;
        if(Array.isArray(covers) && covers.length > 0) {
            //Modify cover data
            await Promise.all(covers.map(cover => this.buildCoverDetailURL(cover)));
            //Set cover data
            this.data = this.filterByProductGroup ? this.filterCoversByProductGroup(covers) : covers;
            if(this.columnsToTotal.length > 0 && this.displayActiveCovers) {
                let totalRow = {};
                for(let cover of this.data) {
                    for(let fieldName of this.columnsToTotal) {
                        totalRow[fieldName] = (totalRow[fieldName] === undefined ? 0 : totalRow[fieldName]) + cover[fieldName]; 
                    }
                }
                totalRow[this.columns[0].fieldName] = 'Total';
                this.totalRow = totalRow;
            }
        } 
    }

    async buildCoverDetailURL(cover) {
        cover.Link = await this.Navigation.generateComponentPageLink(
            'policyDetailPage', 
            { 
                policyRef: this.recordPolicyNumber, 
                selectedCover: cover.CoverReference 
            }
        );
    }

    /*=========================================================
            Handlers
    =========================================================*/

    /**
     * Handles when the Account Record has been changed. This will grab the latest
     * policy number, and if it's different from the one we have stored, then get the
     * new set of covers. 
     */
    async handleAccountChange() {
        try {
            this.isLoading = true;
            clearCache(IDENTIFIER_RECORD_POLICY_REFERENCE + this.recordId); 
            let returnedNumber = await this.fetchPolicyNumber();
            if(returnedNumber != this.recordPolicyNumber) {
                this.recordPolicyNumber = returnedNumber;
                await this.buildData(); //No need to clear cache due to different policy number
            }
        } catch(ex) {
            this.ErrorHandling.logErrorFromException(ex);
        } finally {
            this.State.show();
        }
    }

    /*=========================================================
            Helpers
    =========================================================*/

    /**
     * Small helper method to fetch field information. This uses an SObject record and
     * the field import
     * @param {Object} pRecord SObject Record data
     * @param {Object} pField Field Import to fetch
     * @returns {Object} Field data, undefined if not populated
     */
    getFieldValue(pRecord, pField) {
        return pRecord[pField.fieldApiName];
    }

    filterCoversByProductGroup(pCovers) {
        return pCovers.filter(cover => {
            return cover.Cover === this.productGroup;
        });
    }

}