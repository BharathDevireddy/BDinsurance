import {LightningElement, api} from 'lwc';

export default class AssessmentPeriod extends LightningElement {

    @api
    assessmentPeriod;

    onAssessmentSaved() {
        this.dispatchEvent(new CustomEvent('assessmentsaved'));
    }

}