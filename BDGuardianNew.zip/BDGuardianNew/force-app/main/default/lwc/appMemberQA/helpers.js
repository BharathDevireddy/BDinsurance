/**
 * @description builds up an array of objects used whilst to create radioOptions
 * @param availableOptions - A map of active ApplicationQA__c.Status__c picklist options - APIName to Label
 * @param applicationMemberOptions - A map of record counts of each ApplicationQA__c.Status__c where records >= 1
 * @param statusHelpTextMappings - A map of ApplicationQA__c.Status__c API names and their custom label help texts
 * @return Array[ {apiName:"", label: "", recordCount: 0, isChecked: false, helpText: "" isDisabled: false} ]
 */
function createRadioOptions(availableOptions, applicationMemberOptions, statusHelpTextMappings, isNBJ2) {
    const defaultValue = isNBJ2 ? 'Current' : calculateDefaultOption(applicationMemberOptions);
    let results = [];

    for (const opt of Object.keys(availableOptions)) {
        results.push({
            apiName:opt,
            label: availableOptions[opt],
            recordCount: (applicationMemberOptions[opt] || 0),
            isChecked: (opt === defaultValue),
            isDisabled: ((applicationMemberOptions[opt] || 0) === 0),
            helpText: statusHelpTextMappings[opt]
        });
    };
    return results;
};

/**
 * @description returns picklist value API name which should be selected by default 
 * @param applicationMemberOptions - Map of API Names to number of records where records >= 1
 * @return ApplicationQA__c.Status__c picklist option API name
 */
function calculateDefaultOption(applicationMemberOptions) {
    const keys = Object.keys(applicationMemberOptions);
    return (keys.length > 0) ? keys[0] : '';
};

/**
 * @description string sorting function used in .sort() functions
 * @param a - first value for comparison
 * @param b - second value for comparison
 */
function sortFunctionString(a, b) {
    return (a > b) - (a < b);
}

/**
 * @description method to sort datatable data by direction. returns a new array which will trigger UI refresh
 * @param data - array of objects usually returned on APEX SOQL methods
 * @param key - key identifier used to aqcuire value comparison
 * @param direction - string either 'asc' or 'desc' to describe the direction of expected sort
 * @return sorted array
 */
function sortDataList(data, key, direction) {
    if ('desc' === direction) {
        return [...data.sort((a, b) => sortFunctionString(b[key], a[key]) )];
    } else if ('asc' === direction) {
        return [...data.sort((a, b) => sortFunctionString(a[key], b[key]) )];
    };
}

export{ createRadioOptions, sortDataList, calculateDefaultOption }