import { LightningElement, api, track, wire } from 'lwc';
// import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { createRadioOptions, sortDataList, calculateDefaultOption } from './helpers'

import { getErrorMessage } from 'c/utility';

import getQAStatusOptions                   from '@salesforce/apex/AppMemberQA_Ctrl.getQAStatusOptions';
import getApplicationMemberId               from '@salesforce/apex/AppMemberQA_Ctrl.getApplicationMemberId';
import getApplicationQARecordsForStatus     from '@salesforce/apex/AppMemberQA_Ctrl.getWrappedApplicationQARecordsForStatus';
import fetchApplicationMemberAnswerStatuses from '@salesforce/apex/AppMemberQA_Ctrl.fetchApplicationMemberAnswerStatuses';
import getIsThisNBJ2 							  from '@salesforce/apex/AppMemberQA_Ctrl.getIsThisNBJ2';
import getShowURELink							  from '@salesforce/apex/AppMemberQA_Ctrl.getShowURELink';
// import object_ApplicationQA__c              from '@salesforce/schema/ApplicationQA__c'

import applicantWithoutApplicationQA    from '@salesforce/label/c.ApplicantWithoutApplicationQA';
import helpTextFinal                    from '@salesforce/label/c.appMemberQA_StatusHelp_Final';
import helpTextQuote                    from '@salesforce/label/c.appMemberQA_StatusHelp_Quote';
import helpTextChangedHistoric          from '@salesforce/label/c.appMemberQA_StatusHelp_ChangedHistoric';
import helpTextAnsweredDifferently      from '@salesforce/label/c.appMemberQA_StatusHelp_AnsweredDifferently';
import helpTextOrphaned                 from '@salesforce/label/c.appMemberQA_StatusHelp_Orphaned';
//nbj2 helptexts
import helpTextReferral						from '@salesforce/label/c.appMemberQA_StatusHelp_Referral';
import helpTextCurrent						from '@salesforce/label/c.appMemberQA_StatusHelp_Current';
import helpTextChanged						from '@salesforce/label/c.appMemberQA_StatusHelp_Changed';
import helpTextOrphanednbj2				from '@salesforce/label/c.appMemberQA_StatusHelp_Orphaned_NBJ2';
//PP helptext
import helpTextForeignQuestions			from '@salesforce/label/c.appMemberQA_StatusHelp_Foreign';



export default class ApplicationQuestionsAndAnswers extends LightningElement {

    @api recordId;

    @track wireAppQAObjectInfo;
    @track defaultRadioValue;
    @track radioOptions;
    @track dataTableColumns;
    @track dataTableValues = [];
    @track dataTableSortedBy;
    @track dataTableSortedDirection;
    @track dataTableLoading = true;
    @track hasError = false;
    @track error;
    @track applicationMemberId;
	 isNBJ2 = false;
	 @track showURELink;

	 

    applicationMemberStatuses;                      // current statuses for application Member
    customLabel = { applicantWithoutApplicationQA } // custom label references
    defaultSortedColumn;                            // Field API Name for default sorted column on datatable. Currently set to be (ApplicationQA__c)CompletedDate__c field

    // maps ApplicationQA__c.Status__c API name to custom label help text
    radioOptionsHelpMappings = {
		'final'                 : helpTextFinal,
		'quote answers'         : helpTextQuote,
		'changed/historic'      : helpTextChangedHistoric,
		'answered differently'  : helpTextAnsweredDifferently,
		'orphaned'              : helpTextOrphaned,
		//nbj2
		'Referral'					:	helpTextReferral,
		'Current'					:	helpTextCurrent,
		'Changed'					:	helpTextChanged,
		'Orphaned'					:	helpTextOrphanednbj2,
		//PP
		'Foreign'					:	helpTextForeignQuestions
    };

    get hasQARecords()          { return (this.defaultRadioValue && this.applicationMemberId) };
    get radioGroupDisabled()    { return !this.hasQARecords };

    async connectedCallback() {
        try {
            // get application member id - this will be determined from current object context
            this.applicationMemberId = (await getApplicationMemberId({'parentRecordId': this.recordId}));

            if (this.applicationMemberId) {
					 //determine if this is NBJ1/2
					 this.isNBJ2 = (await getIsThisNBJ2({'applicationMemberId': this.applicationMemberId}));
					 
					 this.defaultSortedColumn = 'completedDate'; // set the default sorted column. This is referenced when the datatable is refreshed

					 //set datatable columns based on nbj type
					 if(this.isNBJ2){ //nbj2
						this.dataTableColumns = [
							 {'label': 'Question',    							'fieldName':'text',	wrapText: true,  sortable: true, type:'wHelpTxt',
							 typeAttributes: { options: { fieldName: 'questionOptions'}, isForeignQuestion : { fieldName: 'isForeignQuestion'}}},
							 {'label': 'Answer',      							'fieldName':'displayAnswer',		wrapText: true,  sortable: true},
							 {'label': 'UMe session number', 				'fieldName':'snapshot',				wrapText: true,  sortable: true},
							 {'label': 'App Section Name',					'fieldName':'section',       		wrapText: true,  sortable: true},
							 {'label': 'Date and time last answered',   	'fieldName':'completedDate',		wrapText: true,  sortable: true,
								  type: 'date', typeAttributes: { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }
							 },
							 {'label': 'User',									'fieldName':'userName',          wrapText: true,  sortable: true}
						];
					 }
					 else{ //nbj1 settings
						this.dataTableColumns = [
							 {'label': 'Question',    			'fieldName':'text',					wrapText: true,  sortable: true},
							 {'label': 'Answer',      			'fieldName':'displayAnswer',		wrapText: true,  sortable: true},
							 {'label': 'Question Section',	'fieldName':'section',       		wrapText: true,  sortable: true},
							 {'label': 'Completed Date',   	'fieldName':'completedDate',		wrapText: true,  sortable: true,
								  type: 'date', typeAttributes: { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }
							 },
							 {'label': 'Question Code',		'fieldName':'code',           	wrapText: true,  sortable: true}
						];
					 }

                // retrieve record counts for QA records per status (for application member)
                this.applicationMemberStatuses = (await fetchApplicationMemberAnswerStatuses({'applicationMemberId': this.applicationMemberId, 'isNBJ2': this.isNBJ2}));

                // calculate the initial default selected radio button - this is used primarily to query results when first shown
                this.defaultRadioValue = (this.isNBJ2 ? 'Current' : await calculateDefaultOption(this.applicationMemberStatuses));
                // retrieve all QA records with status of default selected radio button; where a default exists
                this.dataTableValues = (await getApplicationQARecordsForStatus({'applicationMemberId': this.applicationMemberId, 'status': this.defaultRadioValue, 'isNBJ2': this.isNBJ2}));
					 
                // build list of radio options for current answer statuses and available picklist options dynamically
                this.radioOptions = createRadioOptions((await getQAStatusOptions({'isNBJ2': this.isNBJ2 })), this.applicationMemberStatuses, this.radioOptionsHelpMappings, this.isNBJ2);

                // set default datatable sorting column and direction
                this.dataTableSortedBy = this.defaultSortedColumn;
                this.dataTableSortedDirection = 'asc';
					 
					 //check whether running user should be shown URE link
					 if(this.isNBJ2){
						 this.showURELink = await getShowURELink();
					 }
					 else{
						this.showURELink = false;
					 }
            };
        } catch (err) {
            console.error(err);
            this.hasError = true;
            this.error = getErrorMessage(err);
        };
        this.dataTableLoading = false;
    };

    /**
     * @description event handler used to update datatable when a new radiobutton status has been selected
     */
    async updateDataTableHandler(event) {
        this.dataTableLoading = true;

        // update radioOptions checked flag
        for (const opt of this.radioOptions) { opt.isChecked = (opt.apiName === event.target.value) };

        // reset default sorted columns
        this.dataTableSortedBy = this.defaultSortedColumn;
        this.dataTableSortedDirection = 'asc';

        if (this.applicationMemberStatuses[event.target.value]) {
            try {
                // if records exist for the app member and the selected status, query out all QA records and update datatable
                this.dataTableValues = (await getApplicationQARecordsForStatus({'applicationMemberId': this.applicationMemberId, 'status': event.target.value, 'isNBJ2': this.isNBJ2}))
            } catch (err) {
                console.error(err);
                this.hasError = true;
                this.error = getErrorMessage(err);
            }
        } else {
            // if there are no records available for the current app member, return an empy list
            this.dataTableValues = [];
        };
        this.dataTableLoading = false;
    };

    /**
     * @description handles datatable sort events
     * method will sort the datatable by key and direction
     * @param event
     */
    dataTableSortHandler(event) {
        this.dataTableSortedBy = event.detail.fieldName;
        this.dataTableSortedDirection = event.detail.sortDirection;
        this.dataTableValues = sortDataList(this.dataTableValues, this.dataTableSortedBy, this.dataTableSortedDirection);
   };

	 /**
     * @description Open link to URE enquiry page
     */
	openURE(){ 
		window.open('/lightning/cmp/c__URE_Enquiry_Canvas?c__ApplicationMemberId=' + this.applicationMemberId, '_blank');
	}

}