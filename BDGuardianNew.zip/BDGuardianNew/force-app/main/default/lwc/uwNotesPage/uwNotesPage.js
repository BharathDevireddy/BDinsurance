import { LightningElement, track, api } from 'lwc';
import getUWNotes from '@salesforce/apex/UWNotes_Ctrl.getUWNotes';
import getCaseDetails from '@salesforce/apex/UWNotes_Ctrl.getCaseDetails';


export default class UwNotesPage extends LightningElement {

	@api recordId;
	@track UWNotesList = [];
	@track Case;
	@track showNewBox = false;
	Loading = true;

	async connectedCallback() {
		this.Case = await getCaseDetails({pCaseId: this.recordId});
		this.UWNotesList = await getUWNotes({pCaseId: this.recordId}); 
		this.Loading = false;
	}

	toggleShowNew(){
		this.showNewBox = !this.showNewBox;
	}



}