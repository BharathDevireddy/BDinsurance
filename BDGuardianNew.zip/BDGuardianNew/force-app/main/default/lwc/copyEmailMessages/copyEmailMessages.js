import { LightningElement, api, track } from 'lwc';
import { CloseActionScreenEvent }       from 'lightning/actions';
import { NavigationMixin }              from 'lightning/navigation';
import { ShowToastEvent }               from 'lightning/platformShowToastEvent';

import { WireConverter, getErrorMessage } from 'c/utility';

import * as Apex from './apex';
import * as Label from './label';

export default class CopyEmailMessages extends NavigationMixin(LightningElement) {
    @api
    get recordId()      { return this._recordId; }
    set recordId(value) {
        this._recordId = value;
        this.lazyRecordId.handleResult({ data: value });
    }

    @track error          = null;
    @track loading        = null;
    @track selectedCaseId = null;

    Label = Label;

    _recordId     = null;
    errorLocation = null;
    lazyRecordId  = new WireConverter();

    get disableCopyButton() { return this.loading || !this.selectedCaseId; }

    closeModal() {
        this.dispatchEvent(new CloseActionScreenEvent());
    }
    async copyEmails() {
        if(!this.disableCopyButton) {
            try {
                this.resetError();

                this.loading = "Copying emails";

                const recordId = await this.lazyRecordId.fetch();
                const count = await Apex.copyEmails(recordId, this.selectedCaseId);
                if(count > 0) {
                    const caseUrl = await this[NavigationMixin.GenerateUrl]({
                        type: 'standard__recordPage',
                        attributes: {
                            recordId: this.selectedCaseId,
                            actionName: 'view',
                        }
                    });

                    this.dispatchEvent(new ShowToastEvent({
                        message: Label.CopyEmailMessages_Success,
                        title:   'Success',
                        variant: 'success',
                        messageData: [
                            `${count}`,
                            {
                                url: caseUrl,
                                label: Label.CopyEmailMessages_Success_RecordLink,
                            }
                        ]
                    }));
                } else {
                    this.dispatchEvent(new ShowToastEvent({
                        message: Label.CopyEmailMessages_Warning_NoEmails,
                        title:   'Success',
                        variant: 'warning',
                    }));
                }
                this.closeModal();
            } catch(err) {
                console.error(err);

                this.error         = getErrorMessage(err);
                this.errorLocation = 'execute';

                this.loading = false;
            }
        }
    }

    resetError() {
        this.error         = null;
        this.errorLocation = null;
    }

    async searchCases(e) {
        let results = [ ];
        try {
            if(e.detail.query.length === 0) {
                const recordId   = await this.lazyRecordId.fetch();
                const rawResults = await Apex.mostRecentCases(recordId);

                results = rawResults.map(r => ({
                    label:    r.CaseNumber,
                    value:    r.Id,
                    meta:     r.Subject,
                }));
            } else {
                // Wait for a break in typing so that we don't hammer the server
                // with a million requests while the search is still being
                // formed
                await new Promise(r => setTimeout(r, 500));
                if(e.detail.isLatest()) {
                    if(e.detail.query.length > 1) {
                        const recordId   = await this.lazyRecordId.fetch();
                        const rawResults = await Apex.searchCases(e.detail.query, recordId);
                        results = rawResults.map(r => ({
                            label:    r.CaseNumber,
                            value:    r.Id,
                            meta:     r.Subject,
                        }));
                    }
                }
            }

            if(this.errorLocation === 'search') {
                this.resetError();
            }
        } catch(err) {
            console.error(err);
            if(e.detail.isLatest()) {
                this.error         = getErrorMessage(err);
                this.errorLocation = 'search';
            }
        } finally {
            e.detail.respond(results);
        }
    }
    caseSelected(e) {
        this.selectedCaseId = e.detail.value;
    }
}