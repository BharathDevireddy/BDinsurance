import {LightningElement} from 'lwc';

import {CATEGORY_OPTIONS} from "c/assessmentUtils";

export default class AssessmentFilters extends LightningElement {

    categoryOptions = JSON.parse(JSON.stringify(CATEGORY_OPTIONS));
    filters = {};

    connectedCallback() {
        this.addEmptyCategoryOption();
    }

    onSearch() {
        let formElements = this.template.querySelectorAll("[data-role='formInput']");
        this.captureFieldValues(formElements, this.filters);
        this.dispatchEvent(new CustomEvent('search', {detail: this.filters}))
    }

    addEmptyCategoryOption() {
        this.categoryOptions.unshift({
            label: 'All Categories', value: ''
        });
    }

    captureFieldValues(formElements, editedObject) {
        const checkedFieldTypes = ['checkbox', 'toggle'];
        formElements.forEach(formElement => {
            let fieldName = formElement.dataset.field;
            console.log(fieldName);
            if (checkedFieldTypes.includes(formElement.type)) {
                editedObject[fieldName] = formElement.checked;
            } else {
                editedObject[fieldName] = formElement.value;
            }
            console.log(editedObject[fieldName]);
        });
    }
}