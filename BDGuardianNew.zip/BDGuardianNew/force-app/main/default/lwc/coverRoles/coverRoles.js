//LWC Imports
import { api, track } from 'lwc';

//Object Imports
import ACCOUNT_OBJECT from '@salesforce/schema/Account';

//Component imports
import { sortObject, getErrorMessage } from 'c/utility';
import ClaimsComponent from 'c/claimsComponent';

//Apex Imports
import fetchAccountIdsFromPolicyNumber from '@salesforce/apex/CoverRoles_LEx.fetchAccountIdsFromPolicyNumber';

//Internal Imports
import BODY from './coverRoles.html';
import { COLUMNS, DATA_ORDERING } from './constants';

//Constants
const TYPES_FOR_LINK = [ 'Dual Life', 'Dual Owner' ];

export default class CoverRoles extends ClaimsComponent {

    /*=========================================================
            Parent Component Vars
    =========================================================*/

    componentLabel = 'Cover Roles';
    componentBody = BODY;

    /*=========================================================
           Vars
    =========================================================*/
    
    @api policyRef;
    @api coverRef;

    @track cardTitle = 'Roles';
    @track data;
    @track columns = COLUMNS;
    
    /*=========================================================
           Setup
    =========================================================*/
    
    /**
     * Once connected, callout to the claims data service to fetch the details for the provided cover,
     * then create the form data object needed to display it in the UI
     */
    async connectedCallback() {
        try {
            let details = await this.ClaimsDataService.fetchCoverDetails(this.policyRef, this.coverRef);
            if(details?.RoleSummary?.Roles != null) {
                //Set title
                this.cardTitle += ` (${details.RoleSummary.Roles.length})`;
                //Grab data from roles
                let roles = [];
                let policyNumbers = [];
                details.RoleSummary.Roles.forEach(role =>{ 
                    roles.push(Object.assign({}, role));
                    if(
                        role.PolicyNumber_Linked 
                        && role.PolicyNumber_Linked != this.policyRef 
                        && TYPES_FOR_LINK.indexOf(role.RoleType) != -1
                    ) {
                        policyNumbers.push(String(role.PolicyNumber_Linked));
                    } 
                });
                //Grab acc ids for each policy number
                let accIdByPolicyNumber = policyNumbers.length > 0 ? await fetchAccountIdsFromPolicyNumber({ pPolicyNumbers: policyNumbers }) : {};
                //Update roles
                let promises = [];
                roles.forEach(role => {
                    if(role.PolicyNumber_Linked && role.PolicyNumber_Linked in accIdByPolicyNumber) {
                        promises.push(this.buildAccountURL(accIdByPolicyNumber[role.PolicyNumber_Linked]).then(url => role.Link = url));
                    }
                });
                if(promises) await Promise.all(promises);

                this.data = roles.sort((pLeft, pRight) => sortObject(pLeft, pRight, DATA_ORDERING)) || [];
            }
        } catch(ex) {
            this.ErrorHandling.logErrorFromException(ex);
        } finally {
            this.State.show();
        }
    }

    async buildAccountURL(pAccId) {
        return this.Navigation.generateRecordPageLink(ACCOUNT_OBJECT.objectApiName, pAccId);
    }

}