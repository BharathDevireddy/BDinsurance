export const PREMIUM_DETAIL_LAYOUT = [
    {
        collapsible: true,
        heading: 'Current Premium',
        useHeading: true,
        subSections: [
            {
                id: 0,
                columns: 2,
                rows: [
                    {
                        fields: [
                            {
                                label: 'Paid To Date',
                                fieldName: 'PaidToDate',
                                fieldType: 'DateTime',
                                fieldTypeAttributes: {
                                    day: '2-digit',
                                    month: '2-digit',
                                    year: 'numeric'
                                }
                            },
                            {
                                label: 'Total Premium',
                                fieldName: 'TotalPremium',
                                fieldType: 'Number',
                                fieldTypeAttributes: {
                                    minimumFractionDigits: 2
                                }
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Collection Date',
                                fieldName: 'PaymentDate',
                                fieldType: 'Number'
                            },
                            {
                                label: 'Billing Cycle',
                                fieldName: 'BillingCycle',
                                fieldType: 'Text'
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Bank Name',
                                fieldName: 'BankName',
                                fieldType: 'Text'
                            },
                            {
                                label: 'Account Name',
                                fieldName: 'AccountName',
                                fieldType: 'Text'
                            }
                        ]
                    },
                    {
                        fields: [
                            {
                                label: 'Account Number',
                                fieldName: 'BankAccount',
                                fieldType: 'Text'
                            },
                            {
                                label: 'Sort Code',
                                fieldName: 'SortCode',
                                fieldType: 'Text'
                            }
                        ]
                    }
                ]
            }
        ]
    }
];

export const PREMIUM_TABLE_COLUMNS = [
    {
        label: 'Cover',
        fieldName: 'Cover',
        type: 'text'
    },
    {
        label: 'Reference',
        fieldName: 'DisplayReference',
        type: 'text'
    },
    {
        label: 'Premium',
        fieldName: 'Premium',
        type: 'number',
        typeAttributes: { minimumFractionDigits: 2}
    }
];