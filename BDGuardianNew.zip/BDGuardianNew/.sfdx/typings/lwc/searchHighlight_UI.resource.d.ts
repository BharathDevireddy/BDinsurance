declare module "@salesforce/resourceUrl/searchHighlight_UI" {
    var searchHighlight_UI: string;
    export default searchHighlight_UI;
}