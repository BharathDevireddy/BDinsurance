declare module "@salesforce/resourceUrl/searchHighlight" {
    var searchHighlight: string;
    export default searchHighlight;
}