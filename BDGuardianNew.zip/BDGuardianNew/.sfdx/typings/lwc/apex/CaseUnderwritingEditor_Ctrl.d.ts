declare module "@salesforce/apex/CaseUnderwritingEditor_Ctrl.fetchDataForInit" {
  export default function fetchDataForInit(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseUnderwritingEditor_Ctrl.saveRecords" {
  export default function saveRecords(param: {records: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseUnderwritingEditor_Ctrl.getDisplayDensity" {
  export default function getDisplayDensity(): Promise<any>;
}
declare module "@salesforce/apex/CaseUnderwritingEditor_Ctrl.fetchExclusions" {
  export default function fetchExclusions(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseUnderwritingEditor_Ctrl.fetchRemovals" {
  export default function fetchRemovals(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseUnderwritingEditor_Ctrl.fetchPostpones" {
  export default function fetchPostpones(param: {caseId: any}): Promise<any>;
}
