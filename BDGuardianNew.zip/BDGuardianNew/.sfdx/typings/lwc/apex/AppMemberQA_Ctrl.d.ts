declare module "@salesforce/apex/AppMemberQA_Ctrl.getWrappedApplicationQARecordsForStatus" {
  export default function getWrappedApplicationQARecordsForStatus(param: {applicationMemberId: any, status: any, isNBJ2: any}): Promise<any>;
}
declare module "@salesforce/apex/AppMemberQA_Ctrl.getIsThisNBJ2" {
  export default function getIsThisNBJ2(param: {applicationMemberId: any}): Promise<any>;
}
declare module "@salesforce/apex/AppMemberQA_Ctrl.getApplicationMemberId" {
  export default function getApplicationMemberId(param: {parentRecordId: any}): Promise<any>;
}
declare module "@salesforce/apex/AppMemberQA_Ctrl.fetchApplicationMemberAnswerStatuses" {
  export default function fetchApplicationMemberAnswerStatuses(param: {applicationMemberId: any, isNBJ2: any}): Promise<any>;
}
declare module "@salesforce/apex/AppMemberQA_Ctrl.getQAStatusOptions" {
  export default function getQAStatusOptions(param: {isNBJ2: any}): Promise<any>;
}
declare module "@salesforce/apex/AppMemberQA_Ctrl.getShowURELink" {
  export default function getShowURELink(): Promise<any>;
}
