declare module "@salesforce/apex/PolicyHeader_LEx.fetchAccountForPolicyNumber" {
  export default function fetchAccountForPolicyNumber(param: {pPolicyNumber: any}): Promise<any>;
}
declare module "@salesforce/apex/PolicyHeader_LEx.fetchLatestOpenCase" {
  export default function fetchLatestOpenCase(param: {pPolicyNumber: any}): Promise<any>;
}
