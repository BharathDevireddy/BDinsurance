declare module "@salesforce/apex/NewProductClaim_LEx.checkForExistingChildCase" {
  export default function checkForExistingChildCase(param: {policyClaimId: any, recordType: any}): Promise<any>;
}
declare module "@salesforce/apex/NewProductClaim_LEx.getProductClaimOptions" {
  export default function getProductClaimOptions(): Promise<any>;
}
