declare module "@salesforce/apex/newQaEvaluation_LEX.findDefaultVals" {
  export default function findDefaultVals(param: {CaseId: any}): Promise<any>;
}
