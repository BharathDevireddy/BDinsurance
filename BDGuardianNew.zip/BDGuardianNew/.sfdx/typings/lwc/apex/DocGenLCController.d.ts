declare module "@salesforce/apex/DocGenLCController.NewGuid" {
  export default function NewGuid(): Promise<any>;
}
declare module "@salesforce/apex/DocGenLCController.getCharAtIndex" {
  export default function getCharAtIndex(param: {str: any, index: any}): Promise<any>;
}
declare module "@salesforce/apex/DocGenLCController.getSelDocsToProcess" {
  export default function getSelDocsToProcess(param: {selDocList: any, AccId: any, coverLetterDate: any}): Promise<any>;
}
declare module "@salesforce/apex/DocGenLCController.fetchManuallyAmendedDocs" {
  export default function fetchManuallyAmendedDocs(param: {accId: any}): Promise<any>;
}
declare module "@salesforce/apex/DocGenLCController.getDocumentDetails" {
  export default function getDocumentDetails(param: {accId: any}): Promise<any>;
}
