declare module "@salesforce/apex/UWNotes_Ctrl.getCaseDetails" {
  export default function getCaseDetails(param: {pCaseId: any}): Promise<any>;
}
declare module "@salesforce/apex/UWNotes_Ctrl.getUWNotes" {
  export default function getUWNotes(param: {pCaseId: any}): Promise<any>;
}
