declare module "@salesforce/apex/CoverTable_LEx.fetchCoverTableMetadata" {
  export default function fetchCoverTableMetadata(): Promise<any>;
}
declare module "@salesforce/apex/CoverTable_LEx.fetchRecordPolicyReference" {
  export default function fetchRecordPolicyReference(param: {pRecordId: any}): Promise<any>;
}
