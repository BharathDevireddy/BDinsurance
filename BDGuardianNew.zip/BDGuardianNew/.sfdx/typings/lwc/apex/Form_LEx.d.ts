declare module "@salesforce/apex/Form_LEx.fetchFormConditionalMetadata" {
  export default function fetchFormConditionalMetadata(param: {pIdentifier: any}): Promise<any>;
}
