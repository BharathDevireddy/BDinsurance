declare module "@salesforce/apex/ProductClaimUnderwritingCases_LEx.getUnderwritingCases" {
  export default function getUnderwritingCases(param: {productClaimId: any}): Promise<any>;
}
