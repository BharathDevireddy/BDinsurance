declare module "@salesforce/resourceUrl/scc_tour_images" {
    var scc_tour_images: string;
    export default scc_tour_images;
}