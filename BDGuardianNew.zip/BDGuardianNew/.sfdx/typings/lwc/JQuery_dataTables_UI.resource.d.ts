declare module "@salesforce/resourceUrl/JQuery_dataTables_UI" {
    var JQuery_dataTables_UI: string;
    export default JQuery_dataTables_UI;
}